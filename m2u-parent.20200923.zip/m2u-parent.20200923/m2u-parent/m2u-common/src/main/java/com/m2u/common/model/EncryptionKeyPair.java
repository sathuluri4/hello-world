package com.m2u.common.model;

import lombok.Data;

@Data
public class EncryptionKeyPair {

    private String publicKey;
    private String privateKey;

    public EncryptionKeyPair() {}

    public EncryptionKeyPair(String publicKey, String privateKey) {
        this.publicKey = publicKey;
        this.privateKey = privateKey;
    }
}
