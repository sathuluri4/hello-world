package com.m2u.common.utils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class DateTimeUtils {

    private DateTimeUtils() {}

    public static String formatLocalDateTime(LocalDateTime dt, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format).withZone(ZoneId.systemDefault());
        return dt.format(formatter);
    }

    public static LocalDateTime getLocalDateTime(String dtStr, String fromFormat) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(fromFormat).withZone(ZoneId.systemDefault());
        return LocalDateTime.parse(dtStr, formatter);
    }

    public static String getLocalDateTimeInString(String dtStr, String fromFormat, String toFormat) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(fromFormat).withZone(ZoneId.systemDefault());
        LocalDateTime ldt = LocalDateTime.parse(dtStr, formatter);
        return formatLocalDateTime(ldt, toFormat);
    }
}
