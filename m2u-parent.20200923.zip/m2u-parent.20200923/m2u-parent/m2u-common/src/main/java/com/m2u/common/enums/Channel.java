package com.m2u.common.enums;

public enum Channel {

    M2U,
    LDAP,
    CLARITY,
    ADAPT,
    DATABASE,
    ;
}
