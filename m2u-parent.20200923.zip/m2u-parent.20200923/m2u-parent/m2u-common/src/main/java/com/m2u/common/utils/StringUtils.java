package com.m2u.common.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class StringUtils {

    private StringUtils() {}

    public static boolean isEmptyString(String str) {
        return (null == str || str.trim().isEmpty());
    }

    public static BigDecimal convertStringToBigDecimal(String data) {
        return new BigDecimal(data).setScale(2, RoundingMode.HALF_UP);
    }
}
