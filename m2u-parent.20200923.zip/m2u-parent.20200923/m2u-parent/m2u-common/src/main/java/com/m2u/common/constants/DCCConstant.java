package com.m2u.common.constants;

public final class DCCConstant {

    private DCCConstant() {}

    public static final Long DCC_TRUE = 0L;
    public static final Long DCC_FALSE = 1L;

    public static final Long DCC_NOT_DELETED = 0L;
    public static final Long DCC_DELETED = 1L;

    public static final Long DCC_INACTIVE = 0L;
    public static final Long DCC_ACTIVE = 1L;
}
