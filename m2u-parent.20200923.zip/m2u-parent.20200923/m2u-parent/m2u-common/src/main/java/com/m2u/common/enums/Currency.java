package com.m2u.common.enums;

public enum Currency {

    MYR ("Malaysia Ringgit"),
    SGD ("Singapore Dollar"),
    ;

    String description;

    Currency(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
