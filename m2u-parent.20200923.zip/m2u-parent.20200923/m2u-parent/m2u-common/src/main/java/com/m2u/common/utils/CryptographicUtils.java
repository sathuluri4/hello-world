package com.m2u.common.utils;

import com.m2u.common.exception.CryptographicException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

// TODO: All methods in this class using existing logic, might need refactor to improve performance later
@Slf4j
@Component
public class CryptographicUtils {

	private static final int NUM_ELEMENT = 13;
	private static final int CYCLE_LENGTH = 21;
	private static final double HASH_VALUE = 16362424037903.00;

	private static String signatureValue;

	private CryptographicUtils() {}

	@Value("${m2u.cryptographic.signature-value}")
	public synchronized void setSignatureValue(String signatureValue) {
		this.signatureValue = signatureValue;
	}

	public static String decypher(String encryptedData) throws CryptographicException {
		String decryptedStr = null;

		if (!StringUtils.isEmptyString (encryptedData)) {
			int [] permutation = getPermutation ();
			int rows = permutation.length;
			int cols = encryptedData.length() / rows;
			int [] anRowOfs = new int [rows];

			for (int i = 0 ; i < rows; i++) {
				anRowOfs[permutation[i]] = i * cols;
			}

			StringBuilder plainString = new StringBuilder();
			for (int i = 0; i < cols; i++) {
				for (int j = 0; j < rows; j++) {
					plainString.append(encryptedData.charAt (anRowOfs[ j ] + i));
				}
			}

			decryptedStr = unsignEncryptionKey(doTransLiterate (plainString.toString(), false));
			decryptedStr = decryptedStr.trim();
		}

		return decryptedStr;
	}

	public static String encrypt(String data) throws CryptographicException {
		if (null == data || 0 == data.trim().length()) {
			String errorDetails = String.format("Failed to encrypt data [%s]", data);
			log.error(errorDetails);
			throw new CryptographicException(errorDetails);
		}

		return encypher(data);
	}

	private static String encypher(String data) throws CryptographicException {
		StringBuilder encypherStr = new StringBuilder();

		if (!StringUtils.isEmptyString (data)) {
			int [] permutation = getPermutation();
			String encryptionKey = doTransLiterate(signEncryptionKey(data, permutation.length), true);

			int cols = permutation.length;
			int rows = encryptionKey.length() / cols;
			for (int i = 0; i < cols; i++) {
				int k = permutation[i];
				for (int j = 0; j < rows; j++) {
					encypherStr.append(encryptionKey.charAt(k));
					k += cols;
				}
			}
		}

		return encypherStr.toString();
	}

	private static String signEncryptionKey(String encryptionKey, int permutationLen) throws CryptographicException {
//		String signature = getSignature();

		int textLen = encryptionKey.length() + signatureValue.length();
		int missingCols = permutationLen - (textLen % permutationLen);
		StringBuilder strPadding = new StringBuilder();
		if (missingCols < permutationLen) {
			for (int i = 0; i < missingCols; i++) {
				strPadding.append(' ');
			}
		}

		encryptionKey += strPadding + signatureValue;

		return encryptionKey;
	}

	private static int [] getPermutation() {
		int [] transPositions = new int [NUM_ELEMENT * NUM_ELEMENT];
		int lastTransPositionLocation = 0;

		// Calculate permutation
		for (int i = 0; i < NUM_ELEMENT - 1; i++) {
			for (int j = i + 1; j < NUM_ELEMENT; j++) {
				transPositions[lastTransPositionLocation++] = ( i << 8 ) | j;
			}
		}

		// Calculate the permutation for password
		int [] aCycle = new int [CYCLE_LENGTH];
		double pred = HASH_VALUE;
		for (int i = 0; i < CYCLE_LENGTH; i++) {
			pred = 314159269 * pred + 907633409;
			aCycle[i] = (int)(pred % lastTransPositionLocation);
		}

		// Calculate permutation for an cycle
		int [] aPermutation = new int [NUM_ELEMENT];
		for (int i = 0; i < NUM_ELEMENT; i++) {
			aPermutation[i] = i;
		}

		for (int i = 0; i < aCycle.length; i++) {
			int t = transPositions[aCycle[i]];
			int n1 = t & 255;
			int n2 = (t >> 8) & 255;
			t = aPermutation[n1];
			aPermutation[n1] = aPermutation[n2];
			aPermutation[n2] = t;
		}

		return aPermutation;
	}

	private static String unsignEncryptionKey(String encryptionKey) throws CryptographicException {
//		String signature = getSignature();

		if (signatureValue!=null && signatureValue.length ()>0) {
			int textLen = encryptionKey.lastIndexOf(signatureValue);
			if (textLen>=0) {
				encryptionKey = encryptionKey.substring (0, textLen);
			} else {
				encryptionKey = "";
			}
		}

		return encryptionKey;
	}

	// TODO: Replace to application.yml setting instead of file base
//	private static String getSignature() throws CryptographicException {
//		StringBuilder retValue = new StringBuilder();
//
//		try(BufferedReader inputFile = new BufferedReader(new FileReader(scrambleFile))) {
//			String aLine = null;
//			while((aLine = inputFile.readLine()) != null) {
//				retValue.append(aLine);
//			}
//		} catch (IOException e) {
//			String errorDetails = String.format("Failed to get signature from scramble file [%s]", scrambleFile);
//			log.error(errorDetails, e);
//			throw new CryptographicException(errorDetails, e);
//		}
//
//		return retValue.toString();
//	}

	private static String doTransLiterate(final String encryptionKey, boolean transLiterate) {
		StringBuilder strDest = new StringBuilder();
		int textItr  = 0;
		int textTrail = 0;

		int keyLen = encryptionKey.length ();
		while (textItr < keyLen) {
			StringBuilder strRun = new StringBuilder();
			int skipped   = 0;
			while (skipped < 7 && textItr < keyLen) {
				char t = encryptionKey.charAt(textItr++);
				if (-1 == strRun.indexOf(String.valueOf(t))) {
					strRun.append(t);
					skipped = 0;
				} else {
					skipped++;
				}
			}

			while (textTrail < textItr) {
				int runIdx = strRun.indexOf(String.valueOf(encryptionKey.charAt(textTrail++)));
				if (transLiterate) {
					runIdx++;
					if (runIdx == strRun.length()) {
						runIdx = 0;
					}
				} else {
					runIdx--;
					if (runIdx == -1) {
						runIdx += strRun.length();
					}
				}
				strDest.append(strRun.charAt(runIdx));
			}
		}

		return strDest.toString();
	}
}
