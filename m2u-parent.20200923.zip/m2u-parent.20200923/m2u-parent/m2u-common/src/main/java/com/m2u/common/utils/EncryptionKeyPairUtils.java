package com.m2u.common.utils;

import com.m2u.common.exception.EncryptionKeyPairException;
import com.m2u.common.model.EncryptionKeyPair;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

// TODO: All methods in this class using existing logic, might need refactor to improve performance later
@Slf4j
public class EncryptionKeyPairUtils {

    private static final String RSA_ECB_PKCS1_PADDING = "RSA/ECB/PKCS1Padding";
    private static final String ENCRYPTION_ALGORITHM = "RSA";
    private static final Charset ENCODING = StandardCharsets.UTF_8;
    private static final int KEY_LENGTH = 2048;

    private EncryptionKeyPairUtils() {}

    public static EncryptionKeyPair createEncryptionKeyPair() throws EncryptionKeyPairException {
        KeyPairGenerator keyPairGenerator = null;
        try {
            keyPairGenerator = KeyPairGenerator.getInstance(ENCRYPTION_ALGORITHM);
        } catch (NoSuchAlgorithmException e) {
            String errorDetails = "Failed to create encryption keypair";
            log.error(errorDetails, e);
            throw new EncryptionKeyPairException(errorDetails, e);
        }
        keyPairGenerator.initialize(KEY_LENGTH);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        byte[] publicKeyBytes = keyPair.getPublic().getEncoded();
        String publicKey = Base64.getEncoder().encodeToString(publicKeyBytes);
        byte[] privateKeyBytes = keyPair.getPrivate().getEncoded();
        StringBuilder strB = new StringBuilder();
        for (int i = 0; i<privateKeyBytes.length; ++i) {
            strB.append(Integer.toHexString(0x0100 + (privateKeyBytes[i] & 0x00FF)).substring(1));
        }
        String privateKey = strB.toString();
        return new EncryptionKeyPair(publicKey, privateKey);
    }

    public static String decryptEncryptedData(String encryptedData, String sessionId, String privateKey) throws EncryptionKeyPairException {
        String decryptedData = null;
        String plainText = null;
        try {
            if (!StringUtils.isEmptyString(encryptedData)) {
                decryptedData = getDecryptedString(encryptedData, privateKey);
                plainText = getXORString(decryptedData, sessionId);
            }
        } catch (EncryptionKeyPairException e) {
            throw e;
        } catch (Exception e){
            String errorDetails = String.format("Failed to decrypt encrypted data [%s] with sessionId [%s] privateKey [%s]", encryptedData, sessionId, privateKey);
            throw new EncryptionKeyPairException(errorDetails, e);
        }
        return plainText;
    }

    private static String getDecryptedString(String encryptedMessage, String privateKeyHexString)
            throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException,
            NoSuchPaddingException, BadPaddingException, IllegalBlockSizeException, EncryptionKeyPairException {

        byte[] privateKeyByteArray = parseHexBinary(privateKeyHexString);
        KeyFactory keyFactory = KeyFactory.getInstance(ENCRYPTION_ALGORITHM);
        PrivateKey privateKey = keyFactory.generatePrivate(new PKCS8EncodedKeySpec(privateKeyByteArray));
        Cipher cipher = Cipher.getInstance(RSA_ECB_PKCS1_PADDING);
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        String decryptedBase64EncodedString = new String(Base64.getDecoder().decode(new String(cipher.doFinal(parseHexBinary(encryptedMessage)))));
        return new String(Base64.getDecoder().decode(decryptedBase64EncodedString));
    }

    private static byte[] parseHexBinary(String str) throws EncryptionKeyPairException {
        int len = str.length();
        if ((len % 2) != 0) {
            String errorDetails = String.format("HexBinary [%s] needs to be in even length but found odd length [%d] instead", str, len);
            log.error(errorDetails);
            throw new EncryptionKeyPairException(errorDetails);
        }
        byte[] out = new byte[len/2];
        for ( int i=0; i<len; i+=2 ) {
            int h = hexToBin(str.charAt(i));
            int l = hexToBin(str.charAt(i+1));
            if( h==-1 || l==-1 ) {
                String errorDetails = String.format("HexBinary [%s] contains illegal character h [%d] l [%d]", str, h, l);
                log.error(errorDetails);
                throw new EncryptionKeyPairException(errorDetails);
            }
            out[i/2] = (byte)(h*16+l);
        }
        return out;
    }

    private static int hexToBin(char ch) {
        if( '0'<=ch && ch<='9' ) {
            return ch-'0';
        }
        if( 'A'<=ch && ch<='F' ) {
            return ch-'A'+10;
        }
        if( 'a'<=ch && ch<='f' ) {
            return ch-'a'+10;
        }
        return -1;
    }

    private static String getXORString(String message, String key) {
        byte[] messageBytes = message.getBytes(ENCODING);
        byte[] keyBytes = key.getBytes(StandardCharsets.UTF_8);
        byte[] out = new byte[messageBytes.length];
        for (int i = 0; i < messageBytes.length; i++) {
            out[i] = (byte) (messageBytes[i] ^ keyBytes[i % keyBytes.length]);
        }
        return new String(out);
    }
}
