package com.m2u.cache.controller;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
import com.hazelcast.internal.json.Json;
import com.hazelcast.internal.json.JsonValue;
import com.m2u.cache.enums.CacheMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
public class CacheController {

    @Autowired
    private HazelcastInstance hazelcastInstance;

    @GetMapping(path = "/v1/caches")
    public ResponseEntity<String> getCache(@RequestParam(value = "name") java.lang.String name, @RequestParam(value = "key") java.lang.String key) {
        log.debug("Name [{}] Key [{}]", name, key);
        CacheMap cacheMap = null;
        try {
            cacheMap = CacheMap.valueOf(name);
        } catch (Exception e) {
            String errorDetails = String.format("Unsupported cache map name [%s]. key[%s]", name, key);
            log.error(errorDetails, e);
            return ResponseEntity.badRequest().body(errorDetails);
        }

        IMap<String, String> map = hazelcastInstance.getMap(cacheMap.name());
        String value = map.get(key);

        if (null == value || value.isEmpty()) {
            String errorDetails = String.format("Cache not found for key [%s] in map [%s]", key, name);
            log.warn(errorDetails);
            return ResponseEntity.noContent().build();
        } else {
            log.debug("Cache retrieved with key [{}] value [{}]", key, value);
            return ResponseEntity.ok(value);
        }
    }

    @PostMapping(path = "/v1/caches")
    public ResponseEntity<String> createCache(@RequestBody String keyValue) {
        log.debug("KeyValue [{}]", keyValue);
        JsonValue parse = Json.parse(keyValue);
        String name = parse.asObject().getString("name", "name");
        CacheMap cacheMap = null;
        try {
            cacheMap = CacheMap.valueOf(name);
        } catch (Exception e) {
            String errorDetails = String.format("Unsupported cache map name [%s]. keyValue [%s]", name, keyValue);
            log.error(errorDetails, e);
            return ResponseEntity.badRequest().body(errorDetails);
        }

        String key = parse.asObject().getString("key", "key");
        String value = parse.asObject().get("value").toString();
        IMap<String, String> map = hazelcastInstance.getMap(cacheMap.name());
        String oldValue = map.put(key, value);
        if (null == oldValue) {
            log.debug("Cache inserted with key [{}] in map [{}]", key, cacheMap.name());
            return ResponseEntity.ok(value);
        } else {
            log.debug("Cache updated with key [{}] in map [{}]", key, cacheMap.name());
            return ResponseEntity.ok(oldValue);
        }
    }

    @PutMapping(path = "/v1/caches")
    public ResponseEntity<String> updateCache(@RequestBody String keyValue) {
        return createCache(keyValue);
    }

    @DeleteMapping(path = "/v1/caches")
    public ResponseEntity<String> deleteCache(@RequestParam(value = "name") String name, @RequestParam(value = "key") String key) {
        log.debug("Name [{}] Key [{}]", name, key);
        CacheMap cacheMap = null;
        try {
            cacheMap = CacheMap.valueOf(name);
        } catch (Exception e) {
            String errorDetails = String.format("Unsupported cache map name [%s]. key[%s]", name, key);
            log.error(errorDetails, e);
            return ResponseEntity.badRequest().body(errorDetails);
        }

        IMap<String, String> map = hazelcastInstance.getMap(cacheMap.name());
        map.delete(key);

        log.debug("Cache deleted with key [{}]", key);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
