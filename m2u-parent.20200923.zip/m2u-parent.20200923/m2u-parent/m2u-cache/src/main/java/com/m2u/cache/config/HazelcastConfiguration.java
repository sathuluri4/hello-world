package com.m2u.cache.config;

import com.hazelcast.config.*;
import com.m2u.cache.enums.CacheMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;

@Slf4j
@Configuration
public class HazelcastConfiguration {

    @Value("${m2u.cache.port}")
    private int port;

    @Value("${m2u.cache.members}")
    private String[] members;

    @Value("${m2u.cache.time-to-live-secs: 240}")
    private int timeToLiveSecs;

    @Value("${m2u.cache.max-idle-secs: 240}")
    private int maxIdleSecs;

    @Bean
    public Config hazelcastConfig(){
        Config conf = new Config();

        // TODO: Reference https://docs.hazelcast.org/docs/latest/manual/html-single/
        // Network Config
        NetworkConfig networkConf = conf.getNetworkConfig();
        networkConf.setPortAutoIncrement(false).setPort(port);
        JoinConfig joinConf = networkConf.getJoin();
        joinConf.getMulticastConfig().setEnabled(false);
        joinConf.getTcpIpConfig().setEnabled(true);
        joinConf.getTcpIpConfig().setMembers(Arrays.asList(members));

        // Map Config
        conf.addMapConfig(createPaymentMapConfig());

        return conf;
    }

    // References:
    // https://docs.hazelcast.org/docs/3.11.2/manual/html-single/index.html#map-eviction
    // https://www.programcreek.com/java-api-examples/?api=com.hazelcast.config.MapConfig

    private MapConfig createPaymentMapConfig() {
        MapConfig mapConfig = new MapConfig(CacheMap.PAYMENT.name());
        // TODO: Research and explore more configuration available
        mapConfig.setTimeToLiveSeconds(timeToLiveSecs); // Reset if detected any WRITE action, else evicted automatically
        mapConfig.setMaxIdleSeconds(maxIdleSecs); // Reset if detected any READ/WRITE action, else evicted automatically
        mapConfig.setEvictionPolicy(EvictionPolicy.LRU);
        MaxSizeConfig maxSizeConfig = new MaxSizeConfig(0, MaxSizeConfig.MaxSizePolicy.USED_HEAP_SIZE);
        mapConfig.setMaxSizeConfig(maxSizeConfig);
        return mapConfig;
    }
}
