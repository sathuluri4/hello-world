package com.m2u.cache.enums;

public enum CacheMap {

    PAYMENT,
    ;
}