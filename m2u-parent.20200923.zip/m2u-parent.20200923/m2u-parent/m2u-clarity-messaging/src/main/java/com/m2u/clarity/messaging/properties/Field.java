package com.m2u.clarity.messaging.properties;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class Field {

    public Field() {}

    public Field(String name, int size, String type) {
        this.name = name;
        this.size = size;
        this.type = type;
    }

    private String name;
    private int size;
    private String type;
    private boolean list;
    private boolean leftPadZeros;
    private boolean rightPadZeros;
    private boolean leftPadSpaces;
    private boolean rightPadSpaces;
    private boolean optional;
    private String defaultVal;
    private boolean ignore;
    private boolean repeat;
    private int noOfOccursSize;
    private List<Field> subFields = new ArrayList<>();
    private int noOfCertsRef;
}
