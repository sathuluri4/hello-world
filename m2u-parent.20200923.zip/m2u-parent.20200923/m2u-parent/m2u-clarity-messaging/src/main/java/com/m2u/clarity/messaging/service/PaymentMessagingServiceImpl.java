package com.m2u.clarity.messaging.service;

import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.converter.MessageConverter;
import com.m2u.clarity.messaging.dto.CreateBillPaymentRequestDTO;
import com.m2u.clarity.messaging.dto.CreateBillPaymentResponseDTO;
import com.m2u.clarity.messaging.dto.CreateOnlinePaymentRequestDTO;
import com.m2u.clarity.messaging.dto.CreateOnlinePaymentResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.helper.TCPMessagingHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PaymentMessagingServiceImpl implements PaymentMessagingService {

    @Autowired
    private TCPMessagingHelper tcpMessagingHelper;

    @Autowired
    @Qualifier("CreateOnlinePaymentMessageConverter")
    private MessageConverter<CreateOnlinePaymentRequestDTO, CreateOnlinePaymentResponseDTO> createOnlinePaymentMessageConverter;

    @Autowired
    @Qualifier("CreateBillPaymentMessageConverter")
    private MessageConverter<CreateBillPaymentRequestDTO, CreateBillPaymentResponseDTO> createBillPaymentMessageConverter;

    @Override
    public CreateOnlinePaymentResponseDTO createOnlinePayment(CreateOnlinePaymentRequestDTO request) throws ClarityMessagingException {
        String convertedMessage = createOnlinePaymentMessageConverter.convertRequestMessage(request);
        log.debug("[{}] CLARITY REQ [{}]", request.getTxnRefId(), convertedMessage);

        String response = null;
        try {
            response = tcpMessagingHelper.sendMessage(convertedMessage);
        } catch (ClarityMessagingException e) {
            String errorDetails = String.format("Failed to send payment request [%s]. txnRefId [%s]", convertedMessage, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.TCP_MESSAGE_SEND_FAILED.getCode(),
                ClarityMessagingStatus.TCP_MESSAGE_SEND_FAILED.getDesc(),
                errorDetails, e);
            throw e;
        }

        log.debug("[{}] CLARITY RESP [{}]", request.getTxnRefId(), response);

        return createOnlinePaymentMessageConverter.convertResponseMessage(request, response);
    }

    @Override
    public CreateBillPaymentResponseDTO createBillPayment(CreateBillPaymentRequestDTO request) throws ClarityMessagingException {
        String convertedMessage = createBillPaymentMessageConverter.convertRequestMessage(request);
        log.debug("[{}] CLARITY REQ [{}]", request.getTxnRefId(), convertedMessage);

        String response = null;
        try {
            response = tcpMessagingHelper.sendMessage(convertedMessage);
        } catch (ClarityMessagingException e) {
            String errorDetails = String.format("Failed to send payment request [%s]. txnRefId [%s]", convertedMessage, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.TCP_MESSAGE_SEND_FAILED.getCode(),
                ClarityMessagingStatus.TCP_MESSAGE_SEND_FAILED.getDesc(),
                errorDetails, e);
            throw e;
        }

        log.debug("[{}] CLARITY RESP [{}]", request.getTxnRefId(), response);

        return createBillPaymentMessageConverter.convertResponseMessage(request, response);
    }

}
