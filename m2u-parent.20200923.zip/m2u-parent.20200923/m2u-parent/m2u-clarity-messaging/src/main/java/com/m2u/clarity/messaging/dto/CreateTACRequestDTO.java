package com.m2u.clarity.messaging.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;

@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CreateTACRequestDTO extends AbstractRequestDTO {

    private String serviceRestrictCode;
    private String serviceName;
    private String serviceMessage;
    private String tacServiceCode;
    private String tacInfo1;
    private String tacInfo2;
}
