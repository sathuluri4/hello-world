package com.m2u.clarity.messaging.constants;

public final class Iso8583 {

    private Iso8583() {}

    // Data Type
    public static final String DATA_TYPE_ALPHA = "A";
    public static final String DATA_TYPE_NUMBER = "N";
}
