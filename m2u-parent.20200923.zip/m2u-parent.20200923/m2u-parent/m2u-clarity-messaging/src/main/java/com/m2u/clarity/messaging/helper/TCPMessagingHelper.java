package com.m2u.clarity.messaging.helper;

import com.m2u.clarity.messaging.exception.ClarityMessagingException;

public interface TCPMessagingHelper {

    String sendMessage(String message) throws ClarityMessagingException;
}
