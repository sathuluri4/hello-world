package com.m2u.clarity.messaging.helper;

import com.m2u.clarity.messaging.config.ClarityMessagingConfiguration;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.TCPMessagingProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

@Slf4j
@Component
public class TCPMessagingHelperImpl implements TCPMessagingHelper {

    private BlockingQueue<String> accessTokenQueue;

    @Autowired
    private ClarityMessagingConfiguration.TCPGateway tcpGateway;

    @Autowired
    private TCPMessagingProperties tcpMessagingProp;

    @Autowired
    public TCPMessagingHelperImpl(TCPMessagingProperties tcpMessagingProp) {
        accessTokenQueue = new ArrayBlockingQueue<>(tcpMessagingProp.getClient().getPoolSize());
        for(int i=1; i<=tcpMessagingProp.getClient().getPoolSize(); i++) {
            accessTokenQueue.add("AccessToken_" + i);
        }
    }

    @Override
    public String sendMessage(String message) throws ClarityMessagingException {
        String accessToken = null;
        try {
            accessToken = accessTokenQueue.take();
            return tcpGateway.sendMessage(message);
        } catch (Exception e) {
            throw new ClarityMessagingException(ClarityMessagingStatus.TCP_MESSAGE_SEND_FAILED, e.getMessage(), e);
        } finally {
            if(null != accessToken) {
                accessTokenQueue.add(accessToken);
            }
        }
    }
}
