package com.m2u.clarity.messaging.controller;

import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.GetLogonRequestDTO;
import com.m2u.clarity.messaging.dto.GetLogonResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.service.LogonMessagingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class LogonController extends AbstractController {

    @Autowired
    private LogonMessagingService logonMessagingService;

    @GetMapping(
        path="/v1/logons",
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<GetLogonResponseDTO> getLogon(@RequestBody GetLogonRequestDTO request) {
        log.debug("[{}] REQ [{}]", request.getTxnRefId(), request);
        try {
            GetLogonResponseDTO response = logonMessagingService.getLogon(request);
            log.debug("[{}] RESP [{}]", request.getTxnRefId(), response);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ClarityMessagingException e) {
            return new ResponseEntity<>(
                createErrorResponse(GetLogonResponseDTO.class, request, e.getStatusCode(), e.getMessage()),
                HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.UNEXPECTED_EXCEPTION.getCode(),
                ClarityMessagingStatus.UNEXPECTED_EXCEPTION.getDesc(), e);
            return new ResponseEntity<>(
                createErrorResponse(GetLogonResponseDTO.class, request, ClarityMessagingStatus.UNEXPECTED_EXCEPTION, e.getMessage()),
                HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
