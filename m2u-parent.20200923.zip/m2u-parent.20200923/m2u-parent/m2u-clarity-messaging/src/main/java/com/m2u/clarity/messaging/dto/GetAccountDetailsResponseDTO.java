package com.m2u.clarity.messaging.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.Map;

@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class GetAccountDetailsResponseDTO extends AbstractResponseDTO {

    private String retrievalRefNo;
    private String accountNo;
    private String fdCertificateNo;
    private String accountStatus;
    private String currencyCode;
    private List<Map<String, String>> names;
    private List<Map<String, String>> balOrDates;
}
