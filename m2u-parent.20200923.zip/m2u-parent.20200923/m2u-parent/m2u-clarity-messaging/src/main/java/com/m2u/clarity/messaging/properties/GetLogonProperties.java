package com.m2u.clarity.messaging.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ConfigurationProperties(prefix="m2u.clarity.messaging.get-logon")
@Data
public class GetLogonProperties {

    private final Request request = new Request();
    private final Response response = new Response();

    @Data
    public static class Request {
        private Map<String, String> messageTypes = new HashMap<>();
        private String messageTypeId;
        private RequestDataElement dataElement;
    }

    @Data
    public static class RequestDataElement {
        private Map<String, String> processingCodes = new HashMap<>();
        private Map<String, String> pointOfServices = new HashMap<>();
        private String retrievalRefNo;
        private Map<String, String> terminalIds = new HashMap<>();
        private RequestAdditionalData additionalData;
    }

    @Data
    public static class RequestAdditionalData {
        private Map<String, String> serviceCodes = new HashMap<>();
        private List<String> subServiceIds = new ArrayList<>();
    }

    @Data
    public static class Response {
        private String primaryBitmap;
        private Map<String, List<Field>> additionalData = new HashMap<>();
    }
}
