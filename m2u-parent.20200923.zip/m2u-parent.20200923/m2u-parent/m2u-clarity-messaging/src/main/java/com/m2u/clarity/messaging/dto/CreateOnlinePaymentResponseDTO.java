package com.m2u.clarity.messaging.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;

@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CreateOnlinePaymentResponseDTO extends AbstractResponseDTO {

    private String currencyCode;
    private String fromAcctBal;
    private String seqNo;
    private String secure2uToken;
    private String mac;
}
