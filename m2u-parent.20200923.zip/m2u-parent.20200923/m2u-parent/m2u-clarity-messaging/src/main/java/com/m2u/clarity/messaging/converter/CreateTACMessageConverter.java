package com.m2u.clarity.messaging.converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.CreateTACRequestDTO;
import com.m2u.clarity.messaging.dto.CreateTACResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.ClarityCommonProperties;
import com.m2u.clarity.messaging.properties.CreateTACProperties;
import com.m2u.clarity.messaging.utils.ClarityMessagingUtils;
import com.m2u.clarity.messaging.utils.Iso8583Utils;
import com.m2u.clarity.messaging.utils.JposUtils;
import lombok.extern.slf4j.Slf4j;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component("CreateTACMessageConverter")
public class CreateTACMessageConverter extends AbstractMessageConverter implements MessageConverter<CreateTACRequestDTO, CreateTACResponseDTO> {

    @Autowired
    private ClarityCommonProperties clarityCommonProp;

    @Autowired
    private CreateTACProperties createTACProp;

    private GenericPackager packager;

    @Autowired
    public CreateTACMessageConverter(
        @Value("${m2u.clarity.messaging.jpos.packager.create-tac.default}") String packagerConfig) throws ClarityMessagingException {

        this.packager = JposUtils.setupPackager(packagerConfig);
    }

    @Override
    public String convertRequestMessage(CreateTACRequestDTO request) throws ClarityMessagingException {
        try {
            StringBuilder convertedMessage = new StringBuilder();
            CreateTACProperties.Request reqConfig = createTACProp.getRequest();
            CreateTACProperties.RequestDataElement reqDataElement = reqConfig.getDataElement();
            CreateTACProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();

            // Validating request data before proceed further
            validateRequestData(request);
            // Update request data, e.g. replace with default values, padding, etc
            updateRequestData(request);

            // Generate request message wrapper
            String messageType = reqConfig.getMessageType();
            String reqMessageWrapper = ClarityMessagingUtils.generateReqMessageWrapper(request, messageType);
            convertedMessage.append(reqMessageWrapper);

            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.set(0, reqConfig.getMessageTypeId());
            // PrimaryBitmap is calculate and set by JPOS during packing
            isoMsg.set(2, request.getPan());
            isoMsg.set(3, reqDataElement.getProcessingCodes().get(request.getCountryCode()));
            isoMsg.set(22, reqDataElement.getPointOfServices().get(request.getCountryCode()));
            isoMsg.set(40, request.getServiceRestrictCode());
            isoMsg.set(41, reqDataElement.getTerminalIds().get(request.getCountryCode()));

            StringBuilder additionalData = new StringBuilder();
            additionalData
                .append(reqAdditionalData.getServiceCode())
                .append(request.getServiceName())
                .append(request.getServiceMessage())
                .append(request.getTacServiceCode())
                .append(request.getTacInfo1())
                .append(request.getTacInfo2());

            isoMsg.set(61, additionalData.toString());

            // Call jPOS to generate ISO8583 message
            convertedMessage.append(new String(isoMsg.pack()));
            return convertedMessage.toString();

        } catch (ISOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getCode(),
                ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }

    @Override
    public CreateTACResponseDTO convertResponseMessage(CreateTACRequestDTO request, String response) throws ClarityMessagingException {
        try {
            StringBuilder strB = new StringBuilder(response);

            // Parse response message wrapper
            CreateTACResponseDTO createTACResponseDTO = parseRespMessageWrapper(request, CreateTACResponseDTO.class, response, strB);

            // Replace dummy primary bitmap responded from CLARITY, jPOS need actual primary bitmap for parsing message
            replaceRespBitmaps(request, response, createTACProp.getResponse().getPrimaryBitmap(), strB);

            // Parse ISO8583 message
            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.unpack(strB.toString().getBytes());

            createTACResponseDTO.setSystemAuditTrailNo(isoMsg.getString(11));
            createTACResponseDTO.setDateTime(isoMsg.getString(12));
            createTACResponseDTO.setTacLength(isoMsg.getString(27));
            createTACResponseDTO.setTac(isoMsg.getString(38).trim());
            createTACResponseDTO.setActionCode(isoMsg.getString(39));
            createTACResponseDTO.setTerminalId(isoMsg.getString(41));

            String bit62Data = isoMsg.getString(62);
            Map<String, Object> dataMap = null;
            if(null != bit62Data && bit62Data.length() > 0) {
                StringBuilder strB62 = new StringBuilder(bit62Data);
                List<Map<String, Object>> dataList = parseRespFields(request, createTACProp.getResponse().getAdditionalData(), bit62Data, strB62);

                // Always take the first index for root object
                dataMap = dataList.get(0);
            } else {
                dataMap = new HashMap<>(0);
            }

            ObjectMapper mapper = new ObjectMapper();
            // Updating values to existing object
            mapper.readerForUpdating(createTACResponseDTO).readValue(mapper.writeValueAsBytes(dataMap));

            return createTACResponseDTO;
        } catch (ISOException | IOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getCode(),
                ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }

    private void validateRequestData(CreateTACRequestDTO request) throws ClarityMessagingException {
        CreateTACProperties.RequestDataElement reqDataElement = createTACProp.getRequest().getDataElement();
        CreateTACProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();

        validateDataAgainstMap(request, reqDataElement.getProcessingCodes(), request.getCountryCode(), "ProcessingCode");
        validateDataAgainstMap(request, reqDataElement.getPointOfServices(), request.getCountryCode(), "PointOfService");
        validateDataAgainstMap(request, reqDataElement.getTerminalIds(), request.getCountryCode(), "TerminalId");
        validateDataAgainstList(request, reqDataElement.getServiceRestrictCodes(), request.getServiceRestrictCode(), "ServiceRestrictCode");

        // Validate Additional Data
        validateDataAgainstList(request, reqAdditionalData.getServiceNames(), request.getServiceName(), "ServiceName");
        Iso8583Utils.validateField(request.getServiceMessage(), reqAdditionalData.getServiceMessage());
        Iso8583Utils.validateField(request.getTacServiceCode(), reqAdditionalData.getTacServiceCode());
        Iso8583Utils.validateField(request.getTacInfo1(), reqAdditionalData.getTacInfo1());
        Iso8583Utils.validateField(request.getTacInfo2(), reqAdditionalData.getTacInfo2());
    }

    private void updateRequestData(CreateTACRequestDTO request) {
        CreateTACProperties.RequestAdditionalData reqAdditionalData = createTACProp.getRequest().getDataElement().getAdditionalData();
        request.setServiceMessage(Iso8583Utils.padFieldData(request.getServiceMessage(), reqAdditionalData.getServiceMessage()));
        request.setTacInfo1(Iso8583Utils.padFieldData(request.getTacInfo1(), reqAdditionalData.getTacInfo1()));
        request.setTacInfo2(Iso8583Utils.padFieldData(request.getTacInfo2(), reqAdditionalData.getTacInfo2()));
    }
}