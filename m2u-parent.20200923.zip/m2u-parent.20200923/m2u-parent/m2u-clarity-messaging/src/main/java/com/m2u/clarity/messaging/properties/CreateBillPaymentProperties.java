package com.m2u.clarity.messaging.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ConfigurationProperties(prefix="m2u.clarity.messaging.create-bill-payment")
@Data
public class CreateBillPaymentProperties {

    private final Request request = new Request();
    private final Response response = new Response();

    @Data
    public static class Request {
        private String messageType;
        private String messageTypeId;
        private RequestDataElement dataElement;
    }

    @Data
    public static class RequestDataElement {
        private Map<String, String> processingCodes = new HashMap<>();
        private Map<String, String> pointOfServices = new HashMap<>();
        private List<String> serviceRestrictCodes = new ArrayList<>();
        private Map<String, String> terminalIds = new HashMap<>();
        private Field fromAcctNo;
        private Field toAcctNo;
        private RequestAdditionalData additionalData;
        private RequestSmsData smsData;
    }

    @Data
    public static class RequestAdditionalData {
        private List<String> serviceCodeHeads;
        private List<String> serviceCodes = new ArrayList<>();
        private Field fromAcctCode;
        private Field toAcctCode;
        private Field payeeCode;
        private Field refNo;
        private Field individualEffectPaymentDate;
        private Field currencyCode;
        private Field txnAmount;
        private Field billAcctNo;
        private Field custName;
        private Field icNoBusRegNo;
        private Field cNo;
        private Field expiryDate;
        private Field cvv;
    }

    @Data
    public static class RequestSmsData {
        private List<String> smsAlertBits = new ArrayList<>();
        private Field smsUserId;
        private Field selfNotifMobileNo;
    }

    @Data
    public static class Response {
        private String primaryBitmap;
        private List<Field> additionalData = new ArrayList<>();
    }
}
