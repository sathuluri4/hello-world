package com.m2u.clarity.messaging.converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.CreateOnlinePaymentRequestDTO;
import com.m2u.clarity.messaging.dto.CreateOnlinePaymentResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.ClarityCommonProperties;
import com.m2u.clarity.messaging.properties.CreateOnlinePaymentProperties;
import com.m2u.clarity.messaging.utils.ClarityMessagingUtils;
import com.m2u.clarity.messaging.utils.DestUtils;
import com.m2u.clarity.messaging.utils.Iso8583Utils;
import com.m2u.clarity.messaging.utils.JposUtils;
import lombok.extern.slf4j.Slf4j;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component("CreateOnlinePaymentMessageConverter")
public class CreateOnlinePaymentMessageConverter extends AbstractMessageConverter implements MessageConverter<CreateOnlinePaymentRequestDTO, CreateOnlinePaymentResponseDTO> {

    private static final String TODAY_EFFECTIVE_DATE = "00000000";
    
    @Autowired
    private ClarityCommonProperties clarityCommonProp;

    @Autowired
    private CreateOnlinePaymentProperties createOnlinePaymentProp;

    private GenericPackager packager;

    @Autowired
    public CreateOnlinePaymentMessageConverter(
        @Value("${m2u.clarity.messaging.jpos.packager.create-online-payment.default}") String packagerConfig) throws ClarityMessagingException {

        this.packager = JposUtils.setupPackager(packagerConfig);
    }

    @Override
    public String convertRequestMessage(CreateOnlinePaymentRequestDTO request) throws ClarityMessagingException {
        try {
            StringBuilder convertedMessage = new StringBuilder();
            CreateOnlinePaymentProperties.Request reqConfig = createOnlinePaymentProp.getRequest();
            CreateOnlinePaymentProperties.RequestDataElement reqDataElement = reqConfig.getDataElement();

            // Validating request data before proceed further
            validateRequestData(request);
            // Update request data, e.g. replace with default values, padding, etc
            updateRequestData(request);

            // Generate request message wrapper
            String messageType = reqConfig.getMessageType();
            String reqMessageWrapper = ClarityMessagingUtils.generateReqMessageWrapper(request, messageType);
            convertedMessage.append(reqMessageWrapper);

            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.set(0, reqConfig.getMessageTypeId());
            // PrimaryBitmap is calculate and set by JPOS during packing
            isoMsg.set(2, request.getPan());
            isoMsg.set(3, reqDataElement.getProcessingCodes().get(request.getCountryCode()));
            isoMsg.set(4, request.getTxnAmount());
            isoMsg.set(22, reqDataElement.getPointOfServices().get(request.getCountryCode()));
            isoMsg.set(27, String.valueOf(request.getTacLength()));
            isoMsg.set(38, request.getTac());
            isoMsg.set(40, request.getServiceRestrictCode());
            isoMsg.set(41, reqDataElement.getTerminalIds().get(request.getCountryCode()));
            isoMsg.set(49, request.getTxnCurrencyCode());

            StringBuilder additionalData = new StringBuilder();
            additionalData
                .append(request.getServiceCode())
                .append(request.getFromAcctCode())
                .append(request.getToAcctCode())
                .append(request.getPayeeCode())
                .append(request.getRefNo())
                .append(request.getThirdPartyAcctNo())
                .append(request.getBillAcctNo())
                .append(request.getRecipientRef())
                .append(request.getOtherPaymentDesc());
            isoMsg.set(61, additionalData.toString());

            StringBuilder smsData = new StringBuilder();
            smsData
                .append(request.getSmsAlertBit())
                .append(request.getSmsUserId())
                .append(request.getSelfNotifMobileNo())
                .append(request.getThirdPartyNotifMobileNo());
            isoMsg.set(63, smsData.toString());

            isoMsg.set(73, request.getEffectiveDate());
            isoMsg.set(102, request.getFromAcctNo());
            isoMsg.set(103, request.getToAcctNo());
            // TODO: Set dummy data to get the correct primary & secondary bitmaps
            isoMsg.set(128, "                ");

            // MAC setup
            String temp = new String(isoMsg.pack());
            // Skip the dummy MAC generated just now
            temp = temp.substring(0, temp.length() - 16);
            String mac = DestUtils.createMAC(temp);
            isoMsg.set(128, mac);
            temp = new String(isoMsg.pack());

            // Call jPOS to generate ISO8583 message
            convertedMessage.append(temp);

            return convertedMessage.toString();

        } catch (ISOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getCode(),
                ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }
    
    @Override
    public CreateOnlinePaymentResponseDTO convertResponseMessage(CreateOnlinePaymentRequestDTO request, String response) throws ClarityMessagingException {
        try {
            StringBuilder strB = new StringBuilder(response);

            // Parse response message wrapper
            CreateOnlinePaymentResponseDTO createOnlinePaymentResponseDTO = parseRespMessageWrapper(request, CreateOnlinePaymentResponseDTO.class, response, strB);

            // Replace dummy primary bitmap responded from CLARITY, jPOS need actual primary bitmap for parsing message
            replaceRespBitmaps(request, response, createOnlinePaymentProp.getResponse().getPrimaryBitmap(), strB);

            // Parse ISO8583 message
            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.unpack(strB.toString().getBytes());

            createOnlinePaymentResponseDTO.setSystemAuditTrailNo(isoMsg.getString(11));
            createOnlinePaymentResponseDTO.setDateTime(isoMsg.getString(12));
            createOnlinePaymentResponseDTO.setActionCode(isoMsg.getString(39));
            createOnlinePaymentResponseDTO.setTerminalId(isoMsg.getString(41));

            String bit62Data = isoMsg.getString(62);
            Map<String, Object> dataMap = null;
            if(null != bit62Data && bit62Data.length() > 0) {
                StringBuilder strB62 = new StringBuilder(bit62Data);
                List<Map<String, Object>> dataList = parseRespFields(request, createOnlinePaymentProp.getResponse().getAdditionalData(), bit62Data, strB62);

                // Always take the first index for root object
                dataMap = dataList.get(0);
            } else {
                dataMap = new HashMap<>(0);
            }

            ObjectMapper mapper = new ObjectMapper();
            // Updating values to existing object
            mapper.readerForUpdating(createOnlinePaymentResponseDTO).readValue(mapper.writeValueAsBytes(dataMap));

            createOnlinePaymentResponseDTO.setMac(isoMsg.getString(64));

            return createOnlinePaymentResponseDTO;

        } catch (ISOException | IOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getCode(),
                ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }

    private void validateRequestData(CreateOnlinePaymentRequestDTO request) throws ClarityMessagingException {
        CreateOnlinePaymentProperties.RequestDataElement reqDataElement = createOnlinePaymentProp.getRequest().getDataElement();
        CreateOnlinePaymentProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();
        CreateOnlinePaymentProperties.RequestSmsData reqSmsData = reqDataElement.getSmsData();

        validateDataAgainstMap(request, reqDataElement.getProcessingCodes(), request.getCountryCode(), "ProcessingCode");
        validateDataAgainstMap(request, reqDataElement.getPointOfServices(), request.getCountryCode(), "PointOfService");
        validateDataAgainstMap(request, reqDataElement.getTerminalIds(), request.getCountryCode(), "TerminalId");
        validateDataAgainstList(request, reqDataElement.getServiceRestrictCodes(), request.getServiceRestrictCode(), "ServiceRestrictCode");

        if (request.getTacLength() != request.getTac().length()) {
            String errorDetails = String.format("TAC [%s] value length doesn't sync with request TAC length [%s]. txnRefId [%s]", request.getTac(), request.getTacLength(), request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        if(!TODAY_EFFECTIVE_DATE.equals(request.getEffectiveDate())) {
            validateDataAgainstDateFormat(request, "yyyyMMdd", request.getEffectiveDate(), "EffectiveDate");
        }

        if ((!TODAY_EFFECTIVE_DATE.equals(request.getEffectiveDate())
                && ("1".equals(request.getSmsAlertBit()) || "2".equals(request.getSmsAlertBit())))
                && (null == request.getSmsUserId() || null == request.getSelfNotifMobileNo() || null == request.getThirdPartyNotifMobileNo())) {
            String errorDetails = String.format("SmsUserId, SelfNotifMobileNo and ThirdPartyNotifMobileNo must not be NULL. txnRefId [%s]", request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        // Validate Additional Data
        validateAdditionalData(request, reqAdditionalData);
        validateDataAgainstList(request, reqAdditionalData.getServiceCodes(), request.getServiceCode(), "ServiceCode");

        // Validate SMS Data
        validateSmsData(request, reqSmsData);
        validateDataAgainstList(request, reqSmsData.getSmsAlertBits(), request.getSmsAlertBit(), "SmsAlertBit");
    }

    private void validateAdditionalData(CreateOnlinePaymentRequestDTO request, CreateOnlinePaymentProperties.RequestAdditionalData reqAdditionalData) throws ClarityMessagingException {
        Iso8583Utils.validateField(request.getFromAcctCode(), reqAdditionalData.getFromAcctCode());
        Iso8583Utils.validateField(request.getToAcctCode(), reqAdditionalData.getToAcctCode());
        Iso8583Utils.validateField(request.getPayeeCode(), reqAdditionalData.getPayeeCode());
        Iso8583Utils.validateField(request.getRefNo(), reqAdditionalData.getRefNo());
        Iso8583Utils.validateField(request.getThirdPartyAcctNo(), reqAdditionalData.getThirdPartyAcctNo());
        Iso8583Utils.validateField(request.getBillAcctNo(), reqAdditionalData.getBillAcctNo());
        Iso8583Utils.validateField(request.getRecipientRef(), reqAdditionalData.getRecipientRef());
        Iso8583Utils.validateField(request.getOtherPaymentDesc(), reqAdditionalData.getOtherPaymentDesc());
    }

    private void validateSmsData(CreateOnlinePaymentRequestDTO request, CreateOnlinePaymentProperties.RequestSmsData reqSmsData) throws ClarityMessagingException {
        Iso8583Utils.validateField(request.getSmsUserId(), reqSmsData.getSmsUserId());
        Iso8583Utils.validateField(request.getSelfNotifMobileNo(), reqSmsData.getSelfNotifMobileNo());
        Iso8583Utils.validateField(request.getThirdPartyNotifMobileNo(), reqSmsData.getThirdPartyNotifMobileNo());
    }

    private void updateRequestData(CreateOnlinePaymentRequestDTO request) {
        CreateOnlinePaymentProperties.RequestDataElement reqDataElement = createOnlinePaymentProp.getRequest().getDataElement();

        request.setFromAcctNo(Iso8583Utils.padFieldData(request.getFromAcctNo(), reqDataElement.getFromAcctNo()));

        if(null == request.getToAcctNo()) {
            request.setToAcctNo(reqDataElement.getToAcctNo().getDefaultVal());
        } else {
            // TODO: should we right pad zeros with max size 19? similar to from acct no.?
            request.setToAcctNo(Iso8583Utils.padFieldData(request.getToAcctNo(), reqDataElement.getToAcctNo()));
        }

        updateAdditionalData(request);
        updateSmsData(request);
    }

    private void updateAdditionalData(CreateOnlinePaymentRequestDTO request) {
        CreateOnlinePaymentProperties.RequestDataElement reqDataElement = createOnlinePaymentProp.getRequest().getDataElement();
        CreateOnlinePaymentProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();

        if (null == request.getRefNo()) {
            request.setRefNo(reqAdditionalData.getRefNo().getDefaultVal());
        } else {
            // TODO: if client set with value, should we perform padding? zeros or spaces? left or right?
            request.setRefNo(Iso8583Utils.padFieldData(request.getRefNo(), reqAdditionalData.getRefNo()));
        }

        // Right pad zeros for MBB acct no.
        request.setThirdPartyAcctNo(Iso8583Utils.padFieldData(request.getThirdPartyAcctNo(), reqAdditionalData.getThirdPartyAcctNo()));

        if (null == request.getBillAcctNo()) {
            request.setBillAcctNo(reqAdditionalData.getBillAcctNo().getDefaultVal());
        } else {
            // TODO: If it set and shorter than expected, should we pad it? with zeros or spaces? left or right?
            request.setBillAcctNo(Iso8583Utils.padFieldData(request.getBillAcctNo(), reqAdditionalData.getBillAcctNo()));
        }

        if (null == request.getRecipientRef()) {
            request.setRecipientRef(reqAdditionalData.getRecipientRef().getDefaultVal());
        } else {
            // TODO: If it set and shorter than expected, should we pad with spaces? left or right?
            request.setRecipientRef(Iso8583Utils.padFieldData(request.getRecipientRef(), reqAdditionalData.getRecipientRef()));
        }

        if (null == request.getOtherPaymentDesc()) {
            request.setOtherPaymentDesc(reqAdditionalData.getOtherPaymentDesc().getDefaultVal());
        } else {
            // TODO: If it set and shorter than expected, should we pad with spaces? left or right?
            request.setOtherPaymentDesc(Iso8583Utils.padFieldData(request.getOtherPaymentDesc(), reqAdditionalData.getOtherPaymentDesc()));
        }
    }

    private void updateSmsData(CreateOnlinePaymentRequestDTO request) {
        CreateOnlinePaymentProperties.RequestDataElement reqDataElement = createOnlinePaymentProp.getRequest().getDataElement();
        CreateOnlinePaymentProperties.RequestSmsData reqSmsData = reqDataElement.getSmsData();

        if (TODAY_EFFECTIVE_DATE.equals(request.getEffectiveDate()) && ("0".equals(request.getSmsAlertBit()))) {
            log.debug("[{}] EffectiveDate [{}] and SmsAlertBit [{}] condition detected, overwrite SmsUserId [{}], SelfNotifMobileNo [{}] and ThirdPartyNotifMobileNo [{}] to default values",
                request.getTxnRefId(), request.getEffectiveDate(), request.getSmsAlertBit(),
                    request.getSmsUserId(), request.getSelfNotifMobileNo(), request.getThirdPartyNotifMobileNo());
            request.setSmsUserId(reqSmsData.getSmsUserId().getDefaultVal());
            request.setSelfNotifMobileNo(reqSmsData.getSelfNotifMobileNo().getDefaultVal());
            request.setThirdPartyNotifMobileNo(reqSmsData.getThirdPartyNotifMobileNo().getDefaultVal());
        } else {
            // TODO: should we do padding? zeros or spaces? left or right?
            request.setSmsUserId(Iso8583Utils.padFieldData(request.getSmsUserId(), reqSmsData.getSmsUserId()));
            request.setSelfNotifMobileNo(Iso8583Utils.padFieldData(request.getSelfNotifMobileNo(), reqSmsData.getSelfNotifMobileNo()));
            request.setThirdPartyNotifMobileNo(Iso8583Utils.padFieldData(request.getThirdPartyNotifMobileNo(), reqSmsData.getThirdPartyNotifMobileNo()));
        }
    }
}
