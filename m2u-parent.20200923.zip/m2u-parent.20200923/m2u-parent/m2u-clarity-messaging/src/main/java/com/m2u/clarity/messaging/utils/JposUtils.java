package com.m2u.clarity.messaging.utils;

import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import lombok.extern.slf4j.Slf4j;
import org.jpos.iso.ISOException;
import org.jpos.iso.packager.GenericPackager;

@Slf4j
public final class JposUtils {

    private JposUtils() {
    }

    public static GenericPackager setupPackager(String config) throws ClarityMessagingException {
        try {
            return new GenericPackager(JposUtils.class.getClassLoader().getResourceAsStream(config));
        } catch (ISOException e) {
            log.error(ErrorTemplate.TEMPLATE_4,
                ClarityMessagingStatus.JPOS_PACKAGER_CREATION_FAILED.getCode(),
                ClarityMessagingStatus.JPOS_PACKAGER_CREATION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.JPOS_PACKAGER_CREATION_FAILED, e.getMessage(), e);
        }
    }
}
