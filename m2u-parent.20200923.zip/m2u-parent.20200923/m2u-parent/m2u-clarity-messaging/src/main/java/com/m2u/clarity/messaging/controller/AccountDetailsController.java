package com.m2u.clarity.messaging.controller;

import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.GetAccountDetailsRequestDTO;
import com.m2u.clarity.messaging.dto.GetAccountDetailsResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.service.AccountDetailsMessagingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class AccountDetailsController extends AbstractController {

    @Autowired
    private AccountDetailsMessagingService accountDetailsMessagingService;

    @GetMapping(
            path="/v1/account-details",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<GetAccountDetailsResponseDTO> getAccountDetails(@RequestBody GetAccountDetailsRequestDTO request) {
        log.debug("[{}] REQ [{}]", request.getTxnRefId(), request);
        try {
            GetAccountDetailsResponseDTO response = accountDetailsMessagingService.getAccountDetails(request);
            log.debug("[{}] RESP [{}]", request.getTxnRefId(), response);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ClarityMessagingException e) {
            return new ResponseEntity<>(
                createErrorResponse(GetAccountDetailsResponseDTO.class, request, e.getStatusCode(), e.getMessage()),
                HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.UNEXPECTED_EXCEPTION.getCode(),
                ClarityMessagingStatus.UNEXPECTED_EXCEPTION.getDesc(), e);
            return new ResponseEntity<>(
                createErrorResponse(GetAccountDetailsResponseDTO.class, request, ClarityMessagingStatus.UNEXPECTED_EXCEPTION, e.getMessage()),
                HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
