package com.m2u.clarity.messaging.enums;

public enum ClarityMessagingStatus {

    // Positive Status Code
    SUCCESS ("10000", "Success"),

    // Negative Status Code
    // COMMON
    UNEXPECTED_EXCEPTION ("30000", "Unexpected exception detected"),
    INVALID_REQUEST_DATA ("30001", "Invalid request data detected"),
    INVALID_RESPONSE_DATA ("30002", "Invalid response data detected"),
    INVALID_CONFIGURATION ("30003", "Invalid configuration detected"),
    INVALID_DATA ("30004", "Invalid data detected"),

    // JPOS
    JPOS_PACKAGER_CREATION_FAILED("30100", "JPOS packager creation failed"),

    // ISO8583
    ISO8583_REQ_MESSAGE_CONVERSION_FAILED ("30200", "ISO8583 request message conversion failed"),
    ISO8583_RESP_MESSAGE_CONVERSION_FAILED ("30201", "ISO8583 response message conversion failed"),

    // TCP
    TCP_MESSAGE_SEND_FAILED ("30300", "TCP message sending failed"),
    ;

    private String code;
    private String desc;

    ClarityMessagingStatus(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
