package com.m2u.clarity.messaging.service;

import com.m2u.clarity.messaging.dto.CreateBillPaymentRequestDTO;
import com.m2u.clarity.messaging.dto.CreateBillPaymentResponseDTO;
import com.m2u.clarity.messaging.dto.CreateOnlinePaymentRequestDTO;
import com.m2u.clarity.messaging.dto.CreateOnlinePaymentResponseDTO;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;

public interface PaymentMessagingService {

    CreateOnlinePaymentResponseDTO createOnlinePayment(CreateOnlinePaymentRequestDTO request) throws ClarityMessagingException;
    CreateBillPaymentResponseDTO createBillPayment(CreateBillPaymentRequestDTO request) throws ClarityMessagingException;
}
