package com.m2u.clarity.messaging.config;

import com.m2u.clarity.messaging.properties.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.*;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.ip.tcp.TcpOutboundGateway;
import org.springframework.integration.ip.tcp.connection.AbstractClientConnectionFactory;
import org.springframework.integration.ip.tcp.connection.FailoverClientConnectionFactory;
import org.springframework.integration.ip.tcp.connection.TcpNetClientConnectionFactory;
import org.springframework.integration.ip.tcp.serializer.ByteArrayRawSerializer;
import org.springframework.integration.ip.tcp.serializer.ByteArraySingleTerminatorSerializer;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@IntegrationComponentScan
@EnableConfigurationProperties({
    TCPMessagingProperties.class,
    ClarityCommonProperties.class,
    GetLogonProperties.class,
    CreateTACProperties.class,
    CreateOnlinePaymentProperties.class,
    CreateBillPaymentProperties.class,
    GetAccountDetailsProperties.class
})
@Configuration
public class ClarityMessagingConfiguration {

    @Autowired
    private TCPMessagingProperties tcpMessagingProp;

    @Bean
    @ServiceActivator(inputChannel = "tcpOutChannel")
    public MessageHandler tcpOutGateway(AbstractClientConnectionFactory ccf) {
        TcpOutboundGateway tcpOutGateway = new TcpOutboundGateway();
        tcpOutGateway.setConnectionFactory(ccf);
        tcpOutGateway.setRequestTimeout(tcpMessagingProp.getClient().getRequestTimeout());
        tcpOutGateway.setRemoteTimeout(tcpMessagingProp.getClient().getRemoteTimeout());
        tcpOutGateway.setOutputChannelName("tcpInChannel");
        return tcpOutGateway;
    }

    @MessagingGateway(defaultRequestChannel = "tcpOutChannel")
    public interface TCPGateway {
        String sendMessage(String message);
    }

    @Bean(name = "tcpInChannel")
    public MessageChannel tcpInChannel() {
        return new DirectChannel();
    }

    @MessageEndpoint
    public static class TcpMessageEndpoint {
        @Transformer(inputChannel = "tcpInChannel")
        public String convertResult(byte[] bytes) {
            return new String(bytes, StandardCharsets.UTF_8);
        }
    }

    @Bean
    public AbstractClientConnectionFactory tcpClientCf() {
        List<AbstractClientConnectionFactory> tcpClientCfs = new ArrayList<>();

        // Support multiple TCP clients for failover
        for(TCPMessagingProperties.Server server : tcpMessagingProp.getServer()) {
            AbstractClientConnectionFactory tcpClientCf
                    = new TcpNetClientConnectionFactory(server.getHost(), server.getPort());

            // Default serializer/deserializer (e.g. ByteArrayCrLfSerializer) might not work with all TCP server, e.g. Clarity required ByteArrayRawSerializer
            // Clarity API will required FF (HEX) message ending, due to that we set as below;
            byte delimiter = -1;
            ByteArraySingleTerminatorSerializer serializer1 = new ByteArraySingleTerminatorSerializer(delimiter);
            tcpClientCf.setSerializer(serializer1);

            ByteArrayRawSerializer serializer = new ByteArrayRawSerializer();
            tcpClientCf.setDeserializer(serializer);

            // If TRUE, reverse lookup is done on remote ip address which could cause delay in TCP client in getting response sometime
            tcpClientCf.setLookupHost(false);

            // Do noting for now, just to avoid warning log
            tcpClientCf.setApplicationEventPublisher(x -> {});

            // For non multithreaded TCP server, we need to create socket connection per request with singleUse = TRUE
            tcpClientCf.setSingleUse(true);
            tcpClientCfs.add(tcpClientCf);
        }

        AbstractClientConnectionFactory failoverClientCf = new FailoverClientConnectionFactory(tcpClientCfs);
        failoverClientCf.setSingleUse(true);

        return failoverClientCf;
    }
}
