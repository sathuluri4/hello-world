package com.m2u.clarity.messaging.enums;

public enum Country {

    MALAYSIA ("MY" ),
    SINGAPORE ("SG"),
    ;

    private String countryCode;

    Country(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryCode() {
        return countryCode;
    }
}
