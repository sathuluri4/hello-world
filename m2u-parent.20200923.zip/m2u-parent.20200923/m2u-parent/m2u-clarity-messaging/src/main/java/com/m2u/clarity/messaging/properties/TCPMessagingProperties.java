package com.m2u.clarity.messaging.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

@ConfigurationProperties(prefix="m2u.clarity.messaging.tcp")
@Data
public class TCPMessagingProperties {

    private List<Server> server = new ArrayList<>();
    private final Client client = new Client();

    @Data
    public static class Server {
        private String host;
        private int port;
    }

    @Data
    public static class Client {
        private int requestTimeout = 10000;
        private int remoteTimeout = 10000;
        private int poolSize;
    }
}
