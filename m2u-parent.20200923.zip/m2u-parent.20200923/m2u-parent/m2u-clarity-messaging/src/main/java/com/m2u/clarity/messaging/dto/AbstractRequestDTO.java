package com.m2u.clarity.messaging.dto;

import lombok.Data;

@Data
public abstract class AbstractRequestDTO {

    protected String userId;
    protected String pan;
    protected String creationDateTime;
    protected String txnRefId;
    private String countryCode;
}
