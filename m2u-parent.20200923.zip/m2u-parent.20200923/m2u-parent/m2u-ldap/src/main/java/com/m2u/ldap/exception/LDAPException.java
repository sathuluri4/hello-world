package com.m2u.ldap.exception;

public class LDAPException extends Exception {

    public LDAPException(String message) {
        super(message);
    }

    public LDAPException(String message, Throwable e) {
        super(message, e);
    }
}
