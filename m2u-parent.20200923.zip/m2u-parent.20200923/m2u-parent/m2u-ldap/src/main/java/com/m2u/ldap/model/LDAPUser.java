package com.m2u.ldap.model;

import lombok.Data;

@Data
public class LDAPUser {

    private String mbbUserId;
    private String group;
    private String pan;
}
