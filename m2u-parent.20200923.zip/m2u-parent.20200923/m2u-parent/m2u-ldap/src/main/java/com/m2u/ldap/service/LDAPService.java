package com.m2u.ldap.service;

import com.m2u.ldap.exception.LDAPException;
import com.m2u.ldap.model.LDAPUser;

public interface LDAPService {

    LDAPUser getLDAPUser(String username) throws LDAPException;
    LDAPUser authenticateLDAPUser(String username, String password) throws LDAPException;
}
