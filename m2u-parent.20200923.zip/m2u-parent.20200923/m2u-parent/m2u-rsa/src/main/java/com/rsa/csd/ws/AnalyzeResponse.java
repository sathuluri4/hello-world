/**
 * AnalyzeResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;

public class AnalyzeResponse  extends com.rsa.csd.ws.GenericResponse  implements java.io.Serializable {
    private com.rsa.csd.ws.CollectableCredentialList collectableCredentialList;

    private com.rsa.csd.ws.CredentialAuthResultList credentialAuthResultList;

    private com.rsa.csd.ws.DeviceManagementResponsePayload deviceManagementResponse;

    private com.rsa.csd.ws.RequiredCredentialList requiredCredentialList;

    private com.rsa.csd.ws.RiskResult riskResult;

    private com.rsa.csd.ws.ServerRedirectData serverRedirectData;

    public AnalyzeResponse() {
    }

    public AnalyzeResponse(
           com.rsa.csd.ws.DeviceResult deviceResult,
           com.rsa.csd.ws.IdentificationData identificationData,
           com.rsa.csd.ws.MessageHeader messageHeader,
           com.rsa.csd.ws.StatusHeader statusHeader,
           com.rsa.csd.ws.CollectableCredentialList collectableCredentialList,
           com.rsa.csd.ws.CredentialAuthResultList credentialAuthResultList,
           com.rsa.csd.ws.DeviceManagementResponsePayload deviceManagementResponse,
           com.rsa.csd.ws.RequiredCredentialList requiredCredentialList,
           com.rsa.csd.ws.RiskResult riskResult,
           com.rsa.csd.ws.ServerRedirectData serverRedirectData) {
        super(
            deviceResult,
            identificationData,
            messageHeader,
            statusHeader);
        this.collectableCredentialList = collectableCredentialList;
        this.credentialAuthResultList = credentialAuthResultList;
        this.deviceManagementResponse = deviceManagementResponse;
        this.requiredCredentialList = requiredCredentialList;
        this.riskResult = riskResult;
        this.serverRedirectData = serverRedirectData;
    }


    /**
     * Gets the collectableCredentialList value for this AnalyzeResponse.
     * 
     * @return collectableCredentialList
     */
    public com.rsa.csd.ws.CollectableCredentialList getCollectableCredentialList() {
        return collectableCredentialList;
    }


    /**
     * Sets the collectableCredentialList value for this AnalyzeResponse.
     * 
     * @param collectableCredentialList
     */
    public void setCollectableCredentialList(com.rsa.csd.ws.CollectableCredentialList collectableCredentialList) {
        this.collectableCredentialList = collectableCredentialList;
    }


    /**
     * Gets the credentialAuthResultList value for this AnalyzeResponse.
     * 
     * @return credentialAuthResultList
     */
    public com.rsa.csd.ws.CredentialAuthResultList getCredentialAuthResultList() {
        return credentialAuthResultList;
    }


    /**
     * Sets the credentialAuthResultList value for this AnalyzeResponse.
     * 
     * @param credentialAuthResultList
     */
    public void setCredentialAuthResultList(com.rsa.csd.ws.CredentialAuthResultList credentialAuthResultList) {
        this.credentialAuthResultList = credentialAuthResultList;
    }


    /**
     * Gets the deviceManagementResponse value for this AnalyzeResponse.
     * 
     * @return deviceManagementResponse
     */
    public com.rsa.csd.ws.DeviceManagementResponsePayload getDeviceManagementResponse() {
        return deviceManagementResponse;
    }


    /**
     * Sets the deviceManagementResponse value for this AnalyzeResponse.
     * 
     * @param deviceManagementResponse
     */
    public void setDeviceManagementResponse(com.rsa.csd.ws.DeviceManagementResponsePayload deviceManagementResponse) {
        this.deviceManagementResponse = deviceManagementResponse;
    }


    /**
     * Gets the requiredCredentialList value for this AnalyzeResponse.
     * 
     * @return requiredCredentialList
     */
    public com.rsa.csd.ws.RequiredCredentialList getRequiredCredentialList() {
        return requiredCredentialList;
    }


    /**
     * Sets the requiredCredentialList value for this AnalyzeResponse.
     * 
     * @param requiredCredentialList
     */
    public void setRequiredCredentialList(com.rsa.csd.ws.RequiredCredentialList requiredCredentialList) {
        this.requiredCredentialList = requiredCredentialList;
    }


    /**
     * Gets the riskResult value for this AnalyzeResponse.
     * 
     * @return riskResult
     */
    public com.rsa.csd.ws.RiskResult getRiskResult() {
        return riskResult;
    }


    /**
     * Sets the riskResult value for this AnalyzeResponse.
     * 
     * @param riskResult
     */
    public void setRiskResult(com.rsa.csd.ws.RiskResult riskResult) {
        this.riskResult = riskResult;
    }


    /**
     * Gets the serverRedirectData value for this AnalyzeResponse.
     * 
     * @return serverRedirectData
     */
    public com.rsa.csd.ws.ServerRedirectData getServerRedirectData() {
        return serverRedirectData;
    }


    /**
     * Sets the serverRedirectData value for this AnalyzeResponse.
     * 
     * @param serverRedirectData
     */
    public void setServerRedirectData(com.rsa.csd.ws.ServerRedirectData serverRedirectData) {
        this.serverRedirectData = serverRedirectData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AnalyzeResponse)) return false;
        AnalyzeResponse other = (AnalyzeResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.collectableCredentialList==null && other.getCollectableCredentialList()==null) || 
             (this.collectableCredentialList!=null &&
              this.collectableCredentialList.equals(other.getCollectableCredentialList()))) &&
            ((this.credentialAuthResultList==null && other.getCredentialAuthResultList()==null) || 
             (this.credentialAuthResultList!=null &&
              this.credentialAuthResultList.equals(other.getCredentialAuthResultList()))) &&
            ((this.deviceManagementResponse==null && other.getDeviceManagementResponse()==null) || 
             (this.deviceManagementResponse!=null &&
              this.deviceManagementResponse.equals(other.getDeviceManagementResponse()))) &&
            ((this.requiredCredentialList==null && other.getRequiredCredentialList()==null) || 
             (this.requiredCredentialList!=null &&
              this.requiredCredentialList.equals(other.getRequiredCredentialList()))) &&
            ((this.riskResult==null && other.getRiskResult()==null) || 
             (this.riskResult!=null &&
              this.riskResult.equals(other.getRiskResult()))) &&
            ((this.serverRedirectData==null && other.getServerRedirectData()==null) || 
             (this.serverRedirectData!=null &&
              this.serverRedirectData.equals(other.getServerRedirectData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCollectableCredentialList() != null) {
            _hashCode += getCollectableCredentialList().hashCode();
        }
        if (getCredentialAuthResultList() != null) {
            _hashCode += getCredentialAuthResultList().hashCode();
        }
        if (getDeviceManagementResponse() != null) {
            _hashCode += getDeviceManagementResponse().hashCode();
        }
        if (getRequiredCredentialList() != null) {
            _hashCode += getRequiredCredentialList().hashCode();
        }
        if (getRiskResult() != null) {
            _hashCode += getRiskResult().hashCode();
        }
        if (getServerRedirectData() != null) {
            _hashCode += getServerRedirectData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AnalyzeResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AnalyzeResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("collectableCredentialList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "collectableCredentialList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CollectableCredentialList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("credentialAuthResultList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "credentialAuthResultList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialAuthResultList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceManagementResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "deviceManagementResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceManagementResponsePayload"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requiredCredentialList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "requiredCredentialList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "RequiredCredentialList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("riskResult");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "riskResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "RiskResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverRedirectData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "serverRedirectData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ServerRedirectData"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
