/**
 * CollectionRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;


/**
 * This describes why a collection is being initiated and the reasons
 * behind it
 */
public class CollectionRequest  implements java.io.Serializable {
    private com.rsa.csd.ws.CollectionInitiator collectionInitiator;

    private com.rsa.csd.ws.CollectionReason collectionReason;

    private java.lang.Boolean forceCollection;

    private com.rsa.csd.ws.CredentialList orgCredentialList;

    public CollectionRequest() {
    }

    public CollectionRequest(
           com.rsa.csd.ws.CollectionInitiator collectionInitiator,
           com.rsa.csd.ws.CollectionReason collectionReason,
           java.lang.Boolean forceCollection,
           com.rsa.csd.ws.CredentialList orgCredentialList) {
           this.collectionInitiator = collectionInitiator;
           this.collectionReason = collectionReason;
           this.forceCollection = forceCollection;
           this.orgCredentialList = orgCredentialList;
    }


    /**
     * Gets the collectionInitiator value for this CollectionRequest.
     * 
     * @return collectionInitiator
     */
    public com.rsa.csd.ws.CollectionInitiator getCollectionInitiator() {
        return collectionInitiator;
    }


    /**
     * Sets the collectionInitiator value for this CollectionRequest.
     * 
     * @param collectionInitiator
     */
    public void setCollectionInitiator(com.rsa.csd.ws.CollectionInitiator collectionInitiator) {
        this.collectionInitiator = collectionInitiator;
    }


    /**
     * Gets the collectionReason value for this CollectionRequest.
     * 
     * @return collectionReason
     */
    public com.rsa.csd.ws.CollectionReason getCollectionReason() {
        return collectionReason;
    }


    /**
     * Sets the collectionReason value for this CollectionRequest.
     * 
     * @param collectionReason
     */
    public void setCollectionReason(com.rsa.csd.ws.CollectionReason collectionReason) {
        this.collectionReason = collectionReason;
    }


    /**
     * Gets the forceCollection value for this CollectionRequest.
     * 
     * @return forceCollection
     */
    public java.lang.Boolean getForceCollection() {
        return forceCollection;
    }


    /**
     * Sets the forceCollection value for this CollectionRequest.
     * 
     * @param forceCollection
     */
    public void setForceCollection(java.lang.Boolean forceCollection) {
        this.forceCollection = forceCollection;
    }


    /**
     * Gets the orgCredentialList value for this CollectionRequest.
     * 
     * @return orgCredentialList
     */
    public com.rsa.csd.ws.CredentialList getOrgCredentialList() {
        return orgCredentialList;
    }


    /**
     * Sets the orgCredentialList value for this CollectionRequest.
     * 
     * @param orgCredentialList
     */
    public void setOrgCredentialList(com.rsa.csd.ws.CredentialList orgCredentialList) {
        this.orgCredentialList = orgCredentialList;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CollectionRequest)) return false;
        CollectionRequest other = (CollectionRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.collectionInitiator==null && other.getCollectionInitiator()==null) || 
             (this.collectionInitiator!=null &&
              this.collectionInitiator.equals(other.getCollectionInitiator()))) &&
            ((this.collectionReason==null && other.getCollectionReason()==null) || 
             (this.collectionReason!=null &&
              this.collectionReason.equals(other.getCollectionReason()))) &&
            ((this.forceCollection==null && other.getForceCollection()==null) || 
             (this.forceCollection!=null &&
              this.forceCollection.equals(other.getForceCollection()))) &&
            ((this.orgCredentialList==null && other.getOrgCredentialList()==null) || 
             (this.orgCredentialList!=null &&
              this.orgCredentialList.equals(other.getOrgCredentialList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCollectionInitiator() != null) {
            _hashCode += getCollectionInitiator().hashCode();
        }
        if (getCollectionReason() != null) {
            _hashCode += getCollectionReason().hashCode();
        }
        if (getForceCollection() != null) {
            _hashCode += getForceCollection().hashCode();
        }
        if (getOrgCredentialList() != null) {
            _hashCode += getOrgCredentialList().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CollectionRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CollectionRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("collectionInitiator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "collectionInitiator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CollectionInitiator"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("collectionReason");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "collectionReason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CollectionReason"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("forceCollection");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "forceCollection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orgCredentialList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "orgCredentialList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
