package com.m2u.rsa.dto;

import lombok.Data;

@Data
public abstract class AbtractAdaptResponseDTO {

    private int statusCode;
    private int reasonCode;
    private String desc;
    private String deviceTokenCookie;
    private String deviceTokenFSO;
}
