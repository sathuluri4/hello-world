/**
 * CredentialAuthStatusResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;

public class CredentialAuthStatusResponse  extends com.rsa.csd.ws.CredentialResponseList  implements java.io.Serializable {
    private com.rsa.csd.ws.ChallengeQuestionAuthStatusResponse challengeQuestionAuthStatusResponse;

    private com.rsa.csd.ws.OobEmailAuthStatusResponse oobEmailAuthStatusResponse;

    private com.rsa.csd.ws.OobPhoneAuthStatusResponse oobPhoneAuthStatusResponse;

    private com.rsa.csd.ws.AcspAuthStatusResponseData acspAuthStatusResponseData;

    public CredentialAuthStatusResponse() {
    }

    public CredentialAuthStatusResponse(
           com.rsa.csd.ws.ChallengeQuestionAuthStatusResponse challengeQuestionAuthStatusResponse,
           com.rsa.csd.ws.OobEmailAuthStatusResponse oobEmailAuthStatusResponse,
           com.rsa.csd.ws.OobPhoneAuthStatusResponse oobPhoneAuthStatusResponse,
           com.rsa.csd.ws.AcspAuthStatusResponseData acspAuthStatusResponseData) {
        this.challengeQuestionAuthStatusResponse = challengeQuestionAuthStatusResponse;
        this.oobEmailAuthStatusResponse = oobEmailAuthStatusResponse;
        this.oobPhoneAuthStatusResponse = oobPhoneAuthStatusResponse;
        this.acspAuthStatusResponseData = acspAuthStatusResponseData;
    }


    /**
     * Gets the challengeQuestionAuthStatusResponse value for this CredentialAuthStatusResponse.
     * 
     * @return challengeQuestionAuthStatusResponse
     */
    public com.rsa.csd.ws.ChallengeQuestionAuthStatusResponse getChallengeQuestionAuthStatusResponse() {
        return challengeQuestionAuthStatusResponse;
    }


    /**
     * Sets the challengeQuestionAuthStatusResponse value for this CredentialAuthStatusResponse.
     * 
     * @param challengeQuestionAuthStatusResponse
     */
    public void setChallengeQuestionAuthStatusResponse(com.rsa.csd.ws.ChallengeQuestionAuthStatusResponse challengeQuestionAuthStatusResponse) {
        this.challengeQuestionAuthStatusResponse = challengeQuestionAuthStatusResponse;
    }


    /**
     * Gets the oobEmailAuthStatusResponse value for this CredentialAuthStatusResponse.
     * 
     * @return oobEmailAuthStatusResponse
     */
    public com.rsa.csd.ws.OobEmailAuthStatusResponse getOobEmailAuthStatusResponse() {
        return oobEmailAuthStatusResponse;
    }


    /**
     * Sets the oobEmailAuthStatusResponse value for this CredentialAuthStatusResponse.
     * 
     * @param oobEmailAuthStatusResponse
     */
    public void setOobEmailAuthStatusResponse(com.rsa.csd.ws.OobEmailAuthStatusResponse oobEmailAuthStatusResponse) {
        this.oobEmailAuthStatusResponse = oobEmailAuthStatusResponse;
    }


    /**
     * Gets the oobPhoneAuthStatusResponse value for this CredentialAuthStatusResponse.
     * 
     * @return oobPhoneAuthStatusResponse
     */
    public com.rsa.csd.ws.OobPhoneAuthStatusResponse getOobPhoneAuthStatusResponse() {
        return oobPhoneAuthStatusResponse;
    }


    /**
     * Sets the oobPhoneAuthStatusResponse value for this CredentialAuthStatusResponse.
     * 
     * @param oobPhoneAuthStatusResponse
     */
    public void setOobPhoneAuthStatusResponse(com.rsa.csd.ws.OobPhoneAuthStatusResponse oobPhoneAuthStatusResponse) {
        this.oobPhoneAuthStatusResponse = oobPhoneAuthStatusResponse;
    }


    /**
     * Gets the acspAuthStatusResponseData value for this CredentialAuthStatusResponse.
     * 
     * @return acspAuthStatusResponseData
     */
    public com.rsa.csd.ws.AcspAuthStatusResponseData getAcspAuthStatusResponseData() {
        return acspAuthStatusResponseData;
    }


    /**
     * Sets the acspAuthStatusResponseData value for this CredentialAuthStatusResponse.
     * 
     * @param acspAuthStatusResponseData
     */
    public void setAcspAuthStatusResponseData(com.rsa.csd.ws.AcspAuthStatusResponseData acspAuthStatusResponseData) {
        this.acspAuthStatusResponseData = acspAuthStatusResponseData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CredentialAuthStatusResponse)) return false;
        CredentialAuthStatusResponse other = (CredentialAuthStatusResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.challengeQuestionAuthStatusResponse==null && other.getChallengeQuestionAuthStatusResponse()==null) || 
             (this.challengeQuestionAuthStatusResponse!=null &&
              this.challengeQuestionAuthStatusResponse.equals(other.getChallengeQuestionAuthStatusResponse()))) &&
            ((this.oobEmailAuthStatusResponse==null && other.getOobEmailAuthStatusResponse()==null) || 
             (this.oobEmailAuthStatusResponse!=null &&
              this.oobEmailAuthStatusResponse.equals(other.getOobEmailAuthStatusResponse()))) &&
            ((this.oobPhoneAuthStatusResponse==null && other.getOobPhoneAuthStatusResponse()==null) || 
             (this.oobPhoneAuthStatusResponse!=null &&
              this.oobPhoneAuthStatusResponse.equals(other.getOobPhoneAuthStatusResponse()))) &&
            ((this.acspAuthStatusResponseData==null && other.getAcspAuthStatusResponseData()==null) || 
             (this.acspAuthStatusResponseData!=null &&
              this.acspAuthStatusResponseData.equals(other.getAcspAuthStatusResponseData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getChallengeQuestionAuthStatusResponse() != null) {
            _hashCode += getChallengeQuestionAuthStatusResponse().hashCode();
        }
        if (getOobEmailAuthStatusResponse() != null) {
            _hashCode += getOobEmailAuthStatusResponse().hashCode();
        }
        if (getOobPhoneAuthStatusResponse() != null) {
            _hashCode += getOobPhoneAuthStatusResponse().hashCode();
        }
        if (getAcspAuthStatusResponseData() != null) {
            _hashCode += getAcspAuthStatusResponseData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CredentialAuthStatusResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialAuthStatusResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("challengeQuestionAuthStatusResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "challengeQuestionAuthStatusResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionAuthStatusResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oobEmailAuthStatusResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "oobEmailAuthStatusResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobEmailAuthStatusResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oobPhoneAuthStatusResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "oobPhoneAuthStatusResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobPhoneAuthStatusResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acspAuthStatusResponseData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "acspAuthStatusResponseData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspAuthStatusResponseData"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
