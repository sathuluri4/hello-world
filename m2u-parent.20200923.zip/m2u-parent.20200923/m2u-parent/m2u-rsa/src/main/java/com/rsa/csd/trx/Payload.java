/**
 * Payload.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.trx;


/**
 * This type defines the transaction payload
 */
public class Payload  implements java.io.Serializable {
    private java.lang.String amount;

    private java.lang.String currency;

    private java.lang.String dueDate;

    private com.rsa.csd.ws.ExecutionSpeed executionSpeed;

    private java.lang.String recurringFrequency;

    private com.rsa.csd.ws.Schedule schedule;

    private java.lang.String fromAccountNickname;

    private java.lang.String fromAccountNumber;

    private java.lang.String payeeName;

    private java.lang.String payeeAccountNumber;

    private java.lang.String internationalAccountNumber;

    private com.rsa.csd.ws.OtherAccountOwnershipType payeeAccountOwnershipType;

    private com.rsa.csd.ws.OtherAccountType payeeAccountType;

    private com.rsa.csd.ws.OtherAccountBankType payeeAccountBankType;

    private java.lang.String payeeRoutingCode;

    private java.lang.String payeeAccountCountry;

    private java.lang.String payeeReferenceCode;

    private com.rsa.csd.ws.TransferMediumType transferMediumType;

    private java.lang.String customField;

    public Payload() {
    }

    public Payload(
           java.lang.String amount,
           java.lang.String currency,
           java.lang.String dueDate,
           com.rsa.csd.ws.ExecutionSpeed executionSpeed,
           java.lang.String recurringFrequency,
           com.rsa.csd.ws.Schedule schedule,
           java.lang.String fromAccountNickname,
           java.lang.String fromAccountNumber,
           java.lang.String payeeName,
           java.lang.String payeeAccountNumber,
           java.lang.String internationalAccountNumber,
           com.rsa.csd.ws.OtherAccountOwnershipType payeeAccountOwnershipType,
           com.rsa.csd.ws.OtherAccountType payeeAccountType,
           com.rsa.csd.ws.OtherAccountBankType payeeAccountBankType,
           java.lang.String payeeRoutingCode,
           java.lang.String payeeAccountCountry,
           java.lang.String payeeReferenceCode,
           com.rsa.csd.ws.TransferMediumType transferMediumType,
           java.lang.String customField) {
           this.amount = amount;
           this.currency = currency;
           this.dueDate = dueDate;
           this.executionSpeed = executionSpeed;
           this.recurringFrequency = recurringFrequency;
           this.schedule = schedule;
           this.fromAccountNickname = fromAccountNickname;
           this.fromAccountNumber = fromAccountNumber;
           this.payeeName = payeeName;
           this.payeeAccountNumber = payeeAccountNumber;
           this.internationalAccountNumber = internationalAccountNumber;
           this.payeeAccountOwnershipType = payeeAccountOwnershipType;
           this.payeeAccountType = payeeAccountType;
           this.payeeAccountBankType = payeeAccountBankType;
           this.payeeRoutingCode = payeeRoutingCode;
           this.payeeAccountCountry = payeeAccountCountry;
           this.payeeReferenceCode = payeeReferenceCode;
           this.transferMediumType = transferMediumType;
           this.customField = customField;
    }


    /**
     * Gets the amount value for this Payload.
     * 
     * @return amount
     */
    public java.lang.String getAmount() {
        return amount;
    }


    /**
     * Sets the amount value for this Payload.
     * 
     * @param amount
     */
    public void setAmount(java.lang.String amount) {
        this.amount = amount;
    }


    /**
     * Gets the currency value for this Payload.
     * 
     * @return currency
     */
    public java.lang.String getCurrency() {
        return currency;
    }


    /**
     * Sets the currency value for this Payload.
     * 
     * @param currency
     */
    public void setCurrency(java.lang.String currency) {
        this.currency = currency;
    }


    /**
     * Gets the dueDate value for this Payload.
     * 
     * @return dueDate
     */
    public java.lang.String getDueDate() {
        return dueDate;
    }


    /**
     * Sets the dueDate value for this Payload.
     * 
     * @param dueDate
     */
    public void setDueDate(java.lang.String dueDate) {
        this.dueDate = dueDate;
    }


    /**
     * Gets the executionSpeed value for this Payload.
     * 
     * @return executionSpeed
     */
    public com.rsa.csd.ws.ExecutionSpeed getExecutionSpeed() {
        return executionSpeed;
    }


    /**
     * Sets the executionSpeed value for this Payload.
     * 
     * @param executionSpeed
     */
    public void setExecutionSpeed(com.rsa.csd.ws.ExecutionSpeed executionSpeed) {
        this.executionSpeed = executionSpeed;
    }


    /**
     * Gets the recurringFrequency value for this Payload.
     * 
     * @return recurringFrequency
     */
    public java.lang.String getRecurringFrequency() {
        return recurringFrequency;
    }


    /**
     * Sets the recurringFrequency value for this Payload.
     * 
     * @param recurringFrequency
     */
    public void setRecurringFrequency(java.lang.String recurringFrequency) {
        this.recurringFrequency = recurringFrequency;
    }


    /**
     * Gets the schedule value for this Payload.
     * 
     * @return schedule
     */
    public com.rsa.csd.ws.Schedule getSchedule() {
        return schedule;
    }


    /**
     * Sets the schedule value for this Payload.
     * 
     * @param schedule
     */
    public void setSchedule(com.rsa.csd.ws.Schedule schedule) {
        this.schedule = schedule;
    }


    /**
     * Gets the fromAccountNickname value for this Payload.
     * 
     * @return fromAccountNickname
     */
    public java.lang.String getFromAccountNickname() {
        return fromAccountNickname;
    }


    /**
     * Sets the fromAccountNickname value for this Payload.
     * 
     * @param fromAccountNickname
     */
    public void setFromAccountNickname(java.lang.String fromAccountNickname) {
        this.fromAccountNickname = fromAccountNickname;
    }


    /**
     * Gets the fromAccountNumber value for this Payload.
     * 
     * @return fromAccountNumber
     */
    public java.lang.String getFromAccountNumber() {
        return fromAccountNumber;
    }


    /**
     * Sets the fromAccountNumber value for this Payload.
     * 
     * @param fromAccountNumber
     */
    public void setFromAccountNumber(java.lang.String fromAccountNumber) {
        this.fromAccountNumber = fromAccountNumber;
    }


    /**
     * Gets the payeeName value for this Payload.
     * 
     * @return payeeName
     */
    public java.lang.String getPayeeName() {
        return payeeName;
    }


    /**
     * Sets the payeeName value for this Payload.
     * 
     * @param payeeName
     */
    public void setPayeeName(java.lang.String payeeName) {
        this.payeeName = payeeName;
    }


    /**
     * Gets the payeeAccountNumber value for this Payload.
     * 
     * @return payeeAccountNumber
     */
    public java.lang.String getPayeeAccountNumber() {
        return payeeAccountNumber;
    }


    /**
     * Sets the payeeAccountNumber value for this Payload.
     * 
     * @param payeeAccountNumber
     */
    public void setPayeeAccountNumber(java.lang.String payeeAccountNumber) {
        this.payeeAccountNumber = payeeAccountNumber;
    }


    /**
     * Gets the internationalAccountNumber value for this Payload.
     * 
     * @return internationalAccountNumber
     */
    public java.lang.String getInternationalAccountNumber() {
        return internationalAccountNumber;
    }


    /**
     * Sets the internationalAccountNumber value for this Payload.
     * 
     * @param internationalAccountNumber
     */
    public void setInternationalAccountNumber(java.lang.String internationalAccountNumber) {
        this.internationalAccountNumber = internationalAccountNumber;
    }


    /**
     * Gets the payeeAccountOwnershipType value for this Payload.
     * 
     * @return payeeAccountOwnershipType
     */
    public com.rsa.csd.ws.OtherAccountOwnershipType getPayeeAccountOwnershipType() {
        return payeeAccountOwnershipType;
    }


    /**
     * Sets the payeeAccountOwnershipType value for this Payload.
     * 
     * @param payeeAccountOwnershipType
     */
    public void setPayeeAccountOwnershipType(com.rsa.csd.ws.OtherAccountOwnershipType payeeAccountOwnershipType) {
        this.payeeAccountOwnershipType = payeeAccountOwnershipType;
    }


    /**
     * Gets the payeeAccountType value for this Payload.
     * 
     * @return payeeAccountType
     */
    public com.rsa.csd.ws.OtherAccountType getPayeeAccountType() {
        return payeeAccountType;
    }


    /**
     * Sets the payeeAccountType value for this Payload.
     * 
     * @param payeeAccountType
     */
    public void setPayeeAccountType(com.rsa.csd.ws.OtherAccountType payeeAccountType) {
        this.payeeAccountType = payeeAccountType;
    }


    /**
     * Gets the payeeAccountBankType value for this Payload.
     * 
     * @return payeeAccountBankType
     */
    public com.rsa.csd.ws.OtherAccountBankType getPayeeAccountBankType() {
        return payeeAccountBankType;
    }


    /**
     * Sets the payeeAccountBankType value for this Payload.
     * 
     * @param payeeAccountBankType
     */
    public void setPayeeAccountBankType(com.rsa.csd.ws.OtherAccountBankType payeeAccountBankType) {
        this.payeeAccountBankType = payeeAccountBankType;
    }


    /**
     * Gets the payeeRoutingCode value for this Payload.
     * 
     * @return payeeRoutingCode
     */
    public java.lang.String getPayeeRoutingCode() {
        return payeeRoutingCode;
    }


    /**
     * Sets the payeeRoutingCode value for this Payload.
     * 
     * @param payeeRoutingCode
     */
    public void setPayeeRoutingCode(java.lang.String payeeRoutingCode) {
        this.payeeRoutingCode = payeeRoutingCode;
    }


    /**
     * Gets the payeeAccountCountry value for this Payload.
     * 
     * @return payeeAccountCountry
     */
    public java.lang.String getPayeeAccountCountry() {
        return payeeAccountCountry;
    }


    /**
     * Sets the payeeAccountCountry value for this Payload.
     * 
     * @param payeeAccountCountry
     */
    public void setPayeeAccountCountry(java.lang.String payeeAccountCountry) {
        this.payeeAccountCountry = payeeAccountCountry;
    }


    /**
     * Gets the payeeReferenceCode value for this Payload.
     * 
     * @return payeeReferenceCode
     */
    public java.lang.String getPayeeReferenceCode() {
        return payeeReferenceCode;
    }


    /**
     * Sets the payeeReferenceCode value for this Payload.
     * 
     * @param payeeReferenceCode
     */
    public void setPayeeReferenceCode(java.lang.String payeeReferenceCode) {
        this.payeeReferenceCode = payeeReferenceCode;
    }


    /**
     * Gets the transferMediumType value for this Payload.
     * 
     * @return transferMediumType
     */
    public com.rsa.csd.ws.TransferMediumType getTransferMediumType() {
        return transferMediumType;
    }


    /**
     * Sets the transferMediumType value for this Payload.
     * 
     * @param transferMediumType
     */
    public void setTransferMediumType(com.rsa.csd.ws.TransferMediumType transferMediumType) {
        this.transferMediumType = transferMediumType;
    }


    /**
     * Gets the customField value for this Payload.
     * 
     * @return customField
     */
    public java.lang.String getCustomField() {
        return customField;
    }


    /**
     * Sets the customField value for this Payload.
     * 
     * @param customField
     */
    public void setCustomField(java.lang.String customField) {
        this.customField = customField;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Payload)) return false;
        Payload other = (Payload) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.amount==null && other.getAmount()==null) || 
             (this.amount!=null &&
              this.amount.equals(other.getAmount()))) &&
            ((this.currency==null && other.getCurrency()==null) || 
             (this.currency!=null &&
              this.currency.equals(other.getCurrency()))) &&
            ((this.dueDate==null && other.getDueDate()==null) || 
             (this.dueDate!=null &&
              this.dueDate.equals(other.getDueDate()))) &&
            ((this.executionSpeed==null && other.getExecutionSpeed()==null) || 
             (this.executionSpeed!=null &&
              this.executionSpeed.equals(other.getExecutionSpeed()))) &&
            ((this.recurringFrequency==null && other.getRecurringFrequency()==null) || 
             (this.recurringFrequency!=null &&
              this.recurringFrequency.equals(other.getRecurringFrequency()))) &&
            ((this.schedule==null && other.getSchedule()==null) || 
             (this.schedule!=null &&
              this.schedule.equals(other.getSchedule()))) &&
            ((this.fromAccountNickname==null && other.getFromAccountNickname()==null) || 
             (this.fromAccountNickname!=null &&
              this.fromAccountNickname.equals(other.getFromAccountNickname()))) &&
            ((this.fromAccountNumber==null && other.getFromAccountNumber()==null) || 
             (this.fromAccountNumber!=null &&
              this.fromAccountNumber.equals(other.getFromAccountNumber()))) &&
            ((this.payeeName==null && other.getPayeeName()==null) || 
             (this.payeeName!=null &&
              this.payeeName.equals(other.getPayeeName()))) &&
            ((this.payeeAccountNumber==null && other.getPayeeAccountNumber()==null) || 
             (this.payeeAccountNumber!=null &&
              this.payeeAccountNumber.equals(other.getPayeeAccountNumber()))) &&
            ((this.internationalAccountNumber==null && other.getInternationalAccountNumber()==null) || 
             (this.internationalAccountNumber!=null &&
              this.internationalAccountNumber.equals(other.getInternationalAccountNumber()))) &&
            ((this.payeeAccountOwnershipType==null && other.getPayeeAccountOwnershipType()==null) || 
             (this.payeeAccountOwnershipType!=null &&
              this.payeeAccountOwnershipType.equals(other.getPayeeAccountOwnershipType()))) &&
            ((this.payeeAccountType==null && other.getPayeeAccountType()==null) || 
             (this.payeeAccountType!=null &&
              this.payeeAccountType.equals(other.getPayeeAccountType()))) &&
            ((this.payeeAccountBankType==null && other.getPayeeAccountBankType()==null) || 
             (this.payeeAccountBankType!=null &&
              this.payeeAccountBankType.equals(other.getPayeeAccountBankType()))) &&
            ((this.payeeRoutingCode==null && other.getPayeeRoutingCode()==null) || 
             (this.payeeRoutingCode!=null &&
              this.payeeRoutingCode.equals(other.getPayeeRoutingCode()))) &&
            ((this.payeeAccountCountry==null && other.getPayeeAccountCountry()==null) || 
             (this.payeeAccountCountry!=null &&
              this.payeeAccountCountry.equals(other.getPayeeAccountCountry()))) &&
            ((this.payeeReferenceCode==null && other.getPayeeReferenceCode()==null) || 
             (this.payeeReferenceCode!=null &&
              this.payeeReferenceCode.equals(other.getPayeeReferenceCode()))) &&
            ((this.transferMediumType==null && other.getTransferMediumType()==null) || 
             (this.transferMediumType!=null &&
              this.transferMediumType.equals(other.getTransferMediumType()))) &&
            ((this.customField==null && other.getCustomField()==null) || 
             (this.customField!=null &&
              this.customField.equals(other.getCustomField())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAmount() != null) {
            _hashCode += getAmount().hashCode();
        }
        if (getCurrency() != null) {
            _hashCode += getCurrency().hashCode();
        }
        if (getDueDate() != null) {
            _hashCode += getDueDate().hashCode();
        }
        if (getExecutionSpeed() != null) {
            _hashCode += getExecutionSpeed().hashCode();
        }
        if (getRecurringFrequency() != null) {
            _hashCode += getRecurringFrequency().hashCode();
        }
        if (getSchedule() != null) {
            _hashCode += getSchedule().hashCode();
        }
        if (getFromAccountNickname() != null) {
            _hashCode += getFromAccountNickname().hashCode();
        }
        if (getFromAccountNumber() != null) {
            _hashCode += getFromAccountNumber().hashCode();
        }
        if (getPayeeName() != null) {
            _hashCode += getPayeeName().hashCode();
        }
        if (getPayeeAccountNumber() != null) {
            _hashCode += getPayeeAccountNumber().hashCode();
        }
        if (getInternationalAccountNumber() != null) {
            _hashCode += getInternationalAccountNumber().hashCode();
        }
        if (getPayeeAccountOwnershipType() != null) {
            _hashCode += getPayeeAccountOwnershipType().hashCode();
        }
        if (getPayeeAccountType() != null) {
            _hashCode += getPayeeAccountType().hashCode();
        }
        if (getPayeeAccountBankType() != null) {
            _hashCode += getPayeeAccountBankType().hashCode();
        }
        if (getPayeeRoutingCode() != null) {
            _hashCode += getPayeeRoutingCode().hashCode();
        }
        if (getPayeeAccountCountry() != null) {
            _hashCode += getPayeeAccountCountry().hashCode();
        }
        if (getPayeeReferenceCode() != null) {
            _hashCode += getPayeeReferenceCode().hashCode();
        }
        if (getTransferMediumType() != null) {
            _hashCode += getTransferMediumType().hashCode();
        }
        if (getCustomField() != null) {
            _hashCode += getCustomField().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Payload.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "Payload"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "amount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "currency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dueDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "dueDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("executionSpeed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "executionSpeed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ExecutionSpeed"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recurringFrequency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "recurringFrequency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("schedule");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "schedule"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "Schedule"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromAccountNickname");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "fromAccountNickname"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromAccountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "fromAccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "payeeName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeAccountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "payeeAccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("internationalAccountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "internationalAccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeAccountOwnershipType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "payeeAccountOwnershipType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OtherAccountOwnershipType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeAccountType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "payeeAccountType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OtherAccountType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeAccountBankType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "payeeAccountBankType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OtherAccountBankType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeRoutingCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "payeeRoutingCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeAccountCountry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "payeeAccountCountry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payeeReferenceCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "payeeReferenceCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transferMediumType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "transferMediumType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "TransferMediumType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customField");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "customField"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
