/**
 * AdaptiveAuthenticationInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;

public interface AdaptiveAuthenticationInterface extends java.rmi.Remote {
    public com.rsa.csd.ws.NotifyResponse notify(com.rsa.csd.ws.NotifyRequest request) throws java.rmi.RemoteException, com.rsa.csd.ws.SoapFaultType;
    public com.rsa.csd.ws.QueryResponse query(com.rsa.csd.ws.QueryRequest request) throws java.rmi.RemoteException, com.rsa.csd.ws.SoapFaultType;
    public com.rsa.csd.ws.AnalyzeResponse analyze(com.rsa.csd.ws.AnalyzeRequest request) throws java.rmi.RemoteException, com.rsa.csd.ws.SoapFaultType;
    public com.rsa.csd.ws.AuthenticateResponse authenticate(com.rsa.csd.ws.AuthenticateRequest request) throws java.rmi.RemoteException, com.rsa.csd.ws.SoapFaultType;
    public com.rsa.csd.ws.ChallengeResponse challenge(com.rsa.csd.ws.ChallengeRequest request) throws java.rmi.RemoteException, com.rsa.csd.ws.SoapFaultType;
    public com.rsa.csd.ws.CreateUserResponse createUser(com.rsa.csd.ws.CreateUserRequest request) throws java.rmi.RemoteException, com.rsa.csd.ws.SoapFaultType;
    public com.rsa.csd.ws.QueryAuthStatusResponse queryAuthStatus(com.rsa.csd.ws.QueryAuthStatusRequest request) throws java.rmi.RemoteException, com.rsa.csd.ws.SoapFaultType;
    public com.rsa.csd.ws.UpdateUserResponse updateUser(com.rsa.csd.ws.UpdateUserRequest request) throws java.rmi.RemoteException, com.rsa.csd.ws.SoapFaultType;
}
