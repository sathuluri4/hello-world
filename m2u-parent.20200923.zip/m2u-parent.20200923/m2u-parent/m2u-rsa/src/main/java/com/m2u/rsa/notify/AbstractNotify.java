package com.m2u.rsa.notify;

import com.m2u.rsa.common.AbstractAdapt;
import com.m2u.rsa.config.AdaptConfiguration;
import com.m2u.rsa.dto.AdaptNotifyRequestDTO;
import com.m2u.rsa.enums.AdaptServiceName;
import com.m2u.rsa.exception.AdaptException;
import com.m2u.rsa.utils.AdaptMessageHelper;
import com.rsa.csd.ws.EventDataList;
import com.rsa.csd.ws.EventType;
import com.rsa.csd.ws.NotifyRequest;
import com.rsa.csd.ws.NotifyResponse;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
public abstract class AbstractNotify extends AbstractAdapt<NotifyResponse> {
	private NotifyRequest notifyRequest;
	private NotifyResponse notifyResponse;

	public AbstractNotify(AdaptNotifyRequestDTO req, AdaptServiceName adaptServiceName) throws AdaptException {
		super(req, adaptServiceName);

		notifyRequest = new NotifyRequest();
		notifyRequest.setActionTypeList(getGenericActionTypeList());
		notifyRequest.setDeviceRequest(getDeviceRequest());
		notifyRequest.setIdentificationData(getIdentificationData());
		notifyRequest.setMessageHeader(getMessageHeader());
		notifyRequest.setSecurityHeader(getSecurityHeader());
		notifyRequest.setChannelIndicator(getChannelIndicatorType());
		notifyRequest.setEventDataList(getEventDataList());
	}

	@Override
	public EventDataList getEventDataList() {
		String clientDefinedEventType = null;
		if(EventType.CLIENT_DEFINED.equals(getAdaptServiceName().getEventType())) {
			clientDefinedEventType = getReq().getClientDefinedEventType();
		}
		return AdaptMessageHelper.createEventDataList(getReq().getEventDesc(), getAdaptServiceName().getEventType(), clientDefinedEventType);
	}

	@Override
	public NotifyResponse invoke() throws AdaptException {
		try {
			notifyResponse = AdaptConfiguration.getInvoker().notify(notifyRequest);
			return notifyResponse;
		} catch (Exception e) {
			String errorDetails = String.format("Failed to send notify request with sessionId [%s] eventDesc [%s] eventType [%s]",
				getReq().getSessionId(), getReq().getEventDesc(), getAdaptServiceName().getEventType());
			log.error(errorDetails, e);
			throw new AdaptException(errorDetails, e);
		}
	}
}