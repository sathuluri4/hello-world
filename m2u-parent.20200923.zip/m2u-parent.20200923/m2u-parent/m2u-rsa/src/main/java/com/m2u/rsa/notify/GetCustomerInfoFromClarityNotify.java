package com.m2u.rsa.notify;

import com.m2u.rsa.dto.AdaptNotifyRequestDTO;
import com.m2u.rsa.enums.AdaptServiceName;
import com.m2u.rsa.exception.AdaptException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
public class GetCustomerInfoFromClarityNotify extends AbstractNotify {

	public GetCustomerInfoFromClarityNotify(AdaptNotifyRequestDTO req, AdaptServiceName adaptServiceName) throws AdaptException {
		super(req, adaptServiceName);
	}
}
