package com.m2u.payment.model;

import lombok.Data;

@Data
public class UserLoginDetails {

    private String backdropPath;
    private String imageName;
    private String imageCaption;
}
