package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBServiceLanguage;
import com.m2u.payment.entity.MBBServiceLanguageId;
import org.springframework.data.repository.CrudRepository;

public interface MBBServiceLanguageRepository extends CrudRepository<MBBServiceLanguage, MBBServiceLanguageId> {
}

