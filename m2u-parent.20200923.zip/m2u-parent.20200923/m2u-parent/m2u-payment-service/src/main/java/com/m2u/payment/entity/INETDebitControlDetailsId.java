package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class INETDebitControlDetailsId implements Serializable {

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "TRANSACTION_TYPE")
    private String transactionType;

    @Column(name = "PAYEE_CODE")
    private String payeeCode;

    @Column(name = "TRANSACTION_DATE")
    private LocalDateTime transactionDate;

    public INETDebitControlDetailsId() {}

    public INETDebitControlDetailsId(Long userId, String transactionType, String payeeCode, LocalDateTime transactionDate) {
        this.userId = userId;
        this.transactionType = transactionType;
        this.payeeCode = payeeCode;
        this.transactionDate = transactionDate;
    }

    public int hashCode() {
        return Objects.hash(this.userId, this.transactionType, this.payeeCode, this.transactionDate);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof INETDebitControlDetailsId)) {
            return false;
        }
        INETDebitControlDetailsId pk = (INETDebitControlDetailsId) obj;
        return pk.userId == this.userId
            && pk.transactionType.equals(this.transactionType)
            && pk.payeeCode.equals(this.payeeCode)
            && pk.transactionDate.isEqual(this.transactionDate);
    }
}
