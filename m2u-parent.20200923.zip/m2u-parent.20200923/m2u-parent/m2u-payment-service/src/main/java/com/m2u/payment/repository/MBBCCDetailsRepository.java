package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBCCDetails;
import com.m2u.payment.entity.MBBCCDetailsId;
import org.springframework.data.repository.CrudRepository;

public interface MBBCCDetailsRepository extends CrudRepository<MBBCCDetails, MBBCCDetailsId> {
}
