package com.m2u.payment.utils;

import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.Map;

@Slf4j
@Component
public class DatabaseUtils {

    private static EntityManager entityManager;

    private DatabaseUtils() {}

    @PersistenceContext
    private synchronized  void setEntityManager(EntityManager entityMgr) {
        entityManager = entityMgr;
    }

    public static String generateINETTxnId() throws PaymentException {
        String sql = "SELECT INET_ID.NEXTVAL FROM DUAL";
        try {
            BigDecimal txnId = (BigDecimal) getSingleResultNativeQuery(sql, null);
            return txnId.toString();
        } catch (Exception e) {
            String errorDetails = String.format("Failed to generate INET Txn ID with SQL [%s]", sql);
            log.error(errorDetails, e);
            throw new PaymentException(PaymentServiceStatus.DATABASE_ACCESS_FAILED, errorDetails, e);
        }
    }

    public static Object getSingleResultNativeQuery(String query, Map<String, String> parameters) {
        Query nativeQuery = entityManager.createNativeQuery(query);
        // TODO: will replace placeholder :parameterName
        if(null != parameters) {
            for(Map.Entry<String, String> parameter : parameters.entrySet()) {
                nativeQuery.setParameter(parameter.getKey(), parameter.getValue());
            }
        }
        return nativeQuery.getSingleResult();
    }
}
