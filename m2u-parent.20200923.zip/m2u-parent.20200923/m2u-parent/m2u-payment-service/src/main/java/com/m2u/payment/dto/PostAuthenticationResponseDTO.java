package com.m2u.payment.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.m2u.payment.enums.PaymentServiceStatus;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString(callSuper = true)
@Data
public class PostAuthenticationResponseDTO extends AbstractResponseDTO {

    private String title;
    private List<Object> dynamicFields;

    public PostAuthenticationResponseDTO() {}

    public PostAuthenticationResponseDTO(String sessionId, String token, String engineId, PaymentServiceStatus status) {
        super(sessionId, token, engineId, status.getStatusCode(), status.getStatusMessage());
    }

    public PostAuthenticationResponseDTO(String sessionId, String token, String engineId, String statusCode, String statusMessage) {
        super(sessionId, token, engineId, statusCode, statusMessage);
    }
}
