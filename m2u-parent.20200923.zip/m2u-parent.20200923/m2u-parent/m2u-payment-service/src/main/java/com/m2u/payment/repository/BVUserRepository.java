package com.m2u.payment.repository;

import com.m2u.payment.entity.BVUser;
import org.springframework.data.repository.CrudRepository;

public interface BVUserRepository extends CrudRepository<BVUser, Long> {

    BVUser findByUserAlias(String userAlias);
}
