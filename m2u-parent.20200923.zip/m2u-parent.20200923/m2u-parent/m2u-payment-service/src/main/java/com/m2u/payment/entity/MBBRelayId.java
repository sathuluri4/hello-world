package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MBBRelayId implements Serializable {

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "TRANSACTION_REF_ID")
    private String transactionRefId;

    @Column(name = "TOKEN_ID")
    private String tokenId;

    @Column(name = "CREATE_TIMESTAMP")
    private LocalDateTime createTimestamp;

    public MBBRelayId() {}

    public MBBRelayId(Long userId, String transactionRefId, String tokenId, LocalDateTime createTimestamp) {
        this.userId = userId;
        this.transactionRefId = transactionRefId;
        this.tokenId = tokenId;
        this.createTimestamp = createTimestamp;
    }

    public int hashCode() {
        return Objects.hash(this.userId, this.transactionRefId, this.tokenId, this.createTimestamp);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MBBRelayId)) {
            return false;
        }
        MBBRelayId pk = (MBBRelayId) obj;
        return pk.userId == this.userId
            && pk.transactionRefId.equals(this.transactionRefId)
            && pk.tokenId.equals(this.tokenId)
            && pk.createTimestamp.isEqual(this.createTimestamp);
    }
}
