package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBProductList;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MBBProductListRepository extends CrudRepository<MBBProductList, Long> {

    @Cacheable(value="m2uDCCCache", key="{#accountType, #productCode, #deleted, #status}")
    MBBProductList findByAccountTypeAndProductCodeAndDeletedAndStatus(String accountType, String productCode, Long deleted, Long status);

    @Cacheable(value="m2uDCCCache", key="{#accountType, #productCode, #deleted, #status, #ccPrefix}")
    @Query("select a, b " +
        "from MBBProductList a " +
        "left outer join a.mbbProductInfoList b on a.oid = b.mbbProductInfoId.oid " +
        "where a.accountType = :accountType " +
        "and a.productCode = :productCode " +
        "and a.deleted = :deleted " +
        "and a.status = :status " +
        "and b.mbbProductInfoId.ccPrefix = :ccPrefix")
    List<Object[]> findByAccountTypeAndProductCodeAndDeletedAndStatusAndCcPrefix(String accountType, String productCode, Long deleted, Long status, String ccPrefix);
}
