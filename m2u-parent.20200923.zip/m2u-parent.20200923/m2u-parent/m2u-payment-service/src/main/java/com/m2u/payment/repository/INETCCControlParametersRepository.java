package com.m2u.payment.repository;

import com.m2u.payment.entity.INETCCControlParameters;
import org.springframework.data.repository.CrudRepository;

public interface INETCCControlParametersRepository extends CrudRepository<INETCCControlParameters, Long> {

    INETCCControlParameters findByPayeeCode(String payeeCode);
}
