package com.m2u.payment.enums;

public enum PaymentType {

    TICKETING ("Ticketing", "Online Ticketing Payment"),
    DEBIT ("Debit", "DPE Payment"),
    ;

    String desc;
    String title;

    PaymentType(String desc, String title) {
        this.desc = desc;
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public String getTitle() {
        return title;
    }
}
