package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Table(name="BV_MSGSCRIPT")
@Entity
public class BVMSGScript implements Serializable {

    @Id
    @Column(name = "OID")
    private Long oid;

    @Column(name = "SCRIPT_NAME", nullable = false)
    private String scriptName;

    @Column(name = "STORE_ID", nullable = false)
    private String storeId;

    @Column(name = "CREATION_TIME", nullable = false)
    private LocalDateTime creationTime;

    @Column(name = "STATUS", nullable = false)
    private Long status;

    @Column(name = "DELETED", nullable = false)
    private Long deleted;

    @Column(name = "LAST_MOD_TIME", nullable = false)
    private LocalDateTime lastModTIme;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "PERSONALIZE", nullable = false)
    private Long personalize;

    @Column(name = "SCRIPT_FORM", nullable = false)
    private Long scriptForm;

    @Column(name = "SCRIPT_TXT")
    private String scriptTxt;

    @Column(name = "FILE_PATH")
    private String filePath;

    @Column(name = "SAMPLE")
    private String sample;
}
