package com.m2u.payment.repository;

import com.m2u.payment.entity.INETReceiptDetails;
import com.m2u.payment.entity.INETReceiptDetailsId;
import org.springframework.data.repository.CrudRepository;

public interface INETReceiptDetailsRepository extends CrudRepository<INETReceiptDetails, INETReceiptDetailsId> {
}
