package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MBBProductInfoId implements Serializable {

    @Column(name = "OID")
    private Long oid;

    @Column(name = "CC_PREFIX")
    private String ccPrefix;

    public MBBProductInfoId() {}

    public MBBProductInfoId(Long oid, String ccPrefix) {
        this.oid = oid;
        this.ccPrefix = ccPrefix;
    }

    public int hashCode() {
        return Objects.hash(this.oid, this.ccPrefix);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MBBProductInfoId)) {
            return false;
        }
        MBBProductInfoId pk = (MBBProductInfoId) obj;
        return pk.oid == this.oid
            && pk.ccPrefix.equals(this.ccPrefix);
    }
}
