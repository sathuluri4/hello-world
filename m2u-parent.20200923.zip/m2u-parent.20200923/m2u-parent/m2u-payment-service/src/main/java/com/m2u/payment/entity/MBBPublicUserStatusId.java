package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MBBPublicUserStatusId implements Serializable {

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "ACTIVITY_ID")
    private Long activityId;

    public MBBPublicUserStatusId() {}

    public MBBPublicUserStatusId(Long userId, Long activityId) {
        this.userId = userId;
        this.activityId = activityId;
    }

    public int hashCode() {
        return Objects.hash(this.userId, this.activityId);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MBBPublicUserStatusId)) {
            return false;
        }
        MBBPublicUserStatusId pk = (MBBPublicUserStatusId) obj;
        return pk.userId == this.userId
            && pk.activityId == this.activityId;
    }
}
