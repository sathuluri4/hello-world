package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MBBPayeeGeneralListId implements Serializable {

    @Column(name = "OID")
    private Long oid;

    @Column(name = "MV_CID")
    private String mvCid;

    public MBBPayeeGeneralListId() {}

    public MBBPayeeGeneralListId(Long oid, String mvCid) {
        this.oid = oid;
        this.mvCid = mvCid;
    }

    public int hashCode() {
        return Objects.hash(this.oid, this.mvCid);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MBBPayeeGeneralListId)) {
            return false;
        }
        MBBPayeeGeneralListId pk = (MBBPayeeGeneralListId) obj;
        return pk.oid == this.oid
            && pk.mvCid.equals(this.mvCid);
    }
}
