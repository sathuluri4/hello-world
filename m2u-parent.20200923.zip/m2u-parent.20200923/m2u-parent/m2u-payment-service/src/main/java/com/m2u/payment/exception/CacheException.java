package com.m2u.payment.exception;

public class CacheException extends Exception {

    public CacheException(String errorDetails) {
        super(errorDetails);
    }

    public CacheException(String errorDetails, Throwable e) {
        super(errorDetails, e);
    }
}
