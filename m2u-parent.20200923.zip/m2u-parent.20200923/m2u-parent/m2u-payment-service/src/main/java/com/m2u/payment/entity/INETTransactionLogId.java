package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class INETTransactionLogId implements Serializable {

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "CREATE_TIME")
    private LocalDateTime createTime;

    @Column(name = "BV_SESSION_ID")
    private String bvSessionId;

    @Column(name = "BV_TRANSACTION_ID")
    private String bvTransactionId;

    @Column(name = "TRANSACTION_REF_ID")
    private String transactionRefId;

    @Column(name = "TRANSACTION_TYPE")
    private String transactionType;

    public INETTransactionLogId() {}

    public INETTransactionLogId(Long userId, LocalDateTime createTime, String bvSessionId, String bvTransactionId, String transactionRefId, String transactionType) {
        this.userId = userId;
        this.createTime = createTime;
        this.bvSessionId = bvSessionId;
        this.bvTransactionId = bvTransactionId;
        this.transactionRefId = transactionRefId;
        this.transactionType = transactionType;
    }

    public int hashCode() {
        return Objects.hash(this.userId, this.createTime, this.bvSessionId, this.bvTransactionId, this.transactionRefId, this.transactionType);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof INETTransactionLogId)) {
            return false;
        }
        INETTransactionLogId pk = (INETTransactionLogId) obj;
        return pk.userId == this.userId
            && pk.createTime.isEqual(this.createTime)
            && pk.bvSessionId.equals(this.bvSessionId)
            && pk.bvTransactionId.equals(this.bvTransactionId)
            && pk.transactionRefId.equals(this.transactionRefId)
            && pk.transactionType.equals(this.transactionType);
    }
}
