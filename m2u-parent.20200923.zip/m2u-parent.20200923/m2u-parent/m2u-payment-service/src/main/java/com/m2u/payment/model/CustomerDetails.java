package com.m2u.payment.model;

import lombok.Data;

import java.util.List;

@Data
public class CustomerDetails {

    private Long userId;
    private String userAlias;
    private String customerType;
    private String customerName;
    private String customerIcBusreg;
    private String customerOldIc;
    private String companyName;
    private String companyRegNo;
    private String pan;

    private Long forgetPwdAttempt;
    private String publicStatus;

    // FROM ClARITY
    private String s2uIndicator;
    // TODO: Future use SpringCache to hold the data instead of store to Hazelcast cache
    // TODO: Mean while once user choose the right account, cleanup the Hazelcast cache
    private List<Account> accounts;
    private Account fromAccount;
}
