package com.m2u.payment.enums;

public enum TransactionStatus {

    SUCCESSFUL ("Successful"),
    UNSUCCESSFUL ("Unsuccessful"),
    EXPIRED ("Expired"),
    REJECTED ("Rejected"),
    UNKNOWN ("Unknown"),
    ;

    String desc;

    TransactionStatus(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public static TransactionStatus getByDesc(String desc) {
        switch(desc) {
            case "Successful":
                return TransactionStatus.SUCCESSFUL;
            case "Unsuccessful":
                return TransactionStatus.UNSUCCESSFUL;
            case "Expired":
                return TransactionStatus.EXPIRED;
            case "Rejected":
                return TransactionStatus.REJECTED;
            default:
                return UNKNOWN;
        }
    }
}
