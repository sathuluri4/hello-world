package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBPayeeList;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.repository.CrudRepository;

public interface MBBPayeeListRepository extends CrudRepository<MBBPayeeList, Long> {

    // TODO: To use cache on entity, we need to ensure it child we need to have direct access must set to
    // TODO: fetch eagerly as well to avoid "no session" exception. Unfortunately JPA doesn't allowed multiple List
    // TODO: childs fetch eagerly at the same time, it only support when using Set
    @Cacheable(value="m2uDCCCache", key="{#payeeCode, #deleted, #status, #debitEngineAllowed}")
    MBBPayeeList findByPayeeCodeAndDeletedAndStatusAndDebitEngineAllowed(String payeeCode, Long deleted, Long status, Long debitEngineAllowed);
}
