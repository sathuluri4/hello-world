package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_PAYEE_GENERAL_LIST")
@Entity
public class MBBPayeeGeneralList implements Serializable {

    @EmbeddedId
    private MBBPayeeGeneralListId mbbPayeeGeneralListId;

    @Column(name = "MV_REF_NO")
    private String mvRefNo;

    @Column(name = "MV_BILLACCT_NO")
    private String mvBillacctNo;

    @Column(name = "MV_AMOUNT")
    private Long mvAmount;

    @Column(name = "MV_AMOUNT_DISPLAY")
    private String mvAmountDisplay;

    @Column(name = "MV_NOTE_REQUIRED")
    private Long mvNoteRequired;

    @Column(name = "MV_NOTE")
    private String mvNote;

    @Column(name = "MV_AMOUNT_GST")
    private String mvAmountGst;

    @ManyToOne
    @MapsId("oid")
    @JoinColumn(name="OID")
    private MBBPayeeList mbbPayeeList;
}
