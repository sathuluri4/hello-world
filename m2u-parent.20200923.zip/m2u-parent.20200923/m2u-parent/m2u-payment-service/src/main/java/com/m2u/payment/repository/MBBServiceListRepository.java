package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBServiceList;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MBBServiceListRepository extends CrudRepository<MBBServiceList, Long> {

    @Cacheable(value="m2uDCCCache", key="{#serviceCode, #subServiceCode, #locale}")
    @Query("select a, b, c, d " +
        "from MBBServiceList a " +
        "left outer join a.mbbServiceLanguageList b on a.oid = b.mbbServiceLanguageId.oid and b.mbbServiceLanguageId.locale = :locale " +
        "left outer join a.mbbServiceDetailsList c on a.oid = c.mbbServiceDetailsId.oid and c.mbbServiceDetailsId.subServiceCode = :subServiceCode " +
        "left outer join a.mbbServiceDetailsNewList d on a.oid = d.mbbServiceDetailsNewId.oid and d.mbbServiceDetailsNewId.subServiceCode = :subServiceCode and d.mbbServiceDetailsNewId.locale = :locale " +
        "where a.serviceCode = :serviceCode")
    List<Object[]> findByServiceCodeAndSubServiceCodeAndLocale(String serviceCode, String subServiceCode, String locale);
}