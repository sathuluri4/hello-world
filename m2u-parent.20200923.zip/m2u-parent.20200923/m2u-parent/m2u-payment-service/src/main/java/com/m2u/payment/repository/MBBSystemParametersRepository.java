package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBSystemParameters;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.repository.CrudRepository;

public interface MBBSystemParametersRepository extends CrudRepository<MBBSystemParameters, Long> {

    @Cacheable(value="m2uDCCCache", key="{#mbbParameters, #status}")
    MBBSystemParameters findByMbbParameterIgnoreCaseAndStatus(String mbbParameters, long status);
}
