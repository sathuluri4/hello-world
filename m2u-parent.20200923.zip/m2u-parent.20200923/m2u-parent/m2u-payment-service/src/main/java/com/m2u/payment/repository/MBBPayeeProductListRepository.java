package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBPayeeProductList;
import com.m2u.payment.entity.MBBPayeeProductListId;
import org.springframework.data.repository.CrudRepository;

public interface MBBPayeeProductListRepository extends CrudRepository<MBBPayeeProductList, MBBPayeeProductListId> {
}
