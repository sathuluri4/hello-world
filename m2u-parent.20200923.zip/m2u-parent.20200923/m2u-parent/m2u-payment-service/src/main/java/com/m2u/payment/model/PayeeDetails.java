package com.m2u.payment.model;

import lombok.Data;

@Data
public class PayeeDetails {

    private String payeeCode;
    private String payeeURL;
    private String fullName;
    private String pnPriority;
    private String pnPayeeIp;
    private String pnPayeeEmail1;
    private String pnPayeeEmail2;
    private String billAcctDisplayName;
    private String billRefDisplayName;
    private boolean isTACRequired;
    private boolean isOnlinePayment;
}
