package com.m2u.payment.enums;

import org.springframework.http.HttpStatus;

public enum PaymentServiceStatus {

    // SUCCESS
    SUCCESS ("10000", "Success", HttpStatus.OK),

    // BUSINESS EXCEPTION
    EXCEEDED_MAX_FORGET_PASSWORD_ATTEMPT ("20001", "Customer exceeded max forget password attempt allowed", HttpStatus.UNAUTHORIZED),
    EXCEEDED_LIMIT_ALLOWED ("20001", "Customer transaction amount exceed limit allowed", HttpStatus.UNAUTHORIZED),

    // SERVER EXCEPTION
    UNEXPECTED_EXCEPTION ("30000", "Unexpected exception occurred", HttpStatus.INTERNAL_SERVER_ERROR),
    INTERNAL_SERVER_ERROR ("30001", "Internal server error", HttpStatus.INTERNAL_SERVER_ERROR),
    SERVICE_UNAVAILABLE ("30002", "System under maintenance", HttpStatus.SERVICE_UNAVAILABLE),
    UNSUPPORTED_REQUEST ("30003", "Unsupported request", HttpStatus.BAD_REQUEST),
    INVALID_REQUEST_DATA ("30004", "Invalid request data", HttpStatus.BAD_REQUEST),
    TOKEN_VALIDATION_FAILED ("30005", "Token validation failed", HttpStatus.BAD_REQUEST),
    DATABASE_ACCESS_FAILED ("30006", "Failed to access database", HttpStatus.INTERNAL_SERVER_ERROR),
    LDAP_COMMUNICATION_FAILED("30007", "Failed to communicate with LDAP", HttpStatus.INTERNAL_SERVER_ERROR),
    CLARITY_COMMUNICATION_FAILED("30008", "Failed to communicate with CLARITY", HttpStatus.BAD_GATEWAY),
    ADAPT_COMMUNICATION_FAILED("30009", "Failed to communicate with RSA", HttpStatus.BAD_GATEWAY),
    ADAPT_UNAUTHORISED_ACCESS("30010", "Failed to communicate with RSA", HttpStatus.BAD_REQUEST),
    DATA_CACHING_FAILED ("30011", "Failed to cache data", HttpStatus.BAD_GATEWAY),
    DATA_PARSING_FAILED ("30012", "Failed to parse data", HttpStatus.INTERNAL_SERVER_ERROR),
    DATA_NOT_FOUND ("30013", "Data not found", HttpStatus.BAD_REQUEST),
    ;

    String statusCode;
    String statusMessage;
    HttpStatus httpStatus;
    // TODO: We can soon add in the user readable errorCode and errorMessage, and UIUX can make use of this info to display meaningful message to user
//    String errorCode;
//    String errorMessage;

    PaymentServiceStatus(String code, String message, HttpStatus httpStatus) {
        this.statusCode = code;
        this.statusMessage = message;
        this.httpStatus = httpStatus;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}
