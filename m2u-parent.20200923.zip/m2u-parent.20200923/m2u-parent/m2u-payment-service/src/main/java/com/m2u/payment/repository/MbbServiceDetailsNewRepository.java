package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBServiceDetailsNew;
import com.m2u.payment.entity.MbbServiceDetailsNewId;
import org.springframework.data.repository.CrudRepository;

public interface MbbServiceDetailsNewRepository extends CrudRepository<MBBServiceDetailsNew, MbbServiceDetailsNewId> {
}

