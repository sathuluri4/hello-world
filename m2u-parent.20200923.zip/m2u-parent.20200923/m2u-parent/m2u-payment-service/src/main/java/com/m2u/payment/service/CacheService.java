package com.m2u.payment.service;

import com.m2u.payment.dto.ResetM2UCacheRequestDTO;
import com.m2u.payment.dto.ResetM2UCacheResponseDTO;
import com.m2u.payment.exception.PaymentException;

public interface CacheService {

    ResetM2UCacheResponseDTO resetM2UCache(ResetM2UCacheRequestDTO req, String target) throws PaymentException;
}
