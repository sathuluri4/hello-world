package com.m2u.payment.model;

import lombok.Data;

@Data
public class BillPayment {

    private String serviceCode;
    private String fromAcctCode;
    private String toAcctCode;
    private String payeeCode;
    private String individualEffectPaymentDate;
    private String currencyCode;
    private String txnAmount;
    private String billAcctNo;
    private String custName;
    private String icNoBusRegNo;
    private String cNo;
    private String expiryDate;
    private String cvv;
}
