package com.m2u.payment.repository;

import com.m2u.payment.entity.BVMSGScript;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.repository.CrudRepository;

public interface BVMSGScriptRepository extends CrudRepository<BVMSGScript, Long> {

    @Cacheable(value="m2uPaymentCache", key="{#scriptName}")
    BVMSGScript findTopByScriptName(String scriptName);
}
