package com.m2u.payment.enums;

public enum PayeeType {

    MERCHANT,
    NON_MERCHANT,
    ;
}
