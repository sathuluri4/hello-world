package com.m2u.payment.repository;

import com.m2u.payment.entity.INETDebitControlParameters;
import org.springframework.data.repository.CrudRepository;

public interface INETDebitControlParametersRepository extends CrudRepository<INETDebitControlParameters, Long> {

    INETDebitControlParameters findByPayeeCode(String payeeCode);
}
