package com.m2u.payment.service;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(value = "m2u-cache")
@RibbonClient(value = "m2u-cache")
public interface M2UCacheService {

    static final String M2U_CACHE_REST_PATH = "/m2u/cache/v1/caches";

    @GetMapping(path = M2U_CACHE_REST_PATH)
    String getCache(@RequestParam(value = "name") String name, @RequestParam(value = "key") String key);

    @PostMapping(path = M2U_CACHE_REST_PATH)
    String createCache(String keyValue);

    @PutMapping(path = M2U_CACHE_REST_PATH)
    String updateCache(String keyValue);

    @DeleteMapping(path = M2U_CACHE_REST_PATH)
    String deleteCache(@RequestParam(value = "name") String name, @RequestParam(value = "key") String key);
}