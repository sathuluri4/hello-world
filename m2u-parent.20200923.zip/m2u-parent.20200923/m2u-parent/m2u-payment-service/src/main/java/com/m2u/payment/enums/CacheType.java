package com.m2u.payment.enums;

public enum CacheType {

    M2U_DCC_CACHE ("m2uDCCCache"),
    M2U_PAYMENT_CACHE ("m2uPaymentCache"),
    UNKNOWN ("Unknown"),
    ;

    String cacheName;

    CacheType (String cacheName) {
        this.cacheName = cacheName;
    }

    public String getCacheName() {
        return cacheName;
    }

    public CacheType getByCacheName(String cacheName) {
        switch(cacheName) {
            case "m2uDCCCache":
                return M2U_DCC_CACHE;
            case "m2uPaymentCache":
                return M2U_PAYMENT_CACHE;
            default:
                return UNKNOWN;
        }
    }
}
