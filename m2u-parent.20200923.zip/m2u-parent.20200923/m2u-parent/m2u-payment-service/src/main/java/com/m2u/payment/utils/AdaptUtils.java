package com.m2u.payment.utils;

import com.m2u.payment.dto.AbstractDPERequestDTO;
import com.m2u.payment.enums.PaymentAdaptServiceType;
import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import com.m2u.payment.model.CustomerDetails;
import com.m2u.rsa.config.AdaptConfiguration;
import com.m2u.rsa.dto.AdaptNotifyRequestDTO;
import com.m2u.rsa.dto.AdaptNotifyResponseDTO;
import com.m2u.rsa.exception.AdaptException;
import com.m2u.rsa.service.AdaptService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AdaptUtils {

    private static AdaptService adaptService;

    private AdaptUtils() {}

    @Autowired
    public synchronized void setAdaptService(AdaptService adaptServc) {
        adaptService = adaptServc;
    }

    public static boolean isSwitchOn() {
        String rsaSwitch = AdaptConfiguration.getProperty("SWITCH");
        if(null == rsaSwitch) {
            return false;
        }
        return "0".equals(rsaSwitch);
    }

    public static boolean isDPECustomerType(String customerType) {
        return(isCustomerSupported(customerType, "DPECUSTOMERTYPE"));
    }

    private static boolean isCustomerSupported(String customerType, String resource) {
        String supportedList = AdaptConfiguration.getProperty(resource);
        if(null == supportedList) {
            return false;
        }
        return supportedList.contains(customerType);
    }

    public static AdaptNotifyResponseDTO notify(
            AbstractDPERequestDTO req, CustomerDetails customerDetails, String eventDesc, PaymentAdaptServiceType paymentAdaptServiceType,
            String deviceTokenCookie, String deviceTokenFSO, String txnId) throws PaymentException {

        AdaptNotifyResponseDTO notifyResp = null;
        try {
            if(AdaptUtils.isSwitchOn()) {
                AdaptNotifyRequestDTO notifyReq = createAdaptNotifyRequest(
                    req, customerDetails, eventDesc, paymentAdaptServiceType, deviceTokenCookie, deviceTokenFSO, txnId);

                log.debug("Adapt Notify Request [{}]", notifyReq);
                notifyResp = adaptService.notify(notifyReq);
                log.debug("Adapt Notify Response [{}]", notifyResp);

                if(0 != notifyResp.getReasonCode()) {
                    log.error("Failed to notify RSA [{}] with username [{}]. responseCode [{}] responseDesc [{}]",
                        paymentAdaptServiceType, customerDetails.getUserAlias(), notifyResp.getReasonCode(), notifyResp.getDesc());
                }
            }
        } catch (AdaptException e) {
            String errorDetails = String.format("Failed to invoke Adapt notify eventDesc[%s] adaptServiceName [%s]. sessionId [%s] token [%s] engineId [%s]",
                eventDesc, paymentAdaptServiceType.getAdaptServiceName(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails, e);
            // TODO: Should we stop the transaction? Check with @HuiLee
            throw new PaymentException(PaymentServiceStatus.ADAPT_COMMUNICATION_FAILED, errorDetails, e);
        }
        return notifyResp;
    }

    private static <T extends AbstractDPERequestDTO> AdaptNotifyRequestDTO createAdaptNotifyRequest(
        T req, CustomerDetails customerDetails, String eventDesc, PaymentAdaptServiceType paymentAdaptServiceType,
            String deviceTokenCookie, String deviceTokenFSO, String txnId) {

        AdaptNotifyRequestDTO notifyReq = new AdaptNotifyRequestDTO();

        String userIdStr = String.valueOf(customerDetails.getUserId());

        // TODO: Future can make it store
        notifyReq.setServiceName(paymentAdaptServiceType.getAdaptServiceName());
        notifyReq.setEventDesc(eventDesc);
        notifyReq.setSessionId(req.getSessionId());
        notifyReq.setTxnId(txnId);
        notifyReq.setUserId(userIdStr);
        notifyReq.setCustomerType(customerDetails.getCustomerType());
        notifyReq.setChannel(req.getChannel());

        // Device Request
        notifyReq.getDeviceRequest().setDevicePrint(req.getDevicePrint());
        // TODO: This 2 fields are used as Adapt Cookies in M2U
        notifyReq.getDeviceRequest().setDeviceTokenCookie(deviceTokenCookie);
        notifyReq.getDeviceRequest().setDeviceTokenFSO(deviceTokenFSO);
        // TODO: From HTTP Headers
        notifyReq.getDeviceRequest().setAccept(req.getHeaderAccept());
        notifyReq.getDeviceRequest().setAcceptCharset(req.getHeaderAcceptCharset());
        notifyReq.getDeviceRequest().setAcceptEncoding(req.getHeaderAcceptEncoding());
        notifyReq.getDeviceRequest().setAcceptLanguage(req.getHeaderAcceptLanguage());
        notifyReq.getDeviceRequest().setUserAgent(req.getHeaderUserAgent());
        notifyReq.getDeviceRequest().setRemoteAddress(req.getRemoteAddress());
        // TODO: MBB Customs
        notifyReq.getDeviceRequest().setReferrer(req.getReferrer());

        if("Yes".equals(req.getFormAction())) {
            notifyReq.getDeviceRequest().setDomElements(req.getDomElements());
            notifyReq.getDeviceRequest().setJsEvents(req.getJsEvents());
            notifyReq.getDeviceRequest().setPageId(req.getPageId());
        }

        // Identification Data
        notifyReq.getIdentificationData().setClientSessionId(req.getSessionId());
        notifyReq.getIdentificationData().setClientSegment(customerDetails.getCustomerType());
        notifyReq.getIdentificationData().setUserLoginName(userIdStr);
        notifyReq.getIdentificationData().setUsername(customerDetails.getUserAlias());

        // Event Data List
        // TODO: This should only set be if EventType.CLIENT_DEFINED, else will get ignore
        notifyReq.setClientDefinedEventType(paymentAdaptServiceType.getClientDefinedEventType());

        // Transaction Data
        // TODO: Not cover yet at this stage

        return notifyReq;
    }

//    private static <T extends AbstractRequestDTO> AdaptCreateUserRequestDTO createAdaptCreateUserRequest(T req, BVUser bvUser, PaymentAdaptServiceType paymentAdaptServiceType, String txnId) {
//        AdaptCreateUserRequestDTO createUserReq = new AdaptCreateUserRequestDTO();
//
//        // TODO: Future can make it store
//        createUserReq.setServiceName(paymentAdaptServiceType.getAdaptServiceName());
//        createUserReq.setSessionId(req.getSessionId());
//        // TODO: Let Adapt library generate it
//        createUserReq.setTxnId(txnId);
//        createUserReq.setUserId(bvUser.getUserId().toString());
//        createUserReq.setCustomerType(bvUser.getBvUserProfile().getMbbCustomerType());
//        createUserReq.setChannel(req.getChannel());
//
//        // Device Request
//        createUserReq.getDeviceRequest().setDevicePrint(req.getDevicePrint());
//        // TODO: This 2 fields are used as Adapt Cookies in M2U
//        createUserReq.getDeviceRequest().setDeviceTokenCookie(req.getDeviceTokenCookie());
//        createUserReq.getDeviceRequest().setDeviceTokenFSO(req.getDeviceTokenFSO());
//        // TODO: From HTTP Headers
//        createUserReq.getDeviceRequest().setAccept(req.getHeaderAccept());
//        createUserReq.getDeviceRequest().setAcceptCharset(req.getHeaderAcceptCharset());
//        createUserReq.getDeviceRequest().setAcceptEncoding(req.getHeaderAcceptEncoding());
//        createUserReq.getDeviceRequest().setAcceptLanguage(req.getHeaderAcceptLanguage());
//        createUserReq.getDeviceRequest().setUserAgent(req.getHeaderUserAgent());
//        createUserReq.getDeviceRequest().setRemoteAddress(req.getRemoteAddress());
//        // TODO: MBB Customs
//        createUserReq.getDeviceRequest().setReferrer(req.getReferrer());
//
//        if("Yes".equals(req.getFormAction())) {
//            createUserReq.getDeviceRequest().setDomElements(req.getDomElements());
//            createUserReq.getDeviceRequest().setJsEvents(req.getJsEvents());
//            createUserReq.getDeviceRequest().setPageId(req.getPageId());
//        }
//
//        // Identification Data
//        createUserReq.getIdentificationData().setClientSessionId(req.getSessionId());
//        createUserReq.getIdentificationData().setClientSegment(bvUser.getBvUserProfile().getMbbCustomerType());
//        createUserReq.getIdentificationData().setUserLoginName(bvUser.getUserId().toString());
//        createUserReq.getIdentificationData().setUsername(bvUser.getUserAlias());
//        createUserReq.getIdentificationData().setTxnId(txnId);
//
//        return createUserReq;
//    }

    public static void updateDeviceTokenDetails(AdaptNotifyResponseDTO notifyResp, AbstractDPERequestDTO req) {
        req.setDeviceTokenCookie(notifyResp.getDeviceTokenCookie());
        req.setDeviceTokenFSO(notifyResp.getDeviceTokenFSO());
    }
}
