package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_SERVICE_DETAILS")
@Entity
public class MBBServiceDetails implements Serializable {

    @EmbeddedId
    private MBBServiceDetailsId mbbServiceDetailsId;

    @Column(name="SUB_SERVICE_NAME")
    private String subServiceName;

    @Column(name="MAX_LIMIT")
    private Long maxLimit;

    @Column(name="DENOMINATOR")
    private Long denominator;

    @Column(name="NOTE1")
    private String note1;

    @Column(name="NOTE2")
    private String note2;

    @Column(name="NOTE3")
    private String note3;

    @Column(name="NOTE4")
    private String note4;

    @Column(name="NOTE5")
    private String note5;

    @ManyToOne
    @MapsId("oid")
    @JoinColumn(name="oid")
    private MBBServiceList mbbServiceList;
}
