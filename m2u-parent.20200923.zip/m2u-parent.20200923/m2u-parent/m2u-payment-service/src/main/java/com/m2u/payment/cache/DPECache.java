package com.m2u.payment.cache;

import com.m2u.payment.enums.PaymentType;
import com.m2u.payment.enums.TransactionStatus;
import com.m2u.payment.model.CustomerDetails;
import com.m2u.payment.model.PayeeDetails;
import com.m2u.payment.model.PaymentValidationResult;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class DPECache {

    // DPE specific
    private String sessionId;
    private String token;
    private String privateKey;

    // Request Params
    // TODO: Move this 2 fields to PayeeDetails class
//    private String payeeCode;
//    private String payeeURL;
    private String billAmt;
    private String billRefNo;
    private String billAcctNo;
    private String amtBit;
    private String refBit;
    private String acctBit;
    private String dateBit;

    private BigDecimal bigDecimalTxnAmt;
    private double doubleTxnAmt;
    private String txnAmtWith100Multiply;
    private String displayTxnAmt;

    private PaymentType paymentType;
    private PaymentValidationResult paymentValidationResult;
    private TransactionStatus txnStatus;

    // Customer Details
    private CustomerDetails customerDetails = new CustomerDetails();

    // Payee Details
    private PayeeDetails payeeDetails = new PayeeDetails();

    // S2U Details
    private String s2uRefNo;
    private String s2uToken;
}
