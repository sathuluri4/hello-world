package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class INETPaymentControlDetailsId implements Serializable {

    @Column(name = "USER_ALIAS")
    private String userAlias;

    @Column(name = "CREDIT_CARD_NUM")
    private String creditCardNum;

    @Column(name = "PAYEE_CODE")
    private String payeeCode;

    @Column(name = "TRANSACTION_DATE")
    private LocalDateTime transactionDate;

    public INETPaymentControlDetailsId() {}

    public INETPaymentControlDetailsId(String userAlias, String creditCardNum, String payeeCode, LocalDateTime transactionDate) {
        this.userAlias = userAlias;
        this.creditCardNum = creditCardNum;
        this.payeeCode = payeeCode;
        this.transactionDate = transactionDate;
    }

    public int hashCode() {
        return Objects.hash(this.userAlias, this.creditCardNum, this.payeeCode, this.transactionDate);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof INETPaymentControlDetailsId)) {
            return false;
        }
        INETPaymentControlDetailsId pk = (INETPaymentControlDetailsId) obj;
        return pk.userAlias.equals(this.userAlias)
            && pk.creditCardNum.equals(this.creditCardNum)
            && pk.payeeCode.equals(this.payeeCode)
            && pk.transactionDate.isEqual(this.transactionDate);
    }
}
