package com.m2u.payment.service;

import com.m2u.clarity.messaging.dto.*;
import com.m2u.common.constants.DCCConstant;
import com.m2u.common.enums.Channel;
import com.m2u.common.model.EncryptionKeyPair;
import com.m2u.common.utils.DateTimeUtils;
import com.m2u.common.utils.M2UUtils;
import com.m2u.common.utils.StringUtils;
import com.m2u.ldap.exception.LDAPException;
import com.m2u.ldap.model.LDAPUser;
import com.m2u.ldap.service.LDAPService;
import com.m2u.payment.cache.DPECache;
import com.m2u.payment.config.PassItOnConfiguration;
import com.m2u.payment.constants.PaymentServiceConstant;
import com.m2u.payment.dto.*;
import com.m2u.payment.entity.*;
import com.m2u.payment.enums.*;
import com.m2u.payment.exception.CacheException;
import com.m2u.payment.exception.PaymentException;
import com.m2u.payment.model.*;
import com.m2u.payment.repository.*;
import com.m2u.payment.resources.M2UApplicationResources;
import com.m2u.payment.resources.M2UBusinessOptionsResources;
import com.m2u.payment.utils.*;
import com.m2u.rsa.dto.AdaptNotifyResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Service
public class DPEServiceImpl implements DPEService {

    private static final String DASH_VALUE = "-";
    private static final String DATE_TIME_FORMAT = "dd MMM yyyy HH:mm:ss";
    
    // DYNAMIC FIELDS RELATED
    private static final String FULL_LABEL_FIELD = "fullLabel";
    private static final String ACTION_FIELD = "action";
    private static final String TOKEN_FIELD = "token";  
    private static final String AMOUNT_LABEL = "general.amount";
    private static final String CORPORATION_NAME_LABEL = "general.corporation.name";
    private static final String EFFECTIVE_DATE_LABEL = "m1700.effectiveDate";
    private static final String REFERENCE_LABEL = "m7000.reference";
    private static final String FROM_ACCOUNT_LABEL = "m7000.fromAccount";
    private static final String TODAY_VALUE = "general.today";

    @Autowired
    private Environment env;

    @Autowired
    private MBBPayeeListRepository mbbPayeeListRepository;

    @Autowired
    private BVUserRepository bvUserRepository;

    @Autowired
    private BVMSGScriptRepository bvMSGScriptRepository;

    @Autowired
    private MBBSystemParametersRepository mbbSystemParametersRepository;

    @Autowired
    private MBBPublicUserStatusRepository mbbPublicUserStatusRepository;

    @Autowired
    private INETTransactionLogRepository inetTransactionLogRepository;

    @Autowired
    private INETDebitControlDetailsRepository inetDebitControlDetailsRepository;

    @Autowired
    private INETDebitControlParametersRepository inetDebitControlParametersRepository;

    @Autowired
    private INETCCControlParametersRepository inetCCControlParametersRepository;

    @Autowired
    private INETPaymentControlDetailsRepository inetPaymentControlDetailsRepository;

    @Autowired
    private INETReceiptDetailsRepository inetReceiptDetailsRepository;

    @Autowired
    private MBBPaymentLimitRepository mbbPaymentLimitRepository;

    @Autowired
    private SMSTableRepository smsTableRepository;

    @Autowired
    private MBBRelayRepository mbbRelayRepository;

    @Autowired
    private PNTable2Repository pnTable2Repository;

    @Autowired
    private LDAPService ldapService;

    @Value("${m2u.payment.rest-api.post-authentication}")
    private String postAuthenticationURL;

    @Value("${m2u.payment.rest-api.txn-confirmation}")
    private String txnConfirmationURL;

    @Value("${m2u.payment.rest-api.otp-creation}")
    private String otpCreationURL;

    @Value("${m2u.payment.rest-api.txn-completion}")
    private String txnCompletionURL;

    @Value("${m2u.payment.rest-api.pdf-generation}")
    private String pdfGenerationURL;

    @Override
    public InitializationResponseDTO initialization(InitializationRequestDTO req) throws PaymentException {
        // TODO: Reference M2UMakeMerchantPFXPaymentAction.execute()

        // TODO: Change it to method annotation later
        PaymentServiceUtils.checkIsSystemDowntime();

        DPECache cache = new DPECache();

        // TODO: Reference M2UPayeeLoginAction.execute(), encrypted details is not supported at the moment
        // TODO: Reference M2UMerchantLoginAction.execute()
        String[] paramTokens = req.getParamString().split("\\$");

        if(paramTokens.length > 7) {
            String merchantId = paramTokens[1];
            String amtBit = paramTokens[2];
            String merchantAmount = paramTokens[3];
            String refBit = paramTokens[4];
            String merchantRefNo = paramTokens[5];
            String acctBit = paramTokens[6];
            String merchantAcctNo = paramTokens[7];

            // TODO: Extra request parameters like merchantId, merchantTxnRefNo, mbbTxnRefNo is not supported at the moment

            // TODO: Check payee validity in the beginning stage
            // TODO: IMPORTANT!!! Slim down the content return since this is only verify payee existence
            getMBBPayeeList(merchantId);
            // TODO: Check should we store payee details to cache, but please take note payee details is huge
            // TODO: Payee data and processes involved are costly, not worth to store cache in this stage, e.g. if user authentication failed, resources spent wasted

            String merchantUrl = null;
            String dateBit = null;
            if (paramTokens.length == 9) {
                if ("0".equals(paramTokens[8]) || "1".equals(paramTokens[8])) {
                    dateBit = paramTokens[8];
                    merchantUrl = "";
                } else {
                    dateBit = "";
                    merchantUrl = paramTokens[8];
                }
            }

            BigDecimal bdTxnAmt = StringUtils.convertStringToBigDecimal(merchantAmount);
            double doubleTxnAmt = bdTxnAmt.doubleValue();
            long longTxnAmt = (long) (doubleTxnAmt * 100);
            String txnAmtWith100Mutiply = String.valueOf(longTxnAmt);
            String displayTxnAmount = PaymentServiceUtils.formatAmountWithCountryCurrency(bdTxnAmt, req.getCountryCode());

            cache.setBigDecimalTxnAmt(bdTxnAmt);
            cache.setDoubleTxnAmt(doubleTxnAmt);
            cache.setTxnAmtWith100Multiply(txnAmtWith100Mutiply);
            cache.setDisplayTxnAmt(displayTxnAmount);

            // TODO: Commented and check with UIUX team are they needed?
//            String redirectUrl = null;
//            if (!StringUtils.isEmptyString(merchantUrl)) {
//                String txnDate = DateTimeUtils.formatLocalDateTime(LocalDateTime.now(), DATE_TIME_FORMAT);
//                String redirectUrlTemplate = "%s?transDate=%s&status=02&transAmount=%s&referenceNo=%s&payeeCode=%s&approvalCode=&bankRefNo=&accountNo=%s&corpName=";
//                redirectUrl = String.format(redirectUrlTemplate, merchantUrl, txnDate, txnAmtWith100Mutiply, merchantRefNo, merchantId, merchantAcctNo);
//            }

            // TODO: Reference PasswordEncryptionKey.invoke()
            EncryptionKeyPair encryptKeyPair = SecurityUtils.createEncryptionKeyPair();

            cache.setSessionId(M2UUtils.createSessionId());
            // TODO: Reference M2UControllerAction.saveToken()
            cache.setToken(M2UUtils.createToken());
            cache.setPrivateKey(encryptKeyPair.getPrivateKey());
            cache.getPayeeDetails().setPayeeCode(merchantId);
            cache.getPayeeDetails().setPayeeURL(merchantUrl);
            cache.setBillAmt(merchantAmount);
            cache.setBillRefNo(merchantRefNo);
            cache.setBillAcctNo(merchantAcctNo);
            cache.setAmtBit(amtBit);
            cache.setRefBit(refBit);
            cache.setAcctBit(acctBit);
            cache.setDateBit(dateBit);

            createCache(cache);

            InitializationResponseDTO resp = new InitializationResponseDTO(cache.getSessionId(), cache.getToken(), req.getEngineId());
            resp.setSessionId(cache.getSessionId());
            resp.setEngineId(req.getEngineId());
            resp.setToken(cache.getToken());
            resp.setCurrentDate(LocalDateTime.now());
            // TODO: We could use this field to hold customer readable error message
            resp.setError(null);
            resp.setDeviceTokenCookie(req.getDeviceTokenCookie());
            resp.setDeviceTokenFSO(req.getDeviceTokenFSO());

            resp.setPublicKey(encryptKeyPair.getPublicKey());
            // TODO: Commented and check with UIUX team are they needed?
//            resp.setRedirectURL(redirectUrl);
//            resp.setMerchantURL(merchantUrl);
//            resp.setDateBit(dateBit);

            return resp;
        } else {
            String errorDetails = String.format("Failed to parse request parameters [%s]", req.getParamString());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.INVALID_REQUEST_DATA, errorDetails);
        }
    }

    @Override
    public PreAuthenticationResponseDTO preAuthentication(PreAuthenticationRequestDTO req) throws PaymentException {
        // TODO: Reference M2UMerchantLoginCheckAdaptAction.execute()

        // TODO: Change it to method annotation later
        PaymentServiceUtils.checkIsSystemDowntime();

        DPECache cache = getCache(req.getSessionId());

        // TODO: Change it to method annotation later
        PaymentServiceUtils.isValidToken(cache.getToken(), req.getToken());
        cache.setToken(M2UUtils.createToken());

        String eventDesc = null;
        PaymentAdaptServiceType paymentAdaptServiceType = PaymentAdaptServiceType.ATTEMPT_LOGIN_USERNAME_NOTIFY;
        if (StringUtils.isEmptyString(cache.getPayeeDetails().getPayeeURL()) && !StringUtils.isEmptyString(cache.getDateBit())) {
            eventDesc = "Attempt Debit Payment Signin";
        } else {
            eventDesc = "Attempt Online Ticketing Signin";
        }

        String subSessionId = req.getSessionId().substring(4,12);
        // TODO: IMPORTANT!!! Temporary commented for testing purpose
//        String username = SecurityUtils.decryptEncryptedData(req.getUsername(), subSessionId, cache.getPrivateKey());
        // TODO: IMPORTANT!!! Remove once testing completed
        String username = "m2ursa10";

        // TODO: Reference M2UControllerAction.initWebAppContext(), perform initialization, skip for now
        // APP: SERVER_PATH_VALUE, ADSOLUTE_PATH_VALUE, SERVICE_NAME_VALUE, CONTEXT_PATH_VALUE, DEFAULT_COUNTRY_VALUE,
        //		HOST_REFERER_VALUE, CORBA_SERVER_INDEX_VALUE, SECURE_PATH_VALUE, SECURE_JAVA_PATH_VALUE, BASE_PATH_VALUE,
        //		SECURE_BASE_VALUE, SECURE_LOAN_VALUE, IM2U_FILE_PATH, FPX_FILE_PATH, DP_FILE_PATH, SUPPORTED_LANGUAGES_VALUE, POWS_SERVER_PATH
        // ENV: CUSTOMER_SERVICE, CYBER_HOTLINE, CYBER_HP

        // TODO: Reference M2ULoginCheckAdaptHelper.runProcess() & M2ULoginCheckAdaptServices.analyzeAdapt()

        // TODO: Reference M2UGenericLoginServices.initializeVisitor()
        // TODO: IMPORTANT!!! Slim down the content return since this is only verify payee existence
        BVUser bvUser = getBVUserByUserAlias(username);
        CustomerDetails customerDetails = updateCustomerDetailsWithBVInfo(cache.getCustomerDetails(), bvUser);

        // TODO: As for now only support certain customer type to use DPE
        // TODO: IMPORTANT!!! New customer type need to be migrate to the m2ursacfg.cfg file
        if(!AdaptUtils.isDPECustomerType(bvUser.getBvUserProfile().getMbbCustomerType())) {
            String errorDetails = String.format("Customer type [%s] is not supported in DPE yet. sessionId [%s] token [%s] engineId [%s]",
                bvUser.getBvUserProfile().getMbbCustomerType(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.UNSUPPORTED_REQUEST, errorDetails);
        }

        // TODO: Checked with @HuiLee, only insert/update to MBB_SECURITY after verified with Clarity logon info
        // TODO: Reason doing so is to help avoid real customer being interrupt by unauthorised users

        // TODO: Original is using "LOGINCUSTOMERTYPE", however we change it to custom DPE Type, since we checked previously, we can skip check again here

        // TODO: Reference RSAUtils.AdaptNotify() M2UADAPTNotify.runAdaptNotifyProcess()
        AdaptNotifyResponseDTO notifyResp = AdaptUtils.notify(
            req, customerDetails, eventDesc, paymentAdaptServiceType, req.getDeviceTokenCookie(), req.getDeviceTokenFSO(), null);

        if(null != notifyResp) {
            // TODO: Checked with @HuiLee, we only support existing RSA user, don't need delete any record in MBB_ADAPT, but we need to stop the transaction here
            if(AdaptResponseCode.USER_IS_REMOVED.getReasonCode() == notifyResp.getReasonCode()) {
                String errorDetails = String.format("User [%s] has been removed from RSA. responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                    bvUser.getUserAlias(), notifyResp.getReasonCode(), notifyResp.getDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
                log.error(errorDetails);
                throw new PaymentException(PaymentServiceStatus.ADAPT_UNAUTHORISED_ACCESS, errorDetails);
            }

            // TODO: RSA device details need to be reference in subsequent RSA call, stored them in both request and cache
            AdaptUtils.updateDeviceTokenDetails(notifyResp, req);
        }

        // TODO: Checked with @HuiLee 1 user shall have max 1 record
        MBBAdapt mbbAdapt = bvUser.getMbbAdapt();
        UserLoginDetails userLoginDetails = getUserLoginDetails(mbbAdapt, req.getTimeForTheme());

        // TODO: Reference M2UMerchantLoginCheckAdaptAction.execute()
        // TODO: Checked with @HuiLee, we only support loginenroll RSA user, due to that can ignore existing logic in M2U

        updateCache(cache);

        PreAuthenticationResponseDTO resp = new PreAuthenticationResponseDTO();
        resp.setSessionId(cache.getSessionId());
        resp.setEngineId(req.getEngineId());
        resp.setToken(cache.getToken());
        resp.setCurrentDate(LocalDateTime.now());
        // TODO: We could use this field to hold customer readable error message
        resp.setError(null);
        resp.setDeviceTokenCookie(req.getDeviceTokenCookie());
        resp.setDeviceTokenFSO(req.getDeviceTokenFSO());

        resp.setImageName(userLoginDetails.getImageName());
        resp.setImageCaption(userLoginDetails.getImageCaption());
        resp.setBackdropPath(userLoginDetails.getBackdropPath());

        return resp;
    }

    @Override
    public PostAuthenticationResponseDTO postAuthentication(PostAuthenticationRequestDTO req) throws PaymentException {
        // TODO: Reference M2UMerchantValidateLoginAction.execute()

        // TODO: Change it to method annotation later
        PaymentServiceUtils.checkIsSystemDowntime();

        DPECache cache = getCache(req.getSessionId());

        // TODO: Reference M2UControllerAction.checkToken(), existing logic is different, it check request "action" parameter to identify M2USTATE, e.g. M2USTATE_CONFIRM, M2USTATE_INIT
        // TODO: Each REST API has dedicated task, we dont support this for the moment, due to that ignore the existing M2U logic
        // TODO: Change it to method annotation later
        PaymentServiceUtils.isValidToken(cache.getToken(), req.getToken());
        cache.setToken(M2UUtils.createToken());

        String subSessionId = req.getSessionId().substring(4,12);

        // TODO: IMPORTANT!!! Temporary commented for testing purpose
//        String username = SecurityUtils.decryptEncryptedData(req.getUsername(), subSessionId, cache.getPrivateKey());
//        String password = SecurityUtils.decryptEncryptedData(req.getPassword(), subSessionId, cache.getPrivateKey());
        // TODO: IMPORTANT!!! Remove once testing completed
        String username = "m2ursa10";
        String password = "pass1234";

        // TODO: Existing C++ Plugin do check the length of credential, check with @HuiLee do we follow the same?
        if (username.length() > 16 || password.length() > 12) {
            String errorDetails = String.format("Decrypted username/password exceeded supported length. username.length [%d] password.length [%d]. sessionId [%s] token [%s] engineId [%s]",
                username.length(), password.length(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.DATA_PARSING_FAILED, errorDetails);
        }

        // TODO: Private key is no longer needed at this stage, save cost in cache
        cache.setPrivateKey(null);

        // TODO: We need to fetch the record again, some data could be update in between the process, e.g. no. of password attempt
        BVUser bvUser = getBVUserByUserAlias(username);

        // TODO: I assumed the mandatory data has less chance to be alter between few secs, so get from cache instead
        CustomerDetails customerDetails = updateCustomerDetailsWithBVInfo(cache.getCustomerDetails(), bvUser);

        // TODO: Reference M2UMerchantLoginHelper.runProcess() & M2UMerchantLoginServices.execute()
        // TODO: Reference M2UGenericLoginServices.authenticate()

        LDAPUser ldapUser = null;
        try {
            ldapUser = ldapService.authenticateLDAPUser(username, password);
            log.debug("Authenticated LDAPUser [{}]", username, ldapUser);
        } catch (LDAPException e) {
            // TODO: Reference LDAP errors: https://docs.oracle.com/javase/tutorial/jndi/ldap/exceptions.html
            // TODO: For now we use original LDAP error message which include description + error code
            // TODO: ADAPT got limitation in length, e.g. error code "1605", need to slim down
            int ldapErrorCode = getLDAPErrorCode(e.getMessage());
            String eventDesc = String.format("Unsuccessful Session Signin. [%d]", ldapErrorCode);
            PaymentAdaptServiceType paymentAdaptServiceType = PaymentAdaptServiceType.LOGIN_USERNAME_PASSWORD_FAILED_NOTIFY;
            AdaptNotifyResponseDTO notifyResp = AdaptUtils.notify(
                req, customerDetails, eventDesc, paymentAdaptServiceType, req.getDeviceTokenCookie(), req.getDeviceTokenFSO(), null);

            if(null != notifyResp) {
                // TODO: RSA device details need to be reference in subsequent RSA call, stored them in both request and cache
                AdaptUtils.updateDeviceTokenDetails(notifyResp, req);
            }

            String errorDetails = String.format("Failed to authenticate LDAP with username [%s]. sessionId [%s] token [%s] engineId [%s]", username, req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails, e);
            throw new PaymentException(PaymentServiceStatus.LDAP_COMMUNICATION_FAILED, errorDetails, e);
        }
        customerDetails.setPan(ldapUser.getPan());

        // TODO: Reference M2UMerchantLoginServices.verifyUserLogin()

        // TODO: Reference M2UGenericLoginServices.verifyCustomerMiscInfo()
        verifyCustomerMiscInfo(customerDetails);

        // TODO: Reference M2UMerchantLoginServices.initCustomerInfo()
        // TODO: Reference M2UGenericCustomerInitServices.initCustomerInfo()
        if("ibccpublic".equals(ldapUser.getGroup())) {
            String errorDetails = String.format("\"ibccpublic\" group user  is not supported in DPE yet. sessionId [%s] token [%s] engineId [%s]", req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.UNSUPPORTED_REQUEST, errorDetails);
        }

        // TODO: Reference M2UGenericCustomerInitServices.initNonIbccPublicCustomerInfo()
        // TODO: Reference BVUtils.getCustomerInfoFromFN()
        GetLogonResponseDTO getLogonResp = ClarityUtils.getLogon(req, customerDetails);
        // TODO: Discussed with @HuiLee, since we assumed customer enrolled, we must notify RSA if failed too
        if(!"0000".equals(getLogonResp.getResponseCode())) {
            String eventDesc = String.format("Unsuccessful Signin. [%s]", getLogonResp.getResponseCode());
            PaymentAdaptServiceType paymentAdaptServiceType = PaymentAdaptServiceType.GET_CUSTOMER_INFO_FROM_CLARITY_NOTIFY;
            AdaptNotifyResponseDTO notifyResp = AdaptUtils.notify(
                req, customerDetails, eventDesc, paymentAdaptServiceType, req.getDeviceTokenCookie(), req.getDeviceTokenFSO(), null);

            if(null != notifyResp) {
                // TODO: RSA device details need to be reference in subsequent RSA call, stored them in both request and cache
                AdaptUtils.updateDeviceTokenDetails(notifyResp, req);
            }

            // TODO: Shorten the error details need to be return to UIUX
            String errorDetails = String.format("Failed to get logon info from Clarity. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                getLogonResp.getTxnRefId(), getLogonResp.getResponseCode(), getLogonResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            // TODO: We had log the long error details, so skip logging here
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, errorDetails);
        }

        // TODO: Checked with @HuiLee, we only update last login details to BV_USER_PROFILE and MBB_SECURITY after successful Clarity logon
        LocalDateTime now = LocalDateTime.now();

        // TODO: Perform DB update on BV_USER_PROFILE table
        bvUser.getBvUserProfile().setBvSessionId(req.getSessionId());
        bvUser.getBvUserProfile().setLastLoginDate(now);
        bvUser.getBvUserProfile().setLastModTime(now);
        // TODO: Existing M2U code doesn't update this, but since user successfully login i think we shall reset it back to zero, check with @HuiLee again
        bvUser.getBvUserProfile().setMbbForgetPwAttempt(0L);

        bvUser = updateBVUserMBBSecurity(req, bvUser);
        bvUserRepository.save(bvUser);

        String eventDesc = "Successful Signin";
        PaymentAdaptServiceType paymentAdaptServiceType = PaymentAdaptServiceType.GET_CUSTOMER_INFO_FROM_CLARITY_NOTIFY;
        AdaptNotifyResponseDTO notifyResp = AdaptUtils.notify(
            req, customerDetails, eventDesc, paymentAdaptServiceType, req.getDeviceTokenCookie(), req.getDeviceTokenFSO(), null);

        if(null != notifyResp) {
            // TODO: RSA device details need to be reference in subsequent RSA call, stored them in both request and cache
            AdaptUtils.updateDeviceTokenDetails(notifyResp, req);
        }

        // TODO: Reference M2UMerchantMakePaymentServices.setBean()
        // TODO: Reference M2UMerchantMakePaymentServices.setDisplayInfo() & BVUtils.getPayeeBean
        // TODO: Retrieve payee details early so we can utilize it details to filter out unnecessary data in early stage
        MBBPayeeList mbbPayeeList = getMBBPayeeList(cache.getPayeeDetails().getPayeeCode());
        List<String> acceptedProducts = getMBBPayeeListAcceptedProducts(mbbPayeeList);

        // TODO: Payee can only be Online/Non-Online, we need support both for Ticketing
        boolean isOnlinePayment = (DCCConstant.DCC_TRUE.equals(mbbPayeeList.getOnlinePayment()));

        // TODO: Start filtering the user Clarity accounts
        List<Account> accounts = ClarityUtils.filterClarityLogonAccounts(req, getLogonResp, isOnlinePayment, acceptedProducts);

        // TODO: Reference BVUtils.setAccountProfileList()
        // TODO: Checked with @HuiLee, account nickname is not needed, skip fetch data from MBB_ACCOUNTS

        // TODO: Checked existing M2U, other CCs from MBB_CC_DETAILS doesn't used in DPE logic, so skip handling it

        // TODO: Update with Clarity most recent customer data
        cache.getCustomerDetails().setCustomerType(getLogonResp.getCustTypeFlag());
        cache.getCustomerDetails().setS2uIndicator(getLogonResp.getPdpaS2uIndicator());
        cache.getCustomerDetails().setAccounts(accounts);

        updatePayeeDetailsWithMBBPayeeList(cache.getPayeeDetails(), mbbPayeeList);

        // TODO: Reference M2UGenericCustomerInitServices.verifyTACOption() & BVUtils.isModulePermitted()
        // TODO: It is using file base, e.g. /bv_data/mbb_ACL/mbb_ACL
        // TODO: Checked with @HuiLee, we can think of other way to control this, skip this for now, means ignore the TAC bypass option
        // TODO: Checked at the moment seems like m1100, m1104, m1200, m2000 only rely on it, no impact to DPE

        // TODO: Reference M2UMerchantValidateLoginAction.execute()
        // TODO: The merchantType is only set in M2UPayeeLoginAction.execute(), skip the logic related to it for now

        PaymentType paymentType = null;
        List<Object> dynamicFields = null;

        if (StringUtils.isEmptyString(cache.getPayeeDetails().getPayeeURL()) && !StringUtils.isEmptyString(cache.getDateBit())) {
            // TODO: Reference M2UMakeDebitPaymentAction.execute()
            // TODO: Discussed with @HuiLee, DPE is lower priority for now, we shall cover it later after complete Ticketing
            // MerchantPaymentType = DPE
//            paymentType = PaymentType.DEBIT;
            String errorDetails = String.format("DPE merchant payment type is not supported in DPE yet. sessionId [%s] token [%s] engineId [%s]", req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.UNSUPPORTED_REQUEST, errorDetails);
        } else {
            // TODO: Reference: M2UTicketingMakePaymentAction.execute()
            // MerchantPaymentType = OT
            // TODO: BillPaymentTags.PAYMENT_TYPE = PaymentType.TICKETING is set here
            paymentType = PaymentType.TICKETING;

            // TODO: Reference M2UMerchantMakePaymentHelper.runProcess() & M2UMerchantMakePaymentServices.setBean()
            // TODO: Since merchantTxnRefNo is provided as extra request parameter which we dont support, skip it for now

            // TODO: M2UMerchantMakePaymentServices.setCorporationNameBean()
            // TODO: Reference M2UMerchantMakePaymentServices.setBillAccountNoBean()
            // TODO: Reference M2UMerchantMakePaymentServices.setBillReferenceNoBean()
            // TODO: Reference M2UMerchantMakePaymentServices.setAmountBean()
            // TODO: Reference M2UMerchantMakePaymentServices.setScheduledDateBean(), skip for now since DPE not yet support schedule payment
            // TODO: Reference M2UMerchantMakePaymentServices.setTacRequired(), checked with @HuiLee we always based on payee TAC requirement in DB
            // TODO: Reference M2UMerchantMakePaymentServices.setDisplayInfo()
            // TODO: Reference back to M2UMerchantMakePaymentServices.setBean()

            // TODO: Reference M2UMerchantMakePaymentServices.setBean()
            // TODO: GSC checking is skip for now, we shall cover it later, #WONG
            // TODO: Due to that, "typeOfPayment" & "gscValidationRequired" parameters are ignore for now

            dynamicFields = createDynamicFieldsForPostAuthentication(req, cache);
        }

        cache.setPaymentType(paymentType);

        updateCache(cache);

        PostAuthenticationResponseDTO resp = new PostAuthenticationResponseDTO();
        resp.setSessionId(cache.getSessionId());
        resp.setEngineId(req.getEngineId());
        resp.setToken(cache.getToken());
        resp.setCurrentDate(LocalDateTime.now());
        // TODO: We could use this field to hold customer readable error message
        resp.setError(null);
        resp.setDeviceTokenCookie(req.getDeviceTokenCookie());
        resp.setDeviceTokenFSO(req.getDeviceTokenFSO());

        resp.setTitle(paymentType.getTitle());
        resp.setDynamicFields(dynamicFields);

        // TODO: Commented and check with UIUX team are follow fields necessary?
//        resp.setIsInitiate(false);
//        resp.setIsMobileFullScreen(false);
//        resp.setHasLocalPagination(false);
//        resp.setHasAccordian(false);

        // TODO: Commented and check with UIUX team are follow fields necessary?
//        resp.setFutureInterval(28);
//        resp.setRecurringInterval(28);
//        resp.setAuthenticate(true);

        // TODO: Reference M2UOnlineTicketingUtil.getOnlineticketingPayeeDetails()
        // TODO: Commented and check with UIUX team are follow fields necessary?
//        resp.setPayee(mbbPayeeList.getFullName());
//        resp.setPayeeType(paymentType.getDesc());
//        resp.setAccountNumber(cacheData.getMerchantAcctNo());
//        resp.setAmount(bdAmount.toString());
//        resp.setHasRecurringPayment(false);
//        resp.setCanRegisterBill(false);
//        resp.setCanAllowFuturePayment(false);

        return resp;
    }

    @Override
    public TxnConfirmationResponseDTO confirmTransaction(TxnConfirmationRequestDTO req) throws PaymentException {
        // TODO: Reference M2UTicketsConfirmPaymentAction.execute()

        // TODO: Change it to method annotation later
        PaymentServiceUtils.checkIsSystemDowntime();

        DPECache cache = getCache(req.getSessionId());

        // TODO: Reference M2UControllerAction.checkToken(), existing logic is different, it check request "action" parameter to identify M2USTATE, e.g. M2USTATE_CONFIRM, M2USTATE_INIT
        // TODO: Each REST API has dedicated task, we dont support this for the moment, due to that ignore the existing M2U logic
        // TODO: Change it to method annotation later
        PaymentServiceUtils.isValidToken(cache.getToken(), req.getToken());
        cache.setToken(M2UUtils.createToken());

        // TODO: MerchantPaymentType set during M2UMerchantValidateLoginAction.execute()
        // TODO: It only check for DPE, DPE not support it yet and rejected during post-authentication stage

        // TODO: Reference M2UTicketsConfirmPaymentHelper.runProcess() & M2UTicketsConfirmPaymentServices.execute()
        CustomerDetails customerDetails = cache.getCustomerDetails();
        // TODO: Since we might do cleanup on the cache, this REST API shouldn't be call simply
        if(null == customerDetails.getAccounts() || customerDetails.getAccounts().isEmpty()) {
            String errorDetails = String.format("Customer account list is not available anymore in cache, please start the transaction from beginning again. sessionId [%s] token [%s] engineId [%s]",
                req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.INTERNAL_SERVER_ERROR, errorDetails);
        }

        Optional<Account> fromAcctTemp = customerDetails.getAccounts().stream().filter(x -> x.getIdx() == req.getIdx()).findFirst();
        Account fromAcct = null;
        if(fromAcctTemp.isPresent()) {
            fromAcct = fromAcctTemp.get();
            cache.getCustomerDetails().setFromAccount(fromAcct);
        } else {
            String errorDetails = String.format("Failed to find account with idx [%d]. sessionId [%s] token [%s] engineId [%s]",
                req.getIdx(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        // TODO: Once fromAcct identified, immediately cleanup the unnecessary full Account list from cache
        // TODO: However they could be a risk where go back and choose another account, in this cache the data is gone, do we need support this? check with @HuiLee
        customerDetails.setAccounts(null);

        GetAccountDetailsResponseDTO getAccountDetailsResp = ClarityUtils.getAccountDetails(req, customerDetails);
        if(!"0000".equals(getAccountDetailsResp.getResponseCode())) {
            // TODO: Shorten the error details need to be return to UIUX
            String errorDetails = String.format("Failed to get account details from Clarity. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                getAccountDetailsResp.getTxnRefId(), getAccountDetailsResp.getResponseCode(), getAccountDetailsResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            // TODO: We had log the long error details, so skip logging here
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, errorDetails);
        }

        // TODO: The balance could change anytime by other MBB txn, due to that we cant store it to cache and reuse, take note
        BigDecimal bdBalance = ClarityUtils.getAccountBalance(getAccountDetailsResp, fromAcct);
        String displayBalAmt = PaymentServiceUtils.formatAmountWithCountryCurrency(bdBalance, req.getCountryCode());
        // TODO: Take note this is for temporary, and the value will get change anytime, but we just park it under cache for immediate reference on subsequent process
        fromAcct.setBalance(bdBalance);
        fromAcct.setDisplayBalAmt(displayBalAmt);

        // TODO: In existing M2U logic, session attribute "adaptTransactionName" set with value "ticketsPayment", it is reference by m9003, not sure about DPE

        // TODO: "typeOfPayment" & "gscValidationRequired" were set during M2UMerchantMakePaymentServices.setBean()
        // TODO: We had skip them in previous stage, skip the logic for now, #WONG
//        M2UDynaBean m_oExternalBean = (M2UDynaBean) m_oBean.get("externalBean");
//        String m_sTypeOfPayment = DataValidator.isEmptyString((String) m_oExternalBean.get("typeOfPayment")) ? "" : (String) m_oExternalBean
//                .get("typeOfPayment");
//        boolean m_bGscValidationRequired = (Boolean) m_oExternalBean.get("gscValidationRequired") == null ? false : ((Boolean) m_oExternalBean
//                .get("gscValidationRequired")).booleanValue();
//        boolean m_bValidGSCTrans = (Boolean) request.getAttribute("validGSCTrans") == null ? false : ((Boolean) request
//                .getAttribute("validGSCTrans")).booleanValue();
//
//        if ("G".equalsIgnoreCase(m_sTypeOfPayment) && m_bGscValidationRequired && !m_bValidGSCTrans) {
//            setForwardPage("validateGSCTrans");
//            return super.execute(mapping, m_oBean.getActionForm(), request, response);
//        }
        // TODO: Reference M2UGscPaymentTransactionValidatorAction.execute()
        // TODO: Reference M2UGscPaymentTransactionValidatorHelper.runProcess()
        // TODO: Reference M2UGscPaymentTransactionValidatorServices.process()
        // TODO: Reference MerchantPaymentUtils.getNotes()

        // TODO: In M2UMerchantMakePaymentServices.setBillAccountNoBean(), we setup "billAcctNoDisplayType", however it is either text or label, list is not supported
        // TODO: Due to that we wont support list of billAcctNo for now, and the billAcctNo is same as the merchantAcctNo in cache

        // TODO: In M2UMerchantMakePaymentServices.setBillReferenceNoBean(), we setup "billRefNoDisplayType", however it is either text or label, list is not supported
        // TODO: Due to that we wont support list of billAcctNo for now, and the "billReferenceNo" = "merchantRefNo" in M2U

        // TODO: In M2UMerchantMakePaymentServices.setAmountBean(), we setup "amountDisplayType", however it is either text or label, list is not supported
        // TODO: Due to that we wont support list of amount for now, and the "amount" = "merchantAmount" in M2U

        // TODO: In M2UMerchantMakePaymentServices.setScheduledDateBean(), we are not support schedule payment for DPE now
        // TODO: We never set "registeredPayeeNo" in bean so far, so skip handling anything related to it now

        // TODO: Here we set BV session properties "SEND_TAC_IDENTIFIER" with value "OnlineTicketing", however not sure where it use yet. Might need revisit for this
        // TODO: Since we are not using session, handling of session attribute object "OnlineTicketing" will be skipped

        // TODO: Reference M2UOnlineTicketingUtil.getOnlineticketingPayeeDetails()

        List<Object> dynamicFields = createDynamicFieldsForConfirmTransaction(req, cache);

        // TODO: Reference M2UTicketsConfirmPaymentHelper.runProcess & M2UTicketsConfirmPaymentServices.getSecureM2UTACOTPInd()
        List<Map<String, Object>> secureTypes = S2UUtils.getSecureTypes(cache.getPayeeDetails().isTACRequired(), customerDetails.getCustomerType(), customerDetails.getS2uIndicator(), cache.getDoubleTxnAmt(), req.getLocale());

        // TODO: Commented and check with UIUX team are they needed?
//        String redirectUrl = null;
//        if(!StringUtils.isEmptyString(cache.getPayeeDetails().getPayeeURL())) {
//            PayeeDetails payeeDetails = cache.getPayeeDetails();
//            String transDate = DateTimeUtils.formatLocalDateTime(LocalDateTime.now(), DATE_TIME_FORMAT);
//            // TODO: Compare redirectUrl created during initialization stage, here we put in additional details like payee fullname
//            String redirectUrlTemplate = "%s?transDate=%s&status=03&transAmount=%s&referenceNo=%s&payeeCode=%s&approvalCode=&bankRefNo=&accountNo=%s&corpName=%s";
//            redirectUrl = String.format(redirectUrlTemplate, payeeDetails.getPayeeURL(), transDate, cache.getTxnAmtWith100Multiply(), cache.getBillRefNo(), payeeDetails.getPayeeCode(), cache.getBillAcctNo(), payeeDetails.getFullName());
//        }

        updateCache(cache);

        TxnConfirmationResponseDTO resp = new TxnConfirmationResponseDTO();
        resp.setSessionId(cache.getSessionId());
        resp.setEngineId(req.getEngineId());
        resp.setToken(cache.getToken());
        resp.setCurrentDate(LocalDateTime.now());
        // TODO: We could use this field to hold customer readable error message
        resp.setError(null);
        resp.setDeviceTokenCookie(req.getDeviceTokenCookie());
        resp.setDeviceTokenFSO(req.getDeviceTokenFSO());

        resp.setTitle(cache.getPaymentType().getTitle());
        resp.setDynamicFields(dynamicFields);

        resp.setSecureTypes(secureTypes);
        resp.setIsTACRequired(true);
        // TODO: Shall we put a full REST API URL, but we need to support multiple instance so need think how to achieve this
        resp.setOtpURL(otpCreationURL);

        // TODO: Commented and check with UIUX team are follow fields necessary?
//        resp.setIsInitiate(false);
//        resp.setIsMobileFullScreen(false);
//        resp.setHasLocalPagination(false);
//        resp.setHasAccordian(false);
//        resp.setCurrentDate(LocalDateTime.now());

        // TODO: Commented and check with UIUX team are they needed?
//        resp.setRedirectURL(redirectUrl);

        return resp;
    }

    @Override
    public CreateOTPResponseDTO createOTP(CreateOTPRequestDTO req) throws PaymentException {
        // TODO: Reference M2UTicketsPaymentConfirmedAction.execute

        // TODO: Change it to method annotation later
        PaymentServiceUtils.checkIsSystemDowntime();

        DPECache cache = getCache(req.getSessionId());

        // TODO: Reference M2UControllerAction.checkToken(), existing logic is different, it check request "action" parameter to identify M2USTATE, e.g. M2USTATE_CONFIRM, M2USTATE_INIT
        // TODO: Each REST API has dedicated task, we dont support this for the moment, due to that ignore the existing M2U logic
        // TODO: Change it to method annotation later
        PaymentServiceUtils.isValidToken(cache.getToken(), req.getToken());
        cache.setToken(M2UUtils.createToken());

        // TODO: Reference M2UTACHandlerAction.java
        // TODO: Reference M2UTACHandlerFormatter.sendTAC()
        // TODO: Here we set lot values to the inputmap which need to be reference in subsequent logic, Ticketing Payment and Debit Payment using these:
//        m_oInputsMaps.put("TACID", TACID);
//        m_oInputsMaps.put("AMTID", AMTID);
//        m_oInputsMaps.put("DATASENDING1", DATASENDING1);
//        m_oInputsMaps.put("DATASENDING2", DATASENDING2);
//        m_oInputsMaps.put("TACIMP", "newtacmsg");

        // TODO: Reference M2UTACHandlerHelper.java
        // TODO: Reference M2UTACHandlerServices.processTAC()

        // TODO: We should dynamic handling Ticketing Payment (TAC160001) and Debit Payment (TAC700001) later
        String tacId = getTACIdByPaymentType(cache.getPaymentType());
        
        //Service name: TACNOTESID
        String tacNotesServiceName = M2UBusinessOptionsResources.getValue("tac.notes");
        DCCNote tacNotesDCCNote = DCCUtils.getDCCNote(tacNotesServiceName, tacId, req.getLocale());

        String serviceName = tacNotesDCCNote.getSubNote1();
        String serviceMessage = tacNotesDCCNote.getSubServiceName();
        String serviceCode = tacNotesDCCNote.getSubNote2();

        String tacInfo1 = (null == cache.getBillAcctNo() && null != cache.getBillRefNo()) ? String.format("%.14s", cache.getBillRefNo()) : cache.getBillAcctNo();
        String tacInfo2 = cache.getTxnAmtWith100Multiply();

        CreateTACResponseDTO createTACResp = ClarityUtils.createTAC(req, cache.getCustomerDetails(), serviceName, serviceMessage, serviceCode, tacInfo1, tacInfo2);

        if(!"0000".equals(createTACResp.getResponseCode())) {
            // TODO: Shorten the error details need to be return to UIUX
            String errorDetails = String.format("Failed to request TAC from Clarity. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                createTACResp.getTxnRefId(), createTACResp.getResponseCode(), createTACResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            // TODO: We had log the long error details, so skip logging here
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, errorDetails);
        }

        // TODO: Handle in else using "general.status.unsuccessful"

        // TODO: Handling of USSD_Status and mobileUpdateInterval is not necessary, USSD_Status replaced by mobile_update_interval and "tacRC" HTTP session object is set as empty here

        // TODO: Reference Logger.logTransactionDetails()
        // TODO: Agreed by @HuiLee we skip Jewel Crush handling for now, there will be a further discussion on this
        LocalDateTime now = LocalDateTime.now();
        String txnId = DatabaseUtils.generateINETTxnId();
        String txnType = "TAC Request";
        double txnAmt = 0.0;
        String fromAcctId = DASH_VALUE;
        String toAcctId = DASH_VALUE;
        String details = serviceMessage;
        String txnDetails = new StringBuilder(txnType).append(" ").append(serviceMessage).append(" ").append(DateTimeUtils.formatLocalDateTime(now, "dd MMM yyyy")).toString();
        String billAcctId = DASH_VALUE;
        String billRefId = DASH_VALUE;
        String approvalCode = DASH_VALUE;
        String effectiveDate = "00000000";
        String status = M2UApplicationResources.getValue("general.status.successful");

        // TODO: Seems too many parameters, think a way to enhance it later
        createINETTransactionLogRec(req, cache.getCustomerDetails().getUserId(), txnId, txnType, txnAmt,
            fromAcctId, toAcctId, details, txnDetails, billAcctId, billRefId, approvalCode, effectiveDate, status);

        // TODO: Reference Logger.logObservation()
        // TODO: Not sure what is this observation about, check with @HuiLee and decide whether we should cater it
        // TODO: Existing M2U info: Will log a current visitor's transactions into the observation table when the observation mode is turn on. Similar to mbbObsLog().
        // TODO: From the code, it is more related to BV which I believe is safe to be ignore

        // TODO: Need to return to UIUX
        String displayPhoneNo = null;
        String convertedDateTime = null;

        if (serviceName.equals("02")) {
            // TODO: Both Ticketing Payment and Debit Payment are using "01" TAC message code only
            String errorDetails = String.format("Unsupported TAC message code [02] detected. sessionId [%s] token [%s] engineId [%s]", req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.UNSUPPORTED_REQUEST, errorDetails);
        }

        // TODO: Now we only cater for Ticketing Payment, later we will cover Debit Payment as well
        // TODO: Reference M2UTACHandlerServices.processTAC()

        String tacNo = createTACResp.getTac();
        String customServiceMessage = null;
        if (serviceMessage.length() >= 30) {
            customServiceMessage = serviceMessage.substring(0, 30);
        } else {
            customServiceMessage = serviceMessage;
        }

        String tacMessageProp = null;
        if (PaymentType.DEBIT.equals(cache.getPaymentType())) {
            tacMessageProp = "m2002.tac.message3";
        } else if (PaymentType.TICKETING.equals(cache.getPaymentType())) {
            tacMessageProp = "m2002.tac.message.onln.tkt";
        }

        String smsMessageTemplate = M2UApplicationResources.getValue(tacMessageProp, req.getLocale());
        String clarityDateTime = new StringBuilder(createTACResp.getValidUntilDate()).append(createTACResp.getValidUntilTime()).toString();
        convertedDateTime = DateTimeUtils.getLocalDateTimeInString(clarityDateTime, "yyyyMMddHHmmss", DATE_TIME_FORMAT);

        String[] messageParams = { customServiceMessage, tacNo, env.getProperty("CYBER_HOTLINE"), convertedDateTime, "", cache.getDisplayTxnAmt()};
        String smsMessage = MessageFormat.format(smsMessageTemplate, messageParams);

        CustomerDetails customerDetails = cache.getCustomerDetails();
        String customerName = null;
        String customerNo = null;
        if ("02".equalsIgnoreCase(customerDetails.getCustomerType())) {
            // TODO: Handling for company
            customerName = customerDetails.getCompanyName();
            customerNo = customerDetails.getCompanyRegNo();
        } else {
            // TODO: Handling for standard customer, if no new IC, fallback using old IC
            customerName = customerDetails.getCustomerName();
            if (!StringUtils.isEmptyString(customerDetails.getCustomerIcBusreg())) {
                customerNo = customerDetails.getCustomerIcBusreg();
            } else {
                customerNo = customerDetails.getCustomerOldIc();
            }
        }
        if (customerName.contains("'")) {
            customerName = customerName.replace("'", "''");
        }

        // TODO: Reference BVUtils.logSms()
        String phoneNo = createTACResp.getMobileNo();
        String smsPhoneNo = new StringBuilder(phoneNo.substring(0, 3)).append("-").append(phoneNo.substring(3, phoneNo.length())).toString();
        String smsService = "TAC Application";
        String smsStatus = "1";
        createSMSTableRec(txnId, customerNo, customerName, smsPhoneNo, smsMessage, smsService, smsStatus);

        displayPhoneNo = new StringBuilder(phoneNo.substring(0, 3)).append("-").append(phoneNo.substring(3, phoneNo.length() - 4)).append("XXXX").toString();

        updateCache(cache);

        CreateOTPResponseDTO resp = new CreateOTPResponseDTO();
        resp.setSessionId(cache.getSessionId());
        resp.setEngineId(req.getEngineId());
        resp.setToken(cache.getToken());
        resp.setCurrentDate(LocalDateTime.now());
        // TODO: We could use this field to hold customer readable error message
        resp.setError(null);
        resp.setDeviceTokenCookie(req.getDeviceTokenCookie());
        resp.setDeviceTokenFSO(req.getDeviceTokenFSO());

        resp.setMainHeader(M2UApplicationResources.getValue("common.tac.success.mainHeader", req.getLocale()));
        resp.setMobileDisplay(displayPhoneNo);
        resp.setContent1(M2UApplicationResources.getValue("common.tac.success.content1", req.getLocale()));
        resp.setContent2(M2UApplicationResources.getValue("common.tac.success.content2", req.getLocale()));
        resp.setContent3(M2UApplicationResources.getValue("common.tac.success.content3", req.getLocale()));
        resp.setContent4(String.format("(%s).", convertedDateTime));
        resp.setIsTACSent(true);

        // TODO: We dont have secretBadge set in HTTP session, just ignore the logic

        return resp;
    }

    @Override
    public TxnCompletionResponseDTO completeTransaction(TxnCompletionRequestDTO req) throws PaymentException {
        // TODO: Reference M2UTicketsPaymentConfirmedAction.java

        // TODO: Change it to method annotation later
        PaymentServiceUtils.checkIsSystemDowntime();

        DPECache cache = getCache(req.getSessionId());

        // TODO: Reference M2UControllerAction.checkToken(), existing logic is different, it check request "action" parameter to identify M2USTATE, e.g. M2USTATE_CONFIRM, M2USTATE_INIT
        // TODO: Each REST API has dedicated task, we dont support this for the moment, due to that ignore the existing M2U logic
        // TODO: Change it to method annotation later
        PaymentServiceUtils.isValidToken(cache.getToken(), req.getToken());
        cache.setToken(M2UUtils.createToken());

        PayeeDetails payeeDetails = cache.getPayeeDetails();

        if("004".equals(req.getS2uType()) && null != cache.getS2uRefNo() && null != cache.getS2uToken()) {
            // TODO: Handling for S2U Verification
            // TODO: This method will create it own response and return, update this later
            return handleS2UVerification(req, cache);
        }

        // TODO: Handling for SMS TAC and S2U TAC

        // TODO: Reference M2UTicketsPaymentConfirmedAction.execute()
        // TODO: Reference M2UMerchantPaymentConfirmedHelper.runProcess() & M2UMerchantPaymentConfirmedServices.setBean()
        // TODO: Reference M2UGenericBillPaymentServices.initPayee()
        // TODO: Reference M2UGenericBillPaymentServices.initAccount()
        // TODO: Reference M2UGenericBillPaymentServices.isOtherCCAccount()
        // TODO: Existing M2U doesnt use CC from MBB_CC_DETAILS, due to that logic skip in DPE

        // TODO: Reference M2UGenericBillPaymentServices.checkTransferLimit()
        PaymentValidationResult paymentValidationResult = validatePayment(req, cache);
        cache.setPaymentValidationResult(paymentValidationResult);

        // TODO: Reference M2UBillPaymentTransactionServices.initTransaction()
        // TODO: M2U create "transID" (c_sDBTransactionID) from DB sequence, however it only get used at last stage, M2UGenericBillPaymentServices.logTransactionToDB(). Due to that we dont create it now

        // TODO: Since we are using new customer type "DPECUSTOMERTYPE", logic to check RSA customer type: M2UBIZMAKERCUSTOMERTYPE/M2UBIZCHECKERCUSTOMERTYPE will be skip
        // TODO: "refreshFlag" not generated by DPE, skip related logic

        // TODO: Reference M2UGenericBillPaymentServices.setGeneralFnServerServicesExIn()
        // TODO: Reference M2UMerchantMakePaymentServices.setScheduledDateBean()
        // TODO: At the moment DPE always use Today (00000000) as effective date

        // TODO: We are not dealing with RegisteredPayment/UnregisteredPayment payment types, skip related logic

        String tacValue = TACUtils.getTAC(req.getS2uType(), req.getTacValue());

        CustomerDetails customerDetails = cache.getCustomerDetails();

        // TODO: Reference FormatterUtils.getServiceCode()
        // TODO: Reference FormatterUtils.getToAccountCode()
        CreateOnlinePaymentResponseDTO createOnlinePaymentResp = null;
        CreateBillPaymentResponseDTO createBillPaymentResp = null;
        String txnRefId = null;
        String responseCode = null;
        String responseDesc = null;
        String s2uToken = null;

        if(payeeDetails.isOnlinePayment()) {
            createOnlinePaymentResp = ClarityUtils.createOnlinePayment(req, customerDetails, payeeDetails, cache.getTxnAmtWith100Multiply(), req.getS2uType(), tacValue, cache.getBillAcctNo());
            txnRefId = createOnlinePaymentResp.getTxnRefId();
            responseCode = createOnlinePaymentResp.getResponseCode();
            responseDesc = createOnlinePaymentResp.getResponseDesc();
        } else {
            // TODO: At the moment we only support MAX 1 non online bill payment per request
            BillPayment billPayment = ClarityUtils.createNonOnlineBillPayment(customerDetails, cache.getTxnAmtWith100Multiply(), cache.getBillAcctNo(), payeeDetails.getPayeeCode());
            List<BillPayment> billPayments = new ArrayList<>(1);
            billPayments.add(billPayment);

            createBillPaymentResp = ClarityUtils.createBillPayment(req, customerDetails, cache.getTxnAmtWith100Multiply(), req.getS2uType(), tacValue, billPayments, false);
            txnRefId = createBillPaymentResp.getTxnRefId();
            responseCode = createBillPaymentResp.getResponseCode();
            responseDesc = createBillPaymentResp.getResponseDesc();
        }

        // TODO: EBPP has nothing to do with DPE, skip it logic

        // TODO: For non "ibccpublic" user group, "favourite_trnx" always set as "0", in C++ Plugin if it is 0 we fixed to use 1220 service code instead

        // TODO: IMPORTANT!!! In C++ Plugin logic, we did cater both online=yes & online=no options for DPE. Non-online bill payment using another message type "UOBPYZZZ", we will cover it later as it is part of ticketing, #WONG

        // TODO: Prepaid is not related to DPE, skip it

        // TODO: Reference M2UGenericBillPaymentServices.finalizeTransaction()

        // TODO: Reference M2UGenericBillPaymentServices.createAndConfirmTransaction(), related to BV setup, skip it for DPE

        String txnId = DatabaseUtils.generateINETTxnId();

        String statusCode = null;
        TransactionStatus txnStatus = null;
        String notifyDesc = null;

        String eventDesc = null;
        if(PaymentType.TICKETING.equals(cache.getPaymentType())) {
            eventDesc = "Online Ticketing Payment"; // Ticketing
        } else if (PaymentType.DEBIT.equals(cache.getPaymentType())) {
            // TODO: Code wont reach here at the moment since we stop the transaction if is Debit payment in post authentication stage
            eventDesc = "DPE Payment"; // Ticketing
        }

        if(!"0000".equals(responseCode)) {
            // TODO: Existing M2U only stop transaction if response code = 00A4 throwing error, check with @HuiLee why?
            if("00A4".equals(responseCode)) {
                // TODO: Shorten the error details need to be return to UIUX
                String errorDetails = String.format("Failed to create payment to Clarity. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                    txnRefId, responseCode, responseDesc, req.getSessionId(), req.getToken(), req.getEngineId());
                // TODO: We had log the long error details, so skip logging here
                // TODO: 00A4 is MAX TAC Retries reached
                throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, errorDetails);
            }

            // TODO: Migrate from above code (immediate after calling Clarity) to here
//            recordStatus = M2UApplicationResources.getValue("m1200.unsuccessful", req.getLocale());
            txnStatus = TransactionStatus.UNSUCCESSFUL;
            statusCode = "01";
            // TODO: For failed case, RSA notify send in existing M2U
            // TODO: Since we are using new customer type "DPECUSTOMERTYPE", logic to check RSA customer type: M2UBIZMAKERCUSTOMERTYPE/M2UBIZCHECKERCUSTOMERTYPE will be skip
            // TODO: M2U using Clarity in part of the notification. Just follow for this
            notifyDesc = String.format("Unsuccessful %s. [%s]", eventDesc, responseCode);

        } else {
            // TODO: Both Online or Non-online always stick to 1 occurrence only

            // TODO: Existing M2U for loop logic looks weird, it keep overwrite previous data for multi bills, check with @HuiLee

            // TODO: For DPE, we assumed only 1 bill per request
            // TODO: Both Online and Non-online might not share same set of response fields, please take note, #WONG

            // TODO: Online payment response doesnt involve individualRC, approvalCode, skip the logic

            // TODO: At the moment our transaction for DPE is always today
            // TODO: PINLESS is not covered in DPE

            if(("004".equals(req.getS2uType()) && payeeDetails.isTACRequired())) {
                txnStatus = TransactionStatus.EXPIRED;
                s2uToken = (payeeDetails.isOnlinePayment()) ? createOnlinePaymentResp.getSecure2uToken() : createBillPaymentResp.getPaymentsMade().get(0).get("secure2uToken");
                createMBBRelayRec(customerDetails.getUserId(), s2uToken, txnId, txnStatus.getDesc());
                // TODO: For DPE, we are using INET txn id as S2U Ref No. instead of the one return by Clarity (FYI, Clarity return +000000 which is not meaningful)
                cache.setS2uRefNo(txnId);
                cache.setS2uToken(s2uToken);
            } else {
                txnStatus = TransactionStatus.SUCCESSFUL;
            }

            statusCode = "00";
            notifyDesc = String.format("Successful %s", eventDesc);
        }
        cache.setTxnStatus(txnStatus);

//        if(noOfOccurrences > 0) {
            // TODO: For now we always treat DPE only support 1 bill per request and Today as effective date
            // TODO: In existing M2U if condition, we check whether to display the new balance, since we already have the balance in Clarity response, we dont need this logic
            // TODO: Anything related to M2UBIZMAKERCUSTOMERTYPE/M2UBIZCHECKERCUSTOMERTYPE shall be skip for now
//        }

        // TODO: DPE dont have approval code for now, skip related logic
        // TODO: Skip the Mobile Aggregator logic for DPE
        // TODO: Skip the EPF logic for DPE

        // TODO: txnId was set during M2UBillPaymentTransactionServices.initTransaction()
        LocalDateTime now = LocalDateTime.now();
        // TODO: Not sure is it correct to substring in this range, check with @HuiLee
        String customTxnId = txnId.substring(10, 20);

        // TODO: Anything related to M2UBIZMAKERCUSTOMERTYPE/M2UBIZCHECKERCUSTOMERTYPE shall be skip for now

        PaymentAdaptServiceType paymentAdaptServiceType = PaymentAdaptServiceType.CREATE_PAYMENT_TO_CLARITY_NOTIFY;
        // TODO: Adapt required shorter txnId, due to that we create a custom for it, as per existing M2U
        // TODO: For S2U Verification, feel that we shouldn't notify until user approve it, however might miss if user never approve it, check with @HuiLee
        AdaptNotifyResponseDTO notifyResp = AdaptUtils.notify(
            req, customerDetails, notifyDesc, paymentAdaptServiceType, req.getDeviceTokenCookie(), req.getDeviceTokenFSO(), customTxnId);

        if(null != notifyResp) {
            // TODO: RSA device details need to be reference in subsequent RSA call, stored them in both request and cache
            AdaptUtils.updateDeviceTokenDetails(notifyResp, req);
        }

        // TODO: Anything related to M2UBIZMAKERCUSTOMERTYPE/M2UBIZCHECKERCUSTOMERTYPE shall be skip for now

        // TODO: Reference M2UGenericBillPaymentServices.logTransactionToDB()

        // TODO: All other payment types like "M", "W", "P", "Kiosk" is not cater in DPE, so logic skip
        // TODO: Since we only support Today effective date, we can get use LocalDateTime.now() directly
        // TODO: Anything related to M2UBIZMAKERCUSTOMERTYPE/M2UBIZCHECKERCUSTOMERTYPE shall be skip for now

        logTransactionDetails(req, cache, paymentValidationResult, req.getS2uType(), txnStatus, txnId);

        // TODO: Reference BVUtils.getPDFReceiptLink()
        // TODO: Reference BVUtils.getReceiptOther()
//        String receiptOthers = getReceiptOthers(receiptMap);

        // TODO: THE LOGIC IS BIT COMPLICATED, will cover later, it will return a receipt link, and also setting lot details to the BVSessionObjectProperties
        // TODO: Here we will set to bean values "receiptToPrint" & "printValue"
        // TODO: Receipt generated here is used for success case SMS TAC, S2U TAC and S2U Verification as well

        // TODO: In new platform we will not generate here, we will have another REST API to cater that

        GetAccountDetailsResponseDTO getAccountDetailsResp = ClarityUtils.getAccountDetails(req, customerDetails);

        if(!"0000".equals(getAccountDetailsResp.getResponseCode())) {
            // TODO: Shorten the error details need to be return to UIUX
            String errorDetails = String.format("Failed to get account details from Clarity. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                    getAccountDetailsResp.getTxnRefId(), getAccountDetailsResp.getResponseCode(), getAccountDetailsResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            // TODO: We had log the long error details, so skip logging here
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, errorDetails);
        }

        Account fromAcct = customerDetails.getFromAccount();
        BigDecimal bdBalance = ClarityUtils.getAccountBalance(getAccountDetailsResp, fromAcct);
        String displayBalAmt = PaymentServiceUtils.formatAmountWithCountryCurrency(bdBalance, req.getCountryCode());
        fromAcct.setBalance(bdBalance);
        fromAcct.setDisplayBalAmt(displayBalAmt);

        if(PaymentType.TICKETING.equals(cache.getPaymentType())) {
            // TODO: For Ticketing Payment we trigger => super.insertPNTable ("", "pn_table2");
            createPNTable2Rec(cache, " ", "", " ", statusCode, txnId);

        } else if (PaymentType.DEBIT.equals(cache.getPaymentType())) {
            // TODO: For Debit Payment we trigger => super.insertPNTableCommonTransaction();
            // TODO: At the moment, the code flow wont reach here
            // TODO: The logic will be cover later
        }

        // TODO: We dont support request parameter "merchantTxnRefNo" in DPE yet, skip the logic for now

        // TODO: Reference M2UOnlineTicketingUtil.getOnlineticketingPayeeDetails()
        // TODO: Following code use to control redirectURL value, typeOfPayment in DPE so far used by GSC only, which we ignore for now, #WONG
        // TODO: However both condition body below are exactly same, which means we will only cater first if logic condition only
        // TODO: typeOfPayment = 3 is not related to DPE, check further #WONG
//        if(!typeOfPayment.equals("3") && !typeOfPayment.equalsIgnoreCase("G")){ <= DPE using this
//        if(typeOfPayment.equals("3") && (merchantID.equalsIgnoreCase("1ZT") || merchantID.equalsIgnoreCase("BL1") || merchantID.equalsIgnoreCase("CFS"))){
        // TODO: Here if it is GSC, skip forming the redirectUrl

        boolean requireCallbackProps = false;

        // TODO: Forming the redirect URL
        String redirectUrl = null;
        String status = "01";
        if(TransactionStatus.SUCCESSFUL.equals(txnStatus)) {
            status = "00";
        }
        if(TransactionStatus.EXPIRED.equals(txnStatus)) {
            requireCallbackProps = true;
        }

        List<Object> dynamicFields = createDynamicFieldsForCompleteTransaction(req, cache, requireCallbackProps);

        if(!StringUtils.isEmptyString(payeeDetails.getPayeeURL())) {
            String transDate = DateTimeUtils.formatLocalDateTime(now, DATE_TIME_FORMAT);
            String redirectUrlTemplate = "%s?transDate=%s&status=%s&transAmount=%s&referenceNo=%s&payeeCode=%s&approvalCode=&bankRefNo=&accountNo=%s&corpName=%s";
            redirectUrl = String.format(redirectUrlTemplate, payeeDetails.getPayeeURL(), transDate, status, cache.getTxnAmtWith100Multiply(), cache.getBillRefNo(), payeeDetails.getPayeeCode(), cache.getBillAcctNo(), payeeDetails.getFullName());
        }

        updateCache(cache);

        TxnCompletionResponseDTO resp = new TxnCompletionResponseDTO();
        resp.setSessionId(cache.getSessionId());
        resp.setEngineId(req.getEngineId());
        resp.setToken(cache.getToken());
        resp.setCurrentDate(LocalDateTime.now());
        // TODO: We could use this field to hold customer readable error message
        // TODO: Existing M2U will put the error message + error code return from Clarity and set here in case error
        // TODO: Existing M2U based on Clarity error code and retrieve the error message from Application resources

        if(!"0000".equals(responseCode)) {
            // TODO: We might want to perform the user readable mapping message here
            Map<String, String> errorMap = PaymentServiceUtils.createErrorMap(responseCode, responseDesc, Channel.M2U);
            resp.setError(errorMap);
        }

        resp.setDeviceTokenCookie(req.getDeviceTokenCookie());
        resp.setDeviceTokenFSO(req.getDeviceTokenFSO());

        resp.setTitle(cache.getPaymentType().getTitle());
        resp.setDynamicFields(dynamicFields);
        resp.setRedirectURL(redirectUrl);

        // TODO: If success case we need return
        if(TransactionStatus.SUCCESSFUL.equals(txnStatus)) {
            resp.setReceiptURL(pdfGenerationURL);
        }

        // TODO: Only Secure verification should set this as per M2U existing logic
        if("004".equals(req.getS2uType())) {
            resp.setS2uType(req.getS2uType());
            resp.setIsS2UCallback(true);
            resp.setIsS2UVerification(true);
            resp.setIsTACRequired(false);
        }

        // TODO: We might want to apply multi language here, but existing M2U doesn't
        resp.setStatusDesc(String.format("Transaction %s", txnStatus.getDesc()));

        // TODO: Commented and check with UIUX team are follow fields necessary?
//        resp.setIsInitiate(false);
//        resp.setIsMobileFullScreen(false);
//        resp.setHasLocalPagination(false);
//        resp.setHasAccordian(false);

        return resp;
    }

    @Override
    public ByteArrayInputStream generatePDFReceipt(PDFReceiptGenerationRequestDTO req) throws PaymentException {
        // TODO: Change it to method annotation later
        PaymentServiceUtils.checkIsSystemDowntime();

        DPECache cache = getCache(req.getSessionId());

        // TODO: Change it to method annotation later
        PaymentServiceUtils.isValidToken(cache.getToken(), req.getToken());
        cache.setToken(M2UUtils.createToken());

        PayeeDetails payeeDetails = cache.getPayeeDetails();

        String txnType = null;
        if(payeeDetails.isOnlinePayment()) {
            txnType = M2UApplicationResources.getValue("receipt.transaction.bill.payment.online.open", req.getLocale());
        } else {
            txnType = M2UApplicationResources.getValue("receipt.transaction.bill.payment.open", req.getLocale());
        }

        String receiptNote = M2UApplicationResources.getValue("receipt.note", req.getLocale());

        ByteArrayInputStream inputStream = ReceiptUtils.generateReceiptPDF(
            payeeDetails,
            txnType,
            cache.getBillAcctNo(),
            cache.getBillRefNo(),
            cache.getCustomerDetails().getFromAccount().getDisplayNo(),
            cache.getDisplayTxnAmt(),
            receiptNote,
            cache.getTxnStatus(),
            req.getLocale()
        );

        updateCache(cache);

        return inputStream;
    }

    private TxnCompletionResponseDTO handleS2UVerification(AbstractDPERequestDTO req, DPECache cache) throws PaymentException {
        // TODO: Reference M2USecure2uCallbackHandlerHelper.retrieveTxnStatus() && M2USecure2uCallbackHandlerServices.retrieveTxnStatus()

        MBBRelay mbbRelay = mbbRelayRepository.findByMbbRelayIdTransactionRefIdAndMbbRelayIdTokenId(cache.getS2uRefNo(), cache.getS2uToken());
        if(null == mbbRelay) {
            String errorDetails = String.format("No record found with transactionRefId [%s] tokenId [%s]. sessionId [%s] token [%s] engineId [%s]",
                cache.getS2uRefNo(), cache.getS2uToken(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.DATA_NOT_FOUND, errorDetails);
        }

        // TODO: Reference M2UOnlineTicketingUtil.getOnlineticketingPayeeDetails()
        // TODO: As for now suggest to return similar thing as first time, and further clarify with UIUX team later

        // TODO: For S2U verification, beginning stage status was set as EXPIRED and no receipt need to be generated, however if it status in MBB_RELAY updated to "Successful" then receipt is required

        // TODO: Reference M2UTicketsPaymentConfirmedAction.execute()
        String statusDesc = null;
        boolean isS2UCallback = false;
        CustomerDetails customerDetails = cache.getCustomerDetails();
        PayeeDetails payeeDetails = cache.getPayeeDetails();
        PaymentValidationResult paymentValidationResult = cache.getPaymentValidationResult();

        TransactionStatus txnStatus = TransactionStatus.getByDesc(mbbRelay.getStatus());

        switch(txnStatus) {
            case SUCCESSFUL:
                statusDesc = "Transaction Successful";
                // TODO: For succes case, Clarity will update the record will updated info, we just reuse instead of call Clarity again
                if(null != mbbRelay.getFromAccBalance()) {
                    String tempBalAmt = mbbRelay.getFromAccBalance().substring(1);
                    double doubleBalAmt = Double.parseDouble(tempBalAmt)/100;
                    BigDecimal bdBalance = BigDecimal.valueOf(doubleBalAmt).setScale(2, RoundingMode.HALF_UP);
                    String displayBalAmt = PaymentServiceUtils.formatAmountWithCountryCurrency(bdBalance, req.getCountryCode());
                    customerDetails.getFromAccount().setBalance(bdBalance);
                    customerDetails.getFromAccount().setDisplayBalAmt(displayBalAmt);
                }
                break;
            case UNSUCCESSFUL:
            case REJECTED:
                statusDesc = "Transaction Unsuccessful";
                break;
            case EXPIRED:
                // TODO: Existing M2U set error details in map, however we skip this first until we finalize the error output expected by UIUX
                statusDesc = "Transaction Unsuccessful";
                isS2UCallback = true;
                break;
            case UNKNOWN:
                String errorDetails = String.format("Unsupported txnStatus [%s] detected. sessionId [%s] token [%s] engineId [%s]", txnStatus, req.getSessionId(), req.getToken(), req.getEngineId());
                log.error(errorDetails);
                throw new PaymentException(PaymentServiceStatus.INTERNAL_SERVER_ERROR, errorDetails);
        }
        cache.setTxnStatus(txnStatus);

        List<Object> dynamicFields = createDynamicFieldsForCompleteTransaction(req, cache, isS2UCallback);

        String txnType = (payeeDetails.isOnlinePayment()) ? "OnlinePayment (Secure Verification)" : "BillPayment (Secure Verification)";

        // TODO: Forming the redirect URL
        String redirectUrl = null;
        String status = "01";
        if(TransactionStatus.SUCCESSFUL.equals(txnStatus)) {
            status = "00";
            // TODO: Existing M2U dont have this to cater for successful S2U verification, should we put it in? Check with @HuiLee
            createINETControlDetailsRec(customerDetails, payeeDetails, paymentValidationResult, cache.getDoubleTxnAmt(), txnType);
        }

        if(!StringUtils.isEmptyString(payeeDetails.getPayeeURL())) {
            String transDate = DateTimeUtils.formatLocalDateTime(LocalDateTime.now(), DATE_TIME_FORMAT);
            String redirectUrlTemplate = "%s?transDate=%s&status=%s&transAmount=%s&referenceNo=%s&payeeCode=%s&approvalCode=&bankRefNo=&accountNo=%s&corpName=%s";
            redirectUrl = String.format(redirectUrlTemplate, payeeDetails.getPayeeURL(), transDate, status, cache.getTxnAmtWith100Multiply(), cache.getBillRefNo(), payeeDetails.getPayeeCode(), cache.getBillAcctNo(), payeeDetails.getFullName());
        }

        updateCache(cache);

        TxnCompletionResponseDTO resp = new TxnCompletionResponseDTO();
        resp.setSessionId(cache.getSessionId());
        resp.setEngineId(req.getEngineId());
        resp.setToken(cache.getToken());
        resp.setCurrentDate(LocalDateTime.now());
        // TODO: We could use this field to hold customer readable error message
        // TODO: Existing M2U will put the error message + error code return from Clarity and set here in case error
        // TODO: Exisring M2U based on Clarity error code and retrieve the error message from Application resources
        resp.setError(null);
        resp.setDeviceTokenCookie(req.getDeviceTokenCookie());
        resp.setDeviceTokenFSO(req.getDeviceTokenFSO());

        resp.setTitle(cache.getPaymentType().getTitle());
        resp.setDynamicFields(dynamicFields);
        resp.setRedirectURL(redirectUrl);
        // TODO: If success case we need return
        if(TransactionStatus.SUCCESSFUL.equals(txnStatus)) {
            resp.setReceiptURL(pdfGenerationURL);
        }

        // TODO: Only Secure verification should set this as per M2U existing logic
        if(isS2UCallback) {
            resp.setS2uType("004");
            resp.setIsS2UCallback(true);
            resp.setIsS2UVerification(true);
            resp.setIsTACRequired(false);
        }

        // TODO: We might want to apply multi language here, but existing M2U doesn't
        resp.setStatusDesc(statusDesc);

        // TODO: Commented and check with UIUX team are follow fields necessary?
//        resp.setIsInitiate(false);
//        resp.setIsMobileFullScreen(false);
//        resp.setHasLocalPagination(false);
//        resp.setHasAccordian(false);

        return resp;
    }

    private PaymentValidationResult validatePayment(AbstractDPERequestDTO req, DPECache cache) throws PaymentException {
        Account fromAcct = cache.getCustomerDetails().getFromAccount();
        MBBPaymentLimit mbbPaymentLimit = mbbPaymentLimitRepository.findByMbbPaymentLimitIdUserIdAndMbbPaymentLimitIdPayeeCode(cache.getCustomerDetails().getUserId(), cache.getPayeeDetails().getPayeeCode());

        Long maxLimit = null;
        // TODO: For DPE we only support Today, so the value is 0
        long noOfDays = 0;
        long totalTxn = 0;
        Long maxTxn = null;
        Double maxAmount = null;
        double totalAmount = 0.0;
        double sumAmount;
        List<Object[]> objs = null;

        if(null != mbbPaymentLimit) {
            maxLimit = mbbPaymentLimit.getMaxLimit();
        }

        CustomerDetails customerDetails = cache.getCustomerDetails();
        PayeeDetails payeeDetails = cache.getPayeeDetails();
        boolean skipCheckIfMAXAmtIsZero = false;

        switch(fromAcct.getType()) {
            case PaymentServiceConstant.CREDIT_CARD:
            case PaymentServiceConstant.PREPAID_CCARD:
            case PaymentServiceConstant.CHARGE_CARD:
                // TODO: Reference M2UGenericBillPaymentServices.getCCLimit()
                // TODO: Reference M2UGenericBillPaymentServices.getRecLoop(), skip handling this for now
                INETCCControlParameters inetCCControlParameters = inetCCControlParametersRepository.findByPayeeCode(payeeDetails.getPayeeCode());

                if(null != inetCCControlParameters) {
                    noOfDays = (null == inetCCControlParameters.getNumberOfDays()) ? 0 : inetCCControlParameters.getNumberOfDays();
                    maxTxn = inetCCControlParameters.getMaxTransaction();
                    maxAmount = inetCCControlParameters.getMaxAmount();
                }

                objs = inetPaymentControlDetailsRepository.countTotalTxnsAndToTalAmounts(customerDetails.getUserAlias(), payeeDetails.getPayeeCode(), LocalDateTime.now().minusDays(noOfDays));
                if(!objs.isEmpty()) {
                    Object[] obj = objs.get(0);
                    totalTxn = (null == obj[0]) ? 0 : (long) obj[0];
                    totalAmount = (null == obj[1]) ? 0.0 : (double) obj[1];
                }

                break;
            default:
                // TODO: Reference M2UGenericBillPaymentServices.getAccountLimit()
                // TODO: Reference M2UGenericBillPaymentServices.getRecLoop(), we only deal with 1 payment at a time, recLoop always empty i assumed
                INETDebitControlParameters inetDebitControlParameters = inetDebitControlParametersRepository.findByPayeeCode(payeeDetails.getPayeeCode());
                if(null != inetDebitControlParameters) {
                    maxTxn = inetDebitControlParameters.getMaxTransaction();
                    maxAmount = inetDebitControlParameters.getMaxAmount();
                }

                objs = inetDebitControlDetailsRepository.countTotalTxnsAndToTalAmounts(customerDetails.getUserId(), payeeDetails.getPayeeCode(), LocalDateTime.now());
                if(!objs.isEmpty()) {
                    Object[] obj = objs.get(0);
                    if(null != obj[0]) {
                        totalTxn = (long) obj[0];
                    }
                    if(null != obj[1]) {
                        totalAmount = (double) obj[1];
                    }
                }

                // TODO: For non Card payment, there is a setting where if MAX amount set to 0 in DB, we should skip limit checking
                if(null != maxAmount && 0 == maxAmount) {
                    skipCheckIfMAXAmtIsZero = true;
                }
        }

        // TODO: DPE dont support PINLESS for now, skip the related logic
        sumAmount = totalAmount + cache.getDoubleTxnAmt();

        // TODO: First check MAX limit is it exceeded
        if(null != maxLimit && sumAmount > maxLimit.doubleValue()) {
            // TODO: Need to replace with business error message return to UIUX, refactor this later
            String errorDetails = String.format("Sum amount [%.2f] exceeded payee max limit [%.2f] set by user. userId [%s] payeeCode [%s] amount [%.2f] sessionId [%s] token [%s] engineId [%s]",
                sumAmount, maxLimit.doubleValue(), customerDetails.getUserId(), payeeDetails.getPayeeCode(), cache.getDoubleTxnAmt(), req.getSessionId(), req.getToken(), req.getEngineId());
            throw new PaymentException(PaymentServiceStatus.EXCEEDED_LIMIT_ALLOWED, errorDetails);
        }

        // TODO: Second check MAX amount, skip checking if the MAX amount is 0, handling for Digi Prepaid as per existing M2U
        if(null != maxAmount && !skipCheckIfMAXAmtIsZero && sumAmount > maxAmount) {
            // TODO: Need to replace with business error message return to UIUX, refactor this later
            String errorDetails = String.format("Sum amount [%.2f] exceeded INET max amount [%.2f] allowed for the payee. userId [%s] payeeCode [%s] amount [%.2f] sessionId [%s] token [%s] engineId [%s]",
                sumAmount, maxAmount, customerDetails.getUserId(), payeeDetails.getPayeeCode(), cache.getDoubleTxnAmt(), req.getSessionId(), req.getToken(), req.getEngineId());
            throw new PaymentException(PaymentServiceStatus.EXCEEDED_LIMIT_ALLOWED, errorDetails);
        }

        // TODO: Finally perform checking on MAX transaction allowed
        if (null != maxTxn && totalTxn >= maxTxn) {
            // TODO: Need to replace with business error message return to UIUX, refactor this later
            String errorDetails = String.format("Total transaction [%d] exceeded INET max transaction [%d] allowed for the payee. userId [%s] payeeCode [%s] sessionId [%s] token [%s] engineId [%s]",
                totalTxn, maxTxn, customerDetails.getUserId(), payeeDetails.getPayeeCode(), req.getSessionId(), req.getToken(), req.getEngineId());
            throw new PaymentException(PaymentServiceStatus.EXCEEDED_LIMIT_ALLOWED, errorDetails);
        }

        PaymentValidationResult paymentValidationResult = new PaymentValidationResult();
        paymentValidationResult.setMaxLimit(maxLimit);
        paymentValidationResult.setMaxAmount(maxAmount);
        paymentValidationResult.setMaxTxn(maxTxn);

        return paymentValidationResult;
    }

    private List<Object> createDynamicFieldsForCompleteTransaction(AbstractDPERequestDTO req, DPECache cache, boolean requiredCallback) {
        List<Object> items = new ArrayList<>();
        Account fromAcct = cache.getCustomerDetails().getFromAccount();
        PayeeDetails payeeDetails = cache.getPayeeDetails();

        Map<String, Object> amountMap = UIUXUtils.createSummaryItem(cache.getDisplayTxnAmt(), FULL_LABEL_FIELD, M2UApplicationResources.getValue(AMOUNT_LABEL, req.getLocale()), null, null);
        Map<String, Object> corporationNameMap = UIUXUtils.createSummaryItem(payeeDetails.getFullName(), FULL_LABEL_FIELD, M2UApplicationResources.getValue(CORPORATION_NAME_LABEL, req.getLocale()), null, null);
        Map<String, Object> effectiveDateMap =  UIUXUtils.createSummaryItem(M2UApplicationResources.getValue(TODAY_VALUE, req.getLocale()), FULL_LABEL_FIELD, M2UApplicationResources.getValue(EFFECTIVE_DATE_LABEL, req.getLocale()), null, null);
        Map<String, Object> referenceMap = UIUXUtils.createSummaryItem(cache.getBillRefNo(), FULL_LABEL_FIELD, M2UApplicationResources.getValue(REFERENCE_LABEL, req.getLocale()), null, null);
        String fromAcctDisplay = new StringBuilder(fromAcct.getName()).append(" ").append(fromAcct.getDisplayNo()).toString();
        Map<String, Object> accountMap =  UIUXUtils.createSummaryItem(fromAcctDisplay, FULL_LABEL_FIELD, M2UApplicationResources.getValue(FROM_ACCOUNT_LABEL, req.getLocale()), M2UApplicationResources.getValue("m1009.available.balance", req.getLocale()), fromAcct.getDisplayBalAmt());

        items.add(amountMap);
        items.add(corporationNameMap);
        items.add(effectiveDateMap);
        items.add(referenceMap);
        items.add(accountMap);

        List<Object> finalItems = new ArrayList<>();
        finalItems.add(items);

        if(requiredCallback) {
            // TODO: Revisit and check with UIUX team about this callbackProps usage, is this to proceed next page?
            Map<String, Object> callbackProps = new HashMap<>();
            callbackProps.put("BV_SessionID", req.getSessionId());
            callbackProps.put("BV_EngineID", req.getEngineId());
            callbackProps.put(ACTION_FIELD, "Confirm");
            callbackProps.put(TOKEN_FIELD, cache.getToken());

            Map<String, Object> confirmButton = new HashMap<>();
            Map<String, Object> action = new HashMap<>();
            // TODO: Revisit about the REST API URL issues, it shouldn't be tight to 1 instance only, think about flexibility
            action.put("actionURL", txnCompletionURL);
            action.put("actionType", "restAPI");
            action.put("requireValidation", Boolean.FALSE);
            action.put("responseRequired", Boolean.TRUE);
            action.put("stopScroll", Boolean.TRUE);

            confirmButton.put("type", "confirm");
            confirmButton.put(ACTION_FIELD, action);
            confirmButton.put("callbackProps", callbackProps);


            finalItems.add(confirmButton);
        }

        return UIUXUtils.createDynamicFields(finalItems, null);
    }

    private List<Object> createDynamicFieldsForConfirmTransaction(AbstractDPERequestDTO req, DPECache cache) {
        // TODO: Reference M2UOnlineTicketingUtil.getOnlineticketingPayeeDetails()
        // TODO: Need UIUX team to discuss about the following contents return to UIUX page
        List<Object> items = new ArrayList<>();
        Account fromAcct = cache.getCustomerDetails().getFromAccount();

        Map<String, Object> amountMap = UIUXUtils.createSummaryItem(cache.getDisplayTxnAmt(), FULL_LABEL_FIELD, M2UApplicationResources.getValue(AMOUNT_LABEL, req.getLocale()), null, null);
        Map<String, Object> corporationNameMap = UIUXUtils.createSummaryItem(cache.getPayeeDetails().getFullName(), FULL_LABEL_FIELD, M2UApplicationResources.getValue(CORPORATION_NAME_LABEL, req.getLocale()), null, null);
        Map<String, Object> effectiveDateMap =  UIUXUtils.createSummaryItem(M2UApplicationResources.getValue(TODAY_VALUE, req.getLocale()), FULL_LABEL_FIELD, M2UApplicationResources.getValue(EFFECTIVE_DATE_LABEL, req.getLocale()), null, null);
        Map<String, Object> referenceMap = UIUXUtils.createSummaryItem(cache.getBillRefNo(), FULL_LABEL_FIELD, M2UApplicationResources.getValue(REFERENCE_LABEL, req.getLocale()), null, null);
        String fromAcctDisplay = new StringBuilder(fromAcct.getName()).append(" ").append(fromAcct.getDisplayNo()).toString();
        Map<String, Object> accountMap =  UIUXUtils.createSummaryItem(fromAcctDisplay, FULL_LABEL_FIELD, M2UApplicationResources.getValue(FROM_ACCOUNT_LABEL, req.getLocale()), M2UApplicationResources.getValue("m1009.available.balance", req.getLocale()), fromAcct.getDisplayBalAmt());

        items.add(amountMap);
        items.add(corporationNameMap);
        items.add(effectiveDateMap);
        items.add(referenceMap);
        items.add(accountMap);

        // TODO: Check with UIUX team about this callbackProps usage and what should be set
        Map<String, Object> callbackProps = new HashMap<>();
        callbackProps.put("BV_SessionID", req.getSessionId());
        callbackProps.put("BV_EngineID", req.getEngineId());
        callbackProps.put(ACTION_FIELD, "Confirm");
        callbackProps.put(TOKEN_FIELD, cache.getToken());

        // TODO: Check with UIUX team about this callbackPropsEdit usage and what should be set
        Map<String, Object> callbackPropsEdit =  new HashMap<>();
        callbackPropsEdit.put("sessionId", req.getSessionId());
        callbackPropsEdit.put("engineId", req.getEngineId());
        // TODO: Not sure is it right, check with UIUX team
        callbackPropsEdit.put(ACTION_FIELD, "Back");
        callbackPropsEdit.put(TOKEN_FIELD, cache.getToken());

        // TODO: Check again the REST API URL issues, we shouldn't hardcode and how UIUX shall call it?
        // TODO: Shall we handle multi language in the button as well?
        Map<String, Object> actionItems = UIUXUtils.createActionItems(postAuthenticationURL, "icon", "default", "summaryBlock", PaymentType.TICKETING.getTitle(), callbackPropsEdit, items);

        Map<String, Object> confirmButton = new HashMap<>();
        Map<String, Object> action = new HashMap<>();
        // TODO: Check again the REST API URL issues, we shouldn't hardcode and how UIUX shall call it?
        action.put("actionURL", txnCompletionURL);
        action.put("actionType", "restAPI");
        action.put("requireValidation", Boolean.FALSE);
        action.put("responseRequired", Boolean.TRUE);
        action.put("stopScroll", Boolean.TRUE);

        confirmButton.put("type", "confirm");
        confirmButton.put(ACTION_FIELD, action);
        confirmButton.put("callbackProps", callbackProps);

        List<Object> finalItems = new ArrayList<>();
        finalItems.add(actionItems);
        finalItems.add(confirmButton);

        // TODO: Shall we handle multi language in the button as well?
        String sectionTitle = "Please check your info before we proceed";
        return UIUXUtils.createDynamicFields(finalItems, sectionTitle);
    }

    private List<Object> createDynamicFieldsForPostAuthentication(AbstractDPERequestDTO req, DPECache cache) {
        List<Object> items = new ArrayList<>();
        List<Object> displayAccounts = UIUXUtils.createAccountOptions(cache.getCustomerDetails().getAccounts());

        Map<String, Object> amountMap = UIUXUtils.createField(M2UApplicationResources.getValue(AMOUNT_LABEL, req.getLocale()), "amount", cache.getDisplayTxnAmt(), "text",null, "30", true, null, null, "", "", false, "", "1", null, true);
        Map<String, Object> corporationNameMap = UIUXUtils.createField(M2UApplicationResources.getValue(CORPORATION_NAME_LABEL, req.getLocale()), "payeeName", cache.getPayeeDetails().getFullName(), "text", null, "30", true, null, null, "", "", false, "", "1", null, true);
        Map<String, Object> effectiveDateMap = UIUXUtils.createField(M2UApplicationResources.getValue(EFFECTIVE_DATE_LABEL, req.getLocale()), "effectiveDate", M2UApplicationResources.getValue(TODAY_VALUE, req.getLocale()), "text", null, "30", true, null, null, "", "", false, "", "1", null, true);
        Map<String, Object> referenceMap = UIUXUtils.createField(M2UApplicationResources.getValue(REFERENCE_LABEL, req.getLocale()), "merchantTxnRefNo", cache.getBillRefNo(), "text", null, "30", true, null, null, "", "", false, "", "1", null, true);
        Map<String, Object> accountMap = UIUXUtils.createField(M2UApplicationResources.getValue(FROM_ACCOUNT_LABEL, req.getLocale()), "fromAccount", cache.getBillRefNo(), "select", displayAccounts, "30", true, null, null, "", "", false, "", "1", null, false);

        items.add(amountMap);
        items.add(corporationNameMap);
        items.add(effectiveDateMap);
        items.add(referenceMap);
        items.add(accountMap);

        // TODO: Check with UIUX team about this callbackProps usage and what should be set
        Map<String, Object> callbackProps =  new HashMap<>();
        callbackProps.put("sessionId", req.getSessionId());
        callbackProps.put("engineId", req.getEngineId());
        callbackProps.put(TOKEN_FIELD, cache.getToken());
        callbackProps.put(ACTION_FIELD, "Continue");

        // TODO: Check again the REST API URL issues, we shouldn't hardcode and how UIUX shall call it?
        // TODO: Shall we handle multi language in the button as well?
        Map<String, Object> itemBlock = UIUXUtils.createItemBlock("", "PAY", "button", "center", txnConfirmationURL, new ArrayList<>(), callbackProps, "Success", true, true,null);
        List<Object> blockItems = new ArrayList<>();
        blockItems.add(itemBlock);
        Map<String, Object> block = new HashMap<>();
        block.put("type", "block");
        block.put("items", blockItems);
        items.add(block);

        // TODO: Shall we handle multi language in the button as well?
        String sectionTitle = "Pay to " + cache.getPayeeDetails().getFullName();
        return UIUXUtils.createDynamicFields(items, sectionTitle);
    }

    private String getThemeName(int timeForTheme, boolean isBasic) {
        if (timeForTheme <= 12) {
            if(isBasic) {
                return "Basic Good Morning";
            } else {
                return "Good Morning";
            }
        } else if(timeForTheme <= 21) {
            if(isBasic) {
                return "Basic Good Afternoon";
            } else {
                return "Good Afternoon";
            }
        } else {
            if(isBasic) {
                return "Basic Good Evening";
            } else {
                return "Good Evening";
            }
        }
    }

    private CustomerDetails updateCustomerDetailsWithBVInfo(CustomerDetails customerDetails, BVUser bvUser) {
        BVUserProfile bvUserProfile = bvUser.getBvUserProfile();
        customerDetails.setUserId(bvUser.getUserId());
        customerDetails.setUserAlias(bvUser.getUserAlias());
        customerDetails.setCustomerType(bvUserProfile.getMbbCustomerType());
        customerDetails.setCustomerName(bvUserProfile.getMbbCustomerName());
        customerDetails.setCustomerIcBusreg(bvUserProfile.getMbbCustomerIcBusreg());
        customerDetails.setCustomerOldIc(bvUserProfile.getMbbOldIc());
        customerDetails.setCompanyName(bvUserProfile.getMbbCompanyName());
        customerDetails.setCompanyRegNo(bvUserProfile.getMbbCompanyRegno());
        customerDetails.setForgetPwdAttempt(bvUserProfile.getMbbForgetPwAttempt());
        customerDetails.setPublicStatus(bvUserProfile.getMbbPublicStatus());

        return customerDetails;
    }

    private List<String> getMBBPayeeListAcceptedProducts(MBBPayeeList mbbPayeeList) {
        List<String> acceptedProducts = new ArrayList<>();
        for(MBBPayeeProductList mbbPayeeProductList : mbbPayeeList.getMbbPayeeProductListsList()) {
            String acceptedProduct = new StringBuilder(mbbPayeeProductList.getAccountType())
                .append("-")
                .append((mbbPayeeProductList.getMbbPayeeProductListId().getProductCode()))
                .toString();
            acceptedProducts.add(acceptedProduct);
        }

        return acceptedProducts;
    }

    private PayeeDetails updatePayeeDetailsWithMBBPayeeList(PayeeDetails payeeDetails, MBBPayeeList mbbPayeeList) {
        payeeDetails.setFullName(mbbPayeeList.getFullName());
        payeeDetails.setOnlinePayment(DCCConstant.DCC_TRUE.equals(mbbPayeeList.getOnlinePayment()));
        payeeDetails.setTACRequired(DCCConstant.DCC_TRUE.equals(mbbPayeeList.getTacRequired()));
        payeeDetails.setPnPayeeEmail1(mbbPayeeList.getPnPayeeEmail1());
        payeeDetails.setPnPayeeEmail2(mbbPayeeList.getPnPayeeEmail2());
        payeeDetails.setPnPayeeIp(mbbPayeeList.getPnPayeeIp());
        payeeDetails.setPnPriority(mbbPayeeList.getPnPriority());
        if(DCCConstant.DCC_TRUE.equals(mbbPayeeList.getBillAcctRequired())) {
            payeeDetails.setBillAcctDisplayName(mbbPayeeList.getBillAcctDispName());
        }
        if(DCCConstant.DCC_TRUE.equals(mbbPayeeList.getBillRefRequired())) {
            payeeDetails.setBillRefDisplayName(mbbPayeeList.getBillRefDispName());
        }

        return payeeDetails;
    }

    private UserLoginDetails getUserLoginDetails(MBBAdapt mbbAdapt, int timeForTheme) {
        UserLoginDetails userLoginDetails = new UserLoginDetails();

        if(null == mbbAdapt || null == mbbAdapt.getMbbAdaptImageUrl()) {
            String themeName = getThemeName(timeForTheme, true);
            BVMSGScript bvMSGScript = bvMSGScriptRepository.findTopByScriptName(themeName);
            String[] imagePaths = bvMSGScript.getScriptTxt().split("\\|");
            userLoginDetails.setBackdropPath(imagePaths[0].substring(imagePaths[0].indexOf("#") + 1));
            
            return userLoginDetails;
        }
        
        String mbbAdaptImageUrl = mbbAdapt.getMbbAdaptImageUrl();
        userLoginDetails.setImageCaption(mbbAdapt.getMbbAdaptImageCaption());
        String theme = mbbAdapt.getMbbTheme();

        if(mbbAdaptImageUrl.endsWith(".bin")) {
            try {
                Path path = Paths.get(mbbAdaptImageUrl);
                // TODO: Checked with @HuiLee, .bin file content is just in 1 line, getting from 1st line is fine is this case
                userLoginDetails.setImageName(Files.readAllLines(path).get(0));
            } catch (IOException e) {
                log.error("Unable to read file from [{}]", mbbAdaptImageUrl, e);
            }
        } else {
            userLoginDetails.setImageName(PassItOnConfiguration.getProperty("profilePicStaticPath").concat(mbbAdaptImageUrl));
        }

        if(StringUtils.isEmptyString(theme)) {
            String themeName = getThemeName(timeForTheme, true);
            BVMSGScript bvMSGScript = bvMSGScriptRepository.findTopByScriptName(themeName);
            String[] imagePaths = bvMSGScript.getScriptTxt().split("\\|");
            userLoginDetails.setBackdropPath(imagePaths[0].substring(imagePaths[0].indexOf("#") + 1));
        } else {
            if(theme.startsWith("/")) {
                userLoginDetails.setBackdropPath(theme);
            } else {
                String themeName = getThemeName(timeForTheme, false);
                BVMSGScript bvMSGScript = bvMSGScriptRepository.findTopByScriptName(themeName);
                userLoginDetails.setBackdropPath(bvMSGScript.getScriptTxt());
            }
        }

        return userLoginDetails;
    }

    private void verifyCustomerMiscInfo(CustomerDetails customerDetails) throws PaymentException {
        // TODO: Reference M2UMerchantLoginServices.verifyUserLogin()
        String customerType = customerDetails.getCustomerType();
        Long forgetPwdAttempt = customerDetails.getForgetPwdAttempt();
        String publicStatus = customerDetails.getPublicStatus();

        MBBSystemParameters mbbSystemParameters = mbbSystemParametersRepository.findByMbbParameterIgnoreCaseAndStatus("FORGET_PASSWORD_ATTEMPTS", 1L);

        // TODO: Reference M2UGenericLoginServices.verifyCustomerMiscInfo()
        if ((!StringUtils.isEmptyString(publicStatus) && !"1".equals(publicStatus))
                || "12".equals(customerType)
                || forgetPwdAttempt >= Long.valueOf(mbbSystemParameters.getMbbParameterValue())) {

            MBBPublicUserStatus mbbPublicUserStatus = mbbPublicUserStatusRepository.findTopByMbbPublicUserStatusIdUserIdOrderByActionDateDesc(customerDetails.getUserId());

            int userActivity = 0;
            if(null != mbbPublicUserStatus) {
                userActivity = Integer.valueOf(mbbPublicUserStatus.getActivity());
            }
            if("12".equals(customerType)) {
                userActivity = 2;
            }
            if(5 == userActivity || forgetPwdAttempt >= Long.valueOf(mbbSystemParameters.getMbbParameterValue())) {
                String errorDetails = String.format("Failed to verify customer [%s] miscellaneous info. Current forgetPwdAttempt [%d] >= system forgetPwdAttempt [%s]",
                    customerDetails.getUserAlias(), forgetPwdAttempt, mbbSystemParameters.getMbbParameterValue());
                log.error(errorDetails);
                throw new PaymentException(PaymentServiceStatus.EXCEEDED_MAX_FORGET_PASSWORD_ATTEMPT, errorDetails);
            }
        }
    }

    private BVUser getBVUserByUserAlias(String userAlias) throws PaymentException {
        BVUser bvUser = bvUserRepository.findByUserAlias(userAlias);
        if(null == bvUser) {
            // TODO: Checked with @HuiLee, if user not exists stop the transaction here
            String errorDetails = String.format("No record found with username [%s]", userAlias);
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.DATA_NOT_FOUND, errorDetails);
        }
        return bvUser;
    }

    private MBBPayeeList getMBBPayeeList(String payeeCode) throws PaymentException {
        MBBPayeeList mbbPayeeList = mbbPayeeListRepository.findByPayeeCodeAndDeletedAndStatusAndDebitEngineAllowed(
            payeeCode, DCCConstant.DCC_NOT_DELETED, DCCConstant.DCC_ACTIVE, DCCConstant.DCC_TRUE);

        if (null == mbbPayeeList) {
            String errorDetails = String.format("No MBBPayeeList record found with payeeCode [%s] deleted [%d] status [%d] debitEngineAllowed [%d]",
                payeeCode, DCCConstant.DCC_NOT_DELETED, DCCConstant.DCC_ACTIVE, DCCConstant.DCC_TRUE);
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        return mbbPayeeList;
    }

    private BVUser updateBVUserMBBSecurity(AbstractDPERequestDTO req, BVUser bvUser) {
        // TODO: Checked with @HuiLee, we only update last login details to BV_USER_PROFILE and MBB_SECURITY after successful Clarity logon
        LocalDateTime now = LocalDateTime.now();
        String ipAddress = String.format("%s(%s)", req.getRemoteAddress(), req.getServerName());

        // TODO: Insert/Update of MBB_SECURITY
        if(!bvUser.getMbbSecurityList().isEmpty()) {
            // TODO: Checked with @HuiLee, supposely only 1 record in MBB_SECURITY for each user, however the table has ENGINE_ID column which could cause more than 1 rec
            for(MBBSecurity mbbSecurity : bvUser.getMbbSecurityList()) {
                mbbSecurity.setSessionId(req.getSessionId());
                mbbSecurity.setLoginDatetime(now);
                mbbSecurity.setIpAddress(ipAddress);
                mbbSecurity.setLangChoice(req.getLanguage());
            }
        } else {
            // TODO: If no record create a new one
            MBBSecurityId pk = new MBBSecurityId();
            pk.setUserId(bvUser.getUserId());
            pk.setEngineId(req.getEngineId());

            MBBSecurity newRecord = new MBBSecurity();
            newRecord.setMbbSecurityId(pk);
            newRecord.setSessionId(req.getSessionId());
            newRecord.setLoginDatetime(now);
            newRecord.setIpAddress(ipAddress);
            newRecord.setLangChoice(req.getLanguage());
            bvUser.getMbbSecurityList().add(newRecord);
        }

        return bvUserRepository.save(bvUser);
    }

    private INETTransactionLog createINETTransactionLogRec(AbstractDPERequestDTO req, long userId,
        String txnId, String txnType, double txnAmt, String fromAcctId, String toAcctId, String details, String txnDetails,
            String billAcctId, String billRefId, String approvalCode, String effectiveDate, String status) {

        INETTransactionLogId inetTransactionLogId = new INETTransactionLogId();
        inetTransactionLogId.setUserId(userId);
        inetTransactionLogId.setBvSessionId(req.getSessionId());
        inetTransactionLogId.setCreateTime(LocalDateTime.now());
        // TODO: We dont have BV support anymore, so leave this field to NA value
        inetTransactionLogId.setBvTransactionId(DASH_VALUE);
        inetTransactionLogId.setTransactionRefId(txnId);
        inetTransactionLogId.setTransactionType(txnType);

        INETTransactionLog inetTransactionLog = new INETTransactionLog();
        inetTransactionLog.setInetTransactionLogId(inetTransactionLogId);
        inetTransactionLog.setTransactionAmt(txnAmt);
        inetTransactionLog.setFromacctAcctid(fromAcctId);
        inetTransactionLog.setToacctAcctid(toAcctId);
        inetTransactionLog.setDetails(details);
        inetTransactionLog.setTransactionDetails(txnDetails);
        inetTransactionLog.setBillAcctid(billAcctId);
        inetTransactionLog.setBillRefId(billRefId);
        inetTransactionLog.setApprovalCode(approvalCode);
        inetTransactionLog.setEffectiveDate(effectiveDate);
        inetTransactionLog.setStatus(status);

        String ipAddress = String.format("%s(%s)", req.getRemoteAddress(), req.getServerName());
        inetTransactionLog.setIpAddress(ipAddress);

        return inetTransactionLogRepository.save(inetTransactionLog);
    }

    private SMSTable createSMSTableRec(String txnId, String customerNo, String customerName, String smsHpNo, String smsMessage, String smsService, String smsStatus) {
        // TODO: Reference BVUtils.logSms()
        SMSTableId smsTableId = new SMSTableId();
        smsTableId.setSmsCreatestamp(LocalDateTime.now());
        smsTableId.setSmsIbrefNo(txnId);

        SMSTable smsTable = new SMSTable();
        smsTable.setSmsTableId(smsTableId);
        smsTable.setSmsIcNo(customerNo);
        smsTable.setSmsCustName(customerName);
        smsTable.setSmsHpNo(smsHpNo);
        smsTable.setSmsMessage(smsMessage);
        smsTable.setSmsService(smsService);
        smsTable.setSmsStatus(smsStatus);

        return smsTableRepository.save(smsTable);
    }

    private INETPaymentControlDetails createINETPaymentControlDetailsRec(double txnAmt, String userAlias, String payeeCode, String cardNo) {
        INETPaymentControlDetailsId inetPaymentControlDetailsId = new INETPaymentControlDetailsId();
        inetPaymentControlDetailsId.setUserAlias(userAlias);
        inetPaymentControlDetailsId.setCreditCardNum(cardNo);
        inetPaymentControlDetailsId.setPayeeCode(payeeCode);
        inetPaymentControlDetailsId.setTransactionDate(LocalDateTime.now());

        INETPaymentControlDetails inetPaymentControlDetails = new INETPaymentControlDetails();
        inetPaymentControlDetails.setInetPaymentControlDetailsId(inetPaymentControlDetailsId);
        inetPaymentControlDetails.setTransactionAmount(txnAmt);

        // TODO: Existing M2U doesnt update this column, check with @HuiLee
        inetPaymentControlDetails.setChannelId("M2U");

        return inetPaymentControlDetailsRepository.save(inetPaymentControlDetails);
    }

    private INETDebitControlDetails createINETDebitControlDetailsRec(double txnAmt, long userId, String payeeCode, String txnType) {
        INETDebitControlDetailsId inetDebitControlDetailsId = new INETDebitControlDetailsId();
        inetDebitControlDetailsId.setUserId(userId);
        inetDebitControlDetailsId.setTransactionType(txnType);
        inetDebitControlDetailsId.setPayeeCode(payeeCode);
        inetDebitControlDetailsId.setTransactionDate(LocalDateTime.now());

        INETDebitControlDetails inetDebitControlDetails = new INETDebitControlDetails();
        inetDebitControlDetails.setInetDebitControlDetailsId(inetDebitControlDetailsId);
        inetDebitControlDetails.setTransactionAmount(txnAmt);

        // TODO: Existing M2U doesnt update this column, check with @HuiLee
        inetDebitControlDetails.setChannelId("M2U");

        return inetDebitControlDetailsRepository.save(inetDebitControlDetails);
    }

    private INETReceiptDetails createINETReceiptDetailsRec (String txnId, String receiptDetails) {
        INETReceiptDetailsId inetReceiptDetailsId = new INETReceiptDetailsId();
        inetReceiptDetailsId.setCreateTime(LocalDateTime.now());
        inetReceiptDetailsId.setTransactionRefId(txnId);

        INETReceiptDetails inetReceiptDetails = new INETReceiptDetails();
        inetReceiptDetails.setInetTransactionLogId(inetReceiptDetailsId);
        inetReceiptDetails.setDetails(receiptDetails);

        return inetReceiptDetailsRepository.save(inetReceiptDetails);
    }

    private MBBRelay createMBBRelayRec(long userId, String s2uToken, String txnId, String status) {
        MBBRelayId mbbRelayId = new MBBRelayId();
        mbbRelayId.setCreateTimestamp(LocalDateTime.now());
        mbbRelayId.setTokenId(s2uToken);
        mbbRelayId.setTransactionRefId(txnId);
        mbbRelayId.setUserId(userId);

        MBBRelay mbbRelay = new MBBRelay();
        mbbRelay.setMbbRelayId(mbbRelayId);
        mbbRelay.setStatus(status);

        return mbbRelayRepository.save(mbbRelay);
    }

    private PNTable2 createPNTable2Rec(DPECache cache, String key, String dbcr, String sendTime, String statusCode, String txnId) {

        PayeeDetails payeeDetails = cache.getPayeeDetails();
        String billAcctNo = cache.getBillAcctNo();
        String billRefNo = cache.getBillRefNo();
        double txnAmt = cache.getDoubleTxnAmt();

        PNTable2 pnTable2 = new PNTable2();
        pnTable2.setPnMaybankRefno(txnId);

        LocalDateTime now = LocalDateTime.now();

        int priority = (null == payeeDetails.getPnPriority()) ? 0 : Integer.valueOf(payeeDetails.getPnPriority());
        pnTable2.setPnPriority(priority);

        pnTable2.setPnPayeeIp(payeeDetails.getPnPayeeIp());
        pnTable2.setPnPayeeCode(payeeDetails.getPayeeCode());
        pnTable2.setPnKey(key);

        String pnBillAcctNo = (null == billAcctNo) ? "                              " : billAcctNo;
        pnTable2.setPnBillAcNo(pnBillAcctNo);

        String pnBillRefNo = (null == billRefNo) ? "                              " : billRefNo;
        pnTable2.setPnBillRefNo(pnBillRefNo);

        pnTable2.setPnTrnDate(DateTimeUtils.formatLocalDateTime(now, "yyyyMMdd"));
        pnTable2.setPnTrnTime(DateTimeUtils.formatLocalDateTime(now, "HHmmss"));

        long amount = (long)(txnAmt * 100);
        String transAmount = org.apache.commons.lang3.StringUtils.leftPad(String.valueOf(amount), 9, " ");
        pnTable2.setPnAmount(transAmount);

        // TODO: For success txn, we set 00 and if failed txn we set it with 01 as per previous logic
        pnTable2.setPnStatus(statusCode);

        // TODO: For Ticketing Payment, this is empty string, however for Debit Payment, it might not, please take note
        // TODO: Insert empty string to DB column, will make the column as NULL, check with @HuiLee/DBA
        pnTable2.setPnDbcr(dbcr);

        String email1 = (null == payeeDetails.getPnPayeeEmail1()) ? " " : payeeDetails.getPnPayeeEmail1();
        pnTable2.setPnEmail1(email1);

        String email2 = (null == payeeDetails.getPnPayeeEmail2()) ? " " : payeeDetails.getPnPayeeEmail2();
        pnTable2.setPnEmail2(email2);

        pnTable2.setPnSendtime(sendTime);

        return pnTable2Repository.save(pnTable2);
    }

    private void createINETControlDetailsRec(CustomerDetails customerDetails, PayeeDetails payeeDetails,
         PaymentValidationResult paymentValidationResult, double txnAmt, String txnType) throws PaymentException {

        Account fromAcct = customerDetails.getFromAccount();

        switch(fromAcct.getType()) {
            case PaymentServiceConstant.CREDIT_CARD:
            case PaymentServiceConstant.PREPAID_CCARD:
            case PaymentServiceConstant.CHARGE_CARD:
                // TODO: Any value that is NULL or non "0" will proceed here
                if((null == paymentValidationResult.getMaxAmount() || 0 != paymentValidationResult.getMaxAmount())
                    && (null == paymentValidationResult.getMaxTxn() || 0 != paymentValidationResult.getMaxTxn())) {

                    String cardNo = org.apache.commons.lang3.StringUtils.rightPad(fromAcct.getAccountNo().trim(), 19, "0");
                    String encryptedCardNo = SecurityUtils.encryptCardNo(cardNo);
                    createINETPaymentControlDetailsRec(txnAmt, customerDetails.getUserAlias(), payeeDetails.getPayeeCode(), encryptedCardNo);
                }
                break;
            default:
                // TODO: Any value that is NULL or non "0" will proceed here
                if(null == paymentValidationResult.getMaxLimit() || 0 != paymentValidationResult.getMaxLimit()) {
                    createINETDebitControlDetailsRec(txnAmt, customerDetails.getUserId(), payeeDetails.getPayeeCode(), txnType);
                }
        }
    }

    private String getTACIdByPaymentType(PaymentType paymentType) {
        // TODO: We should dynamic handling Ticketing Payment (TAC160001) and Debit Payment (TAC700001) later

        String tacId = null;
        if (PaymentType.DEBIT.equals(paymentType)) {
            tacId = "TAC700001";
        } else if (PaymentType.TICKETING.equals(paymentType)) {
            tacId = "TAC160001";
        }
        return tacId;
    }

    private void logTransactionDetails(AbstractDPERequestDTO req, DPECache cache, PaymentValidationResult paymentValidationResult,
        String s2uType, TransactionStatus txnStatus, String txnId) throws PaymentException {

        CustomerDetails customerDetails = cache.getCustomerDetails();
        PayeeDetails payeeDetails = cache.getPayeeDetails();

        // TODO: We dont cater ASNB stuff in DPE, so skip the logic
        StringBuilder txnType = (payeeDetails.isOnlinePayment()) ? new StringBuilder("OnlinePayment") : new StringBuilder("BillPayment");

        if("004".equals(s2uType)) {
            txnType.append(" (Secure Verification)");
        } else if("005".equals(s2uType)) {
            txnType.append(" (Secure TAC)");
        }
        String txnTypeStr = txnType.toString();

        // TODO: Reference Logger.logTransactionDetails()
        double txnAmt = cache.getDoubleTxnAmt();
        Account fromAcct = customerDetails.getFromAccount();
        String toAcctId = DASH_VALUE;
        String details = payeeDetails.getFullName();
        String txnDetails = String.format("Pay from <b> %s %s</b><br>PAY to %s<br> %s",
            fromAcct.getName(), fromAcct.getDisplayNo(), payeeDetails.getFullName(), DateTimeUtils.formatLocalDateTime(LocalDateTime.now(), "dd MMM yyyy"));
        String billAcctId = cache.getBillAcctNo();
        String billRefId = cache.getBillRefNo();
        String approvalCode = DASH_VALUE;
        String effectiveDate = "00000000";

        createINETTransactionLogRec(req, cache.getCustomerDetails().getUserId(), txnId, txnTypeStr, txnAmt,
            fromAcct.getAccountNo(), toAcctId, details, txnDetails, billAcctId, billRefId, approvalCode, effectiveDate, txnStatus.getDesc());

        // TODO: This part is more for the SMS TAC/ S2U TAC which immediately we can know the result
        // TODO: For S2U Verification we will insert it under another logic, since the status is still EXPIRED
        if(TransactionStatus.SUCCESSFUL.equals(txnStatus)) {
            createINETControlDetailsRec(customerDetails, payeeDetails, paymentValidationResult, cache.getDoubleTxnAmt(), txnTypeStr);
        }

        // TODO: DPE doesn't involve SMS Alerts, skip the logic

        // TODO: Reference M2UGenericBillPaymentServices.setReceiptPrintingValue()

        // TODO: Make this as a separate method to handle receipt stuff
//        String receiptTitle = M2UApplicationResources.getValue("m1200.paymenttype.billpayment", req.getLocale());
//        String receiptNote = M2UApplicationResources.getValue("receipt.note", req.getLocale());
        // TODO: Since DPE handle Today effective date, the "printReceipt" flag must be true

        // TODO: Anything related to M2UBIZMAKERCUSTOMERTYPE/M2UBIZCHECKERCUSTOMERTYPE shall be skip for now

        // TODO: Is it necessary to use LinkedHashMap? Is it because of the sequence ordering? Check further when free
        Map<String, String> receiptMap = ReceiptUtils.getReceiptMap(payeeDetails, cache.getBillAcctNo(), cache.getBillRefNo(), req.getLocale());

        // TODO: Skip non DPE related thing like isRegisteredPayment/isPrepaidPayment, approvalCodeToDisplay, reloadDetailsToDisplay, EPF Payment, Pay Loan & HP

        // TODO: DPE skip isEPFPayment/isRegisteredPayment logic

        // TODO: Skip ASNB logic

        String receiptTxnType = null;
        if(payeeDetails.isOnlinePayment()) {
            receiptTxnType = M2UApplicationResources.getValue("receipt.transaction.bill.payment.online.open", req.getLocale());
            // TODO: ASNB nothing to do with DPE, skip it
        } else {
            // TODO: DPE dont related to isPrepaidPayment, skip the logic
            receiptTxnType = M2UApplicationResources.getValue("receipt.transaction.bill.payment.open", req.getLocale());
        }
        receiptMap.put("TransactionType", receiptTxnType);

        // TODO: Reference Logger.logTransactionReceiptDetails()
        String receiptParamString = ReceiptUtils.getReceiptParamsString(receiptMap, "|");
        // TODO: Is the locale and language has same value all the time? if yes maybe we should remove language field from request
        String receiptDetails = receiptParamString.concat("|lg|").concat(req.getLanguage());

        createINETReceiptDetailsRec(txnId, receiptDetails);

        // TODO: "noOfRecs" not set in bean far for DPE, plus we assumed DPE to handle 1 receipt only, so skip related logic
    }

    private void createCache(DPECache cache) throws PaymentException {
        try {
            String json = PaymentServiceUtils.convertObjectToJSON(cache);
            String cacheStr = String.format(PaymentServiceConstant.PAYMENT_CACHE_TEMPLATE, cache.getSessionId(), json);
            CacheUtils.createCache(cacheStr);
        } catch (CacheException e) {
            String errorDetails = String.format("Failed to cache [%s] to cache map [%s]", cache, PaymentServiceConstant.PAYMENT_MAP_NAME);
            log.error(errorDetails, e);
            throw new PaymentException(PaymentServiceStatus.DATA_CACHING_FAILED, errorDetails, e);
        }
    }

    private DPECache getCache(String sessionId) throws PaymentException {
        try {
            String json = CacheUtils.getCache(PaymentServiceConstant.PAYMENT_MAP_NAME, sessionId);
            if(null != json) {
                return PaymentServiceUtils.convertJSONToObject(DPECache.class, json);
            } else {
                String errorDetails = String.format("Failed to get cache from cache map [%s] using key [%s]", PaymentServiceConstant.PAYMENT_MAP_NAME, sessionId);
                log.error(errorDetails);
                throw new PaymentException(PaymentServiceStatus.INVALID_REQUEST_DATA, errorDetails);
            }
        } catch (CacheException e) {
            String errorDetails = String.format("Failed to get cache from cache map [%s] using key [%s]", PaymentServiceConstant.PAYMENT_MAP_NAME, sessionId);
            log.error(errorDetails, e);
            throw new PaymentException(PaymentServiceStatus.DATA_CACHING_FAILED, errorDetails, e);
        }
    }

    private void updateCache(DPECache cache) throws PaymentException {
        try {
            String json = PaymentServiceUtils.convertObjectToJSON(cache);
            String cacheStr = String.format(PaymentServiceConstant.PAYMENT_CACHE_TEMPLATE, cache.getSessionId(), json);
            CacheUtils.updateCache(cacheStr);
        } catch (PaymentException e) {
            throw e;
        } catch (CacheException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.DATA_CACHING_FAILED, e.getMessage(), e);
        }
    }

    private int getLDAPErrorCode(String errorMessage)
    {
        String pattern="-?\\d+";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(errorMessage);
        if (m.find()) {
            return Integer.valueOf(m.group(0));
        }
        return -1;
    }
}