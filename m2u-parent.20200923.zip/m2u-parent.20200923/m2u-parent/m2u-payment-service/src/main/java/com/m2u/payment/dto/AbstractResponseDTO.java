package com.m2u.payment.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Map;

@Data
public abstract class AbstractResponseDTO {

    protected String sessionId;
    protected String token;
    protected String engineId;
    protected String statusCode;
    protected String statusMessage;
    protected Map<String, String> error;
    protected LocalDateTime currentDate;

    private String deviceTokenCookie;
    private String deviceTokenFSO;

    public AbstractResponseDTO() {}

    public AbstractResponseDTO(String sessionId, String token, String engineId) {
        this.sessionId = sessionId;
        this.token = token;
        this.engineId = engineId;
    }

    public AbstractResponseDTO(String sessionId, String token, String engineId, String statusCode, String statusMessage) {
        this.sessionId = sessionId;
        this.token = token;
        this.engineId = engineId;
        this.statusCode = statusCode;
        this.statusMessage = statusMessage;
    }
}
