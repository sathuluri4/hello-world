package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBPublicUserStatus;
import com.m2u.payment.entity.MBBPublicUserStatusId;
import org.springframework.data.repository.CrudRepository;

public interface MBBPublicUserStatusRepository extends CrudRepository<MBBPublicUserStatus, MBBPublicUserStatusId> {

    MBBPublicUserStatus findTopByMbbPublicUserStatusIdUserIdOrderByActionDateDesc(Long userId);
}
