package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBRelay;
import com.m2u.payment.entity.MBBRelayId;
import org.springframework.data.repository.CrudRepository;

public interface MBBRelayRepository extends CrudRepository<MBBRelay, MBBRelayId> {

    MBBRelay findByMbbRelayIdTransactionRefIdAndMbbRelayIdTokenId(String transactionRefId, String tokenId);
}
