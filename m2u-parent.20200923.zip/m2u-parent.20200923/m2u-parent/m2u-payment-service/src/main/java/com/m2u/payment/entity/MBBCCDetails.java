package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_CC_DETAILS")
@Entity
public class MBBCCDetails implements Serializable {

    @EmbeddedId
    private MBBCCDetailsId mbbccDetailsId;

    @Column(name = "CREDIT_CARD_BRAND")
    private String creditCardBrand;

    @Column(name = "CVV2_CVC2")
    private String cvv2CVC2;

    @Column(name = "EXPIRY_MONTH")
    private String expiryMonth;

    @Column(name = "EXPIRY_YEAR")
    private String expiryYear;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "LOG_DATE")
    private String logDate;

    @Column(name = "CARD_STATUS")
    private String cardStatus;

    @Column(name = "BANK_CODE")
    private String bankCode;

    @Column(name = "MEMBER_SINCE")
    private String memberSince;

    @Column(name = "POSTCODE")
    private String postCode;

    @ManyToOne
    @MapsId("userId")
    @JoinColumn(name="USER_ID")
    private BVUser bvUser;
}
