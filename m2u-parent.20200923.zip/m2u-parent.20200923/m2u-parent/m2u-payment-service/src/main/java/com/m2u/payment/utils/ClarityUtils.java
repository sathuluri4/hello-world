package com.m2u.payment.utils;

import com.m2u.clarity.messaging.dto.*;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.service.AccountDetailsMessagingService;
import com.m2u.clarity.messaging.service.LogonMessagingService;
import com.m2u.clarity.messaging.service.PaymentMessagingService;
import com.m2u.clarity.messaging.service.TACMessagingService;
import com.m2u.common.constants.DCCConstant;
import com.m2u.common.utils.DateTimeUtils;
import com.m2u.common.utils.StringUtils;
import com.m2u.payment.constants.PaymentServiceConstant;
import com.m2u.payment.dto.AbstractDPERequestDTO;
import com.m2u.payment.entity.MBBProductInfo;
import com.m2u.payment.entity.MBBProductList;
import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import com.m2u.payment.model.*;
import com.m2u.payment.repository.MBBProductListRepository;
import com.m2u.payment.resources.M2UApplicationResources;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Component
public class ClarityUtils {

    private static final String TODAY_EFFECTIVE_DATE = "00000000";

    private static MBBProductListRepository mbbProductListRepository;
    private static LogonMessagingService logonMessagingService;
    private static AccountDetailsMessagingService accountDetailsMessagingService;
    private static TACMessagingService tacMessagingService;
    private static PaymentMessagingService paymentMessagingService;

    private ClarityUtils() {}

    @Autowired
    public synchronized void setMBBProductListRepository(MBBProductListRepository mbbProductListRepo) {
        mbbProductListRepository = mbbProductListRepo;
    }

    @Autowired
    private synchronized void setLogonMessagingService(LogonMessagingService logonMessagingServc) {
        logonMessagingService = logonMessagingServc;
    }

    @Autowired
    private synchronized void setAccountDetailsMessagingService(AccountDetailsMessagingService accountDetailsMessagingServc){
        accountDetailsMessagingService = accountDetailsMessagingServc;
    }

    @Autowired
    private synchronized void setTACMessagingService(TACMessagingService tacMessagingServc){
        tacMessagingService = tacMessagingServc;
    }

    @Autowired
    private synchronized void setPaymentMessagingService(PaymentMessagingService paymentMessagingServc){
        paymentMessagingService = paymentMessagingServc;
    }

    public static GetLogonResponseDTO getLogon(AbstractDPERequestDTO req, CustomerDetails customerDetails) throws PaymentException {
        GetLogonRequestDTO getLogonReq = null;
        GetLogonResponseDTO getLogonResp = null;
        try {
            getLogonReq = new GetLogonRequestDTO();
            getLogonReq = updateClarityCommonData(req, getLogonReq, customerDetails.getPan());
            getLogonReq.setSubServiceId("03");
            log.debug("CLARITY GetLogon REQ [{}]", getLogonReq);
            getLogonResp = logonMessagingService.getLogon(getLogonReq);
            log.debug("CLARITY GetLogon RESP [{}]", getLogonResp);
        } catch (ClarityMessagingException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, e.getMessage(), e);
        }

        if(!"0000".equals(getLogonResp.getResponseCode())) {
            String errorDetails = String.format("Failed to get logon info from Clarity with GetLogonRequestDTO [%s]. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                    getLogonReq, getLogonResp.getTxnRefId(), getLogonResp.getResponseCode(), getLogonResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
        }

        return getLogonResp;
    }

    public static GetAccountDetailsResponseDTO getAccountDetails(AbstractDPERequestDTO req, CustomerDetails customerDetails) throws PaymentException {
        GetAccountDetailsRequestDTO getAccountDetailsReq = null;
        GetAccountDetailsResponseDTO getAccountDetailsResp = null;
        try {
            Account fromAcct = customerDetails.getFromAccount();
            getAccountDetailsReq = new GetAccountDetailsRequestDTO();
            getAccountDetailsReq = updateClarityCommonData(req, getAccountDetailsReq, customerDetails.getPan());
            // TODO: Most value below is hardcoded in M2U by default
            getAccountDetailsReq.setSubServiceCode("01");
            getAccountDetailsReq.setAccountType(fromAcct.getType());
            getAccountDetailsReq.setAccountNo(fromAcct.getAccountNo());
            getAccountDetailsReq.setFdCertificateNo("00000000000000");
            // TODO: Not sure shall we hardcode or use the Clarity version of account currency code
//            getAccountDetailsReq.setCurrencyCode(CurrencyCode.MYR.name());
            getAccountDetailsReq.setCurrencyCode(fromAcct.getCurrencyCode());
            getAccountDetailsReq.setCreditCardType("00");

            // TODO: Reference M2UGenericCustomerInitServices.initNonIbccPublicCustomerInfo()
            // TODO: Reference BVUtils.getCustomerInfoFromFN()
            log.debug("CLARITY GetAccountDetails REQ [{}]", getAccountDetailsReq);
            getAccountDetailsResp = accountDetailsMessagingService.getAccountDetails(getAccountDetailsReq);
            log.debug("CLARITY GetAccountDetails RESP [{}]", getAccountDetailsResp);
        } catch (ClarityMessagingException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, e.getMessage(), e);
        }

        if(!"0000".equals(getAccountDetailsResp.getResponseCode())) {
            String errorDetails = String.format("Failed to get account details from Clarity with GetAccountDetailsRequestDTO [%s]. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                getAccountDetailsReq, getAccountDetailsResp.getTxnRefId(), getAccountDetailsResp.getResponseCode(), getAccountDetailsResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
        }

        return getAccountDetailsResp;
    }

    public static CreateTACResponseDTO createTAC(AbstractDPERequestDTO req, CustomerDetails customerDetails,
                                                 String serviceName, String serviceMessage, String serviceCode, String tacInfo1, String tacInfo2) throws PaymentException {
        CreateTACRequestDTO createTACReq = null;
        CreateTACResponseDTO createTACResp = null;
        try {
            createTACReq = new CreateTACRequestDTO();
            createTACReq = updateClarityCommonData(req, createTACReq, customerDetails.getPan());
            // TODO: 000 (no action) or 001 (force expired), M2U used 001
            createTACReq.setServiceRestrictCode("001");
            createTACReq.setServiceName(serviceName);
            createTACReq.setServiceMessage(serviceMessage);
            createTACReq.setTacServiceCode(serviceCode);
            createTACReq.setTacInfo1(tacInfo1);
            createTACReq.setTacInfo2(tacInfo2);

            log.debug("CLARITY CreateTAC REQ [{}]", createTACReq);
            createTACResp = tacMessagingService.createTAC(createTACReq);
            log.debug("CLARITY CreateTAC RESP [{}]", createTACResp);
        } catch (ClarityMessagingException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, e.getMessage(), e);
        }

        if(!"0000".equals(createTACResp.getResponseCode())) {
            String errorDetails = String.format("Failed to request TAC from Clarity with CreateTACRequestDTO [%s]. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                    createTACReq, createTACResp.getTxnRefId(), createTACResp.getResponseCode(), createTACResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
        }

        return createTACResp;
    }

    public static CreateOnlinePaymentResponseDTO createOnlinePayment(AbstractDPERequestDTO req, CustomerDetails customerDetails, PayeeDetails payeeDetails,
                                                                     String txnAmt, String s2uType, String tacValue, String billAcctNo) throws PaymentException {

        CreateOnlinePaymentRequestDTO createOnlinePaymentReq = null;
        CreateOnlinePaymentResponseDTO createOnlinePaymentResp = null;
        String serviceCode = null;

        try {
            if("700".equals(payeeDetails.getPayeeCode())) {
                serviceCode = "11";
            } else {
                serviceCode = "12";
            }

            Account fromAcct = customerDetails.getFromAccount();
            createOnlinePaymentReq = new CreateOnlinePaymentRequestDTO();
            createOnlinePaymentReq = updateClarityCommonData(req, createOnlinePaymentReq, customerDetails.getPan());
            createOnlinePaymentReq.setTxnAmount(txnAmt);
            createOnlinePaymentReq.setTxnCurrencyCode(fromAcct.getCurrencyCode());
            createOnlinePaymentReq.setServiceRestrictCode(s2uType);
            // TODO: Although for now it is always 6 digits, but we make it dynamic calculate the length
            createOnlinePaymentReq.setTacLength(tacValue.length());
            createOnlinePaymentReq.setTac(tacValue);
            createOnlinePaymentReq.setFromAcctNo(fromAcct.getAccountNo());
            createOnlinePaymentReq.setServiceCode(serviceCode);
            createOnlinePaymentReq.setFromAcctCode(fromAcct.getAccountCode());
            createOnlinePaymentReq.setToAcctCode("20");
            // TODO: Clarity required length 4 payee code, existing M2U just appened it with "1"
            createOnlinePaymentReq.setPayeeCode(payeeDetails.getPayeeCode().concat("1"));
            createOnlinePaymentReq.setBillAcctNo(billAcctNo);
            createOnlinePaymentReq.setSmsAlertBit("0");
            createOnlinePaymentReq.setEffectiveDate(TODAY_EFFECTIVE_DATE);

            log.debug("CLARITY CreateOnlinePayment REQ [{}]", createOnlinePaymentReq);
            createOnlinePaymentResp = paymentMessagingService.createOnlinePayment(createOnlinePaymentReq);
            log.debug("CLARITY CreateOnlinePayment RESP [{}]", createOnlinePaymentResp);
        } catch (ClarityMessagingException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, e.getMessage(), e);
        }

        if(!"0000".equals(createOnlinePaymentResp.getResponseCode())) {
            String errorDetails = String.format("Failed to create online payment to Clarity with CreateOnlinePaymentRequestDTO [%s]. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                createOnlinePaymentReq, createOnlinePaymentResp.getTxnRefId(), createOnlinePaymentResp.getResponseCode(), createOnlinePaymentResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
        }

        return createOnlinePaymentResp;
    }

    public static CreateBillPaymentResponseDTO createBillPayment(AbstractDPERequestDTO req, CustomerDetails customerDetails,
                                                                 String txnAmt, String s2uType, String tacValue, List<BillPayment> billPayments, boolean isZakatPayment) throws PaymentException {

        CreateBillPaymentRequestDTO createBillPaymentReq = null;
        CreateBillPaymentResponseDTO createBillPaymentResp = null;
        try {
            Account fromAcct = customerDetails.getFromAccount();
            createBillPaymentReq = new CreateBillPaymentRequestDTO();
            createBillPaymentReq = updateClarityCommonData(req, createBillPaymentReq, customerDetails.getPan());
            createBillPaymentReq.setTxnAmount(txnAmt);
            createBillPaymentReq.setTxnCurrencyCode(fromAcct.getCurrencyCode());
            createBillPaymentReq.setServiceRestrictCode(s2uType);
            // TODO: Although for now it is always 6 digits, but we make it dynamic calculate the length
            createBillPaymentReq.setTacLength(tacValue.length());
            createBillPaymentReq.setTac(tacValue);
            createBillPaymentReq.setFromAcctNo(fromAcct.getAccountNo());

            if(isZakatPayment) {
                createBillPaymentReq.setServiceCodeHead("180000");
            } else {
                createBillPaymentReq.setServiceCodeHead("030000");
            }

            List<CreateBillPaymentRequestDTO.BillPayment> reqBillPayments = new ArrayList<>(billPayments.size());
            for(BillPayment billPayment :  billPayments) {
                CreateBillPaymentRequestDTO.BillPayment reqBillPayment = new CreateBillPaymentRequestDTO.BillPayment();
                reqBillPayment.setServiceCode(billPayment.getServiceCode());
                reqBillPayment.setFromAcctCode(billPayment.getFromAcctCode());
                reqBillPayment.setToAcctCode(billPayment.getToAcctCode());
                // TODO: Clarity required length 4 payee code, existing M2U just appened it with "1"
                reqBillPayment.setPayeeCode(billPayment.getPayeeCode().concat("1"));
                reqBillPayment.setIndividualEffectPaymentDate(billPayment.getIndividualEffectPaymentDate());
                reqBillPayment.setCurrencyCode(billPayment.getCurrencyCode());
                reqBillPayment.setTxnAmount(billPayment.getTxnAmount());
                reqBillPayment.setBillAcctNo(billPayment.getBillAcctNo());
                reqBillPayment.setCustName(billPayment.getCustName());
                reqBillPayment.setIcNoBusRegNo(billPayment.getIcNoBusRegNo());
                reqBillPayment.setCNo(billPayment.getCNo());
                reqBillPayment.setExpiryDate(billPayment.getExpiryDate());
                reqBillPayment.setCvv(billPayment.getCvv());
                reqBillPayments.add(reqBillPayment);
            }
            createBillPaymentReq.setBillPayment(reqBillPayments);

            createBillPaymentReq.setSmsAlertBit("0");
            createBillPaymentReq.setEffectiveDate(TODAY_EFFECTIVE_DATE);

            log.debug("CLARITY CreateBillPayment REQ [{}]", createBillPaymentReq);
            createBillPaymentResp = paymentMessagingService.createBillPayment(createBillPaymentReq);
            log.debug("CLARITY CreateBillPayment RESP [{}]", createBillPaymentResp);
        } catch (ClarityMessagingException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.CLARITY_COMMUNICATION_FAILED, e.getMessage(), e);
        }

        if(!"0000".equals(createBillPaymentResp.getResponseCode())) {
            String errorDetails = String.format("Failed to create bill payment to Clarity with CreateBillPaymentResponseDTO [%s]. txnRefId [%s] responseCode [%s] responseDesc [%s] sessionId [%s] token [%s] engineId [%s]",
                createBillPaymentReq, createBillPaymentResp.getTxnRefId(), createBillPaymentResp.getResponseCode(), createBillPaymentResp.getResponseDesc(), req.getSessionId(), req.getToken(), req.getEngineId());
            log.error(errorDetails);
        }

        return createBillPaymentResp;
    }

    public static List<Account> filterClarityLogonAccounts(AbstractDPERequestDTO req, GetLogonResponseDTO getLogonResp, boolean isOnlinePayment, List<String> acceptedProducts) {
        List<Account> accounts = new ArrayList<>();
        int acctIdx = 0;

        for(Map.Entry<String, List<Map<String, String>>> accountGroup : getLogonResp.getAccountGroups().entrySet()) {
            // TODO: Here we filter out accounts which account type is 'PR' as per existing M2U logic
            if(!PaymentServiceConstant.PRODUCT_INDICATOR.equals(accountGroup.getKey())) {
                if(accountGroup.getValue().size() > 0) {
                    for(Map<String, String> account : accountGroup.getValue()) {
                        Account acct = new Account();
                        acct.setType(accountGroup.getKey());
                        acct.setAccountCode(account.get("acctCode"));
                        acct.setAccountNo(account.get("acctNo"));
                        acct.setCurrencyCode(account.get("currencyCode"));
                        acct.setCurrency(PaymentServiceUtils.getDisplayCurrency(account.get("currencyCode")));
                        acct.setDisplayNo(formatAccountNo(account.get("acctNo"), accountGroup.getKey(), req.getCountryCode()));

                        // TODO: Reference BVUtils.getAccountExtraInfo()
                        // TODO: Reference BVUtils.getProductContent()
                        // TODO: For each account, we trigger new DB query to get necessry info, is that a way to improve this? e.g. using IN condition?
                        // TODO: IMPORTANT!!! Think how to enhance this
                        acct = updateAccountExtraInfo(acct, accountGroup.getKey(), acct.getAccountCode(), acct.getAccountNo());

                        // TODO: Reference M2UMerchantMakePaymentServices.getAccountList() && M2UMerchantMakePaymentServices.getAccountListWithServiceName()
                        boolean validAcct = isAccountAccepted(isOnlinePayment, acct, acceptedProducts);
                        if(validAcct) {
                            acct.setIdx(acctIdx);
                            accounts.add(acct);
                            acctIdx++;
                        }
                    }
                }
            }
        }

        return accounts;
    }

    private static <T extends AbstractDPERequestDTO, U extends com.m2u.clarity.messaging.dto.AbstractRequestDTO> U updateClarityCommonData(T t, U u, String pan) {
        LocalDateTime now = LocalDateTime.now();
        String nowStr = DateTimeUtils.formatLocalDateTime(now, "yyyyMMddHHmmss");
        ZonedDateTime zdt = ZonedDateTime.of(now, ZoneId.systemDefault());
        String epochMillis = String.valueOf(zdt.toInstant().toEpochMilli());
        // TODO: Discussed with @HuiLee, we will use full 13 digits epoch millis + max 7 chars of the hostname, if it exceeded 7 chars we pick the 7 chars most right
        String serverName = null;
        int serverNameLength = t.getServerName().length();
        if(serverNameLength < 8) {
            serverName = t.getServerName();
        } else {
            serverName = t.getServerName().substring(serverNameLength-7, serverNameLength);
        }
        String txnRefId = String.format("%s%s", serverName, epochMillis);

        u.setUserId(pan);
        // TODO: Original LDAP pan contained extra postfix zeros, we need pick the first 16 digits only
        u.setPan(pan.substring(0, 16));
        u.setCreationDateTime(nowStr);
        u.setCountryCode(t.getCountryCode());
        u.setTxnRefId(txnRefId);

        return u;
    }

    private static String formatAccountNo(String acctNo, String acctType, String countryCode) {
        if ("MY".equals(countryCode)) {
            switch (acctType) {
                case PaymentServiceConstant.CREDIT_CARD:
                case PaymentServiceConstant.DEBIT_CARD:
                case PaymentServiceConstant.PREPAID_CCARD:
                case PaymentServiceConstant.CHARGE_CARD:
                    String cardNoPrefix = acctNo.substring(0, 5);
                    String[] cardPrefixes = M2UApplicationResources.getValue("card_prefix").split(",");
                    for (String cardPrefix : cardPrefixes) {
                        // TODO: Should we skip check the acctType since we are deal with pure card which shall only have card number
                        if (cardPrefix.equals(cardNoPrefix) || cardPrefix.equalsIgnoreCase(acctType)) {
                            return new StringBuilder(PaymentServiceConstant.CARD_DIGIT_FORMAT_15).append(acctNo.substring(11, 15)).toString();
                        }
                    }
                    return new StringBuilder(PaymentServiceConstant.CARD_DIGIT_FORMAT_16).append(acctNo.substring(12, 16)).toString();
                case PaymentServiceConstant.CURRENT_ACCOUNT:
                case PaymentServiceConstant.SAVING_ACCOUNT:
                case PaymentServiceConstant.LOAN:
                case PaymentServiceConstant.HIRE_PURCHASE:
                case PaymentServiceConstant.FIX_DEPOSIT:
                case PaymentServiceConstant.FOREIGN_CURRENCY_ACCOUNT:
                case PaymentServiceConstant.GOLD_SAVING_ACCOUNT:
                    return acctNo.substring(0, 12);
                case PaymentServiceConstant.PERSONAL_LOAN:
                    return acctNo.substring(0, 16);
            }
        } else if ("SG".equals(countryCode)) {
            switch (acctType) {
                case PaymentServiceConstant.CREDIT_CARD:
                    return acctNo.substring(0, 16);
                default:
                    return acctNo.substring(0, 8);
            }
        }
        // TODO: Fall back plan
        return acctNo;
    }

    private static <T extends AbstractAccount> T updateAccountExtraInfo(T acct, String acctType, String acctCode, String acctNo) {
        MBBProductList mbbProductList = null;
        Object[] obj = null;
        switch(acctType) {
            case PaymentServiceConstant.CREDIT_CARD:
            case PaymentServiceConstant.DEBIT_CARD:
            case PaymentServiceConstant.PREPAID_CCARD:
            case PaymentServiceConstant.CHARGE_CARD:
                String ccPrefix = acctNo.substring(0, 6);
                List<Object[]> objs = mbbProductListRepository.findByAccountTypeAndProductCodeAndDeletedAndStatusAndCcPrefix(acctType, acctCode, DCCConstant.DCC_NOT_DELETED, DCCConstant.DCC_ACTIVE, ccPrefix);
                if(objs.size() > 0) {
                    obj = objs.get(0);
                    mbbProductList = (MBBProductList) obj[0];
                }
                break;
            default:
                mbbProductList = mbbProductListRepository.findByAccountTypeAndProductCodeAndDeletedAndStatus(acctType, acctCode, DCCConstant.DCC_NOT_DELETED, DCCConstant.DCC_ACTIVE);
        }

        if(null != mbbProductList) {
            if(null != obj) {
                // TODO: Only applicable to CARD related account type
                MBBProductInfo mbbProductInfo = (MBBProductInfo) obj[1];
                acct.setName(mbbProductInfo.getCcDisplayName());
            } else {
                acct.setName(mbbProductList.getLName());
            }

            // TODO: Checked with @Kuhan, we don't need fetch account balance at this stage

            acct.setServiceName(mbbProductList.getSName());

            acct.setTransferFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getTrfFr()));
            acct.setTransferToAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getTrfTo()));
            acct.setThirdPartyTransferFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getTrf3rdFr()));
            acct.setThirdPartyTransferToAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getTrf3rdTo()));
            acct.setOnlinePaymentFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getOnpayFr()));
            acct.setNonOnlinePaymentFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getNonpayFr()));
            acct.setChequeServicesFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getChqFr()));
            acct.setElectronicShareApplicationToAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getEsaFr()));
            acct.setPolicyRenewalFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getPrnwFr()));
            acct.setRequestAcctStatementFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getReqAcStatFr()));
            acct.setFixDepositFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getFdtdFr()));
            acct.setFixDepositToAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getFdtdTo()));
            acct.setEremittanceFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getEremittanceFr()));
            acct.setEpfFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getEpfFr()));
            acct.setShareInvestmentCenterSMFAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getSicSmf()));
            acct.setFundAllocationFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getFundAllocationFr()));
            acct.setFixDepositUpliftmentToAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getFdUpliftmentTo()));
            acct.setAddressFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getAddressFr()));
            acct.setBillPaymentToAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getBillpymtTo()));
            acct.setMaxihomeRedrawToAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getMaxihomeRedrawTo()));
            acct.setPremierPAFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getPpaFr()));
            acct.setFpxFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getFpxFr()));
            acct.setJointAcctFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getJointFrom()));
            acct.setJompayFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getJpyFra()));
            acct.setPayFromAcct(DCCConstant.DCC_TRUE.equals(mbbProductList.getPayFra()));

            // TODO: Reference BVUtils.getProductContentFromChild()
            // TODO: Checked with @HuiLee we don't need to fetch data from child MBB_FORM_DETAILS for now
        } else {
            log.debug("No MBBProductList record found with accountType [{}] accountCode [{}] accountNum [{}] status [{}] ccPrefix [{}] deleted [{}] status [{}]",
                    acctType, acctCode, acctNo, DCCConstant.DCC_NOT_DELETED, DCCConstant.DCC_ACTIVE);
        }

        return acct;
    }

    private static boolean isAccountAccepted(boolean isOnlinePayment, Account acct, List<String> acceptedProducts) {
        boolean isPaymentSupported = true;
        boolean isAcceptedProduct = true;

        if(isOnlinePayment) {
            isPaymentSupported = acct.isOnlinePaymentFromAcct();
        } else {
            isPaymentSupported = acct.isNonOnlinePaymentFromAcct();
        }

        if (acct.getType().equals(PaymentServiceConstant.CREDIT_CARD)
                || acct.getType().equals(PaymentServiceConstant.PREPAID_CCARD)
                || acct.getType().equals(PaymentServiceConstant.CHARGE_CARD)) {
            // TODO: Looks ugly find a way to enhance it
            String currentProduct = new StringBuilder(acct.getType()).append("-").append(acct.getAccountCode()).toString();
            isAcceptedProduct = acceptedProducts.contains(currentProduct);
        }

        return isPaymentSupported && isAcceptedProduct;
    }

    public static BigDecimal getAccountBalance(GetAccountDetailsResponseDTO getAccountDetailsResp, Account fromAcct) {
        if("00".equals(getAccountDetailsResp.getAccountStatus()) && getAccountDetailsResp.getBalOrDates().size() > 0) {
            Optional<Map<String, String>> noOfBalOrDate = null;
            switch(fromAcct.getType()) {
                case PaymentServiceConstant.CREDIT_CARD:
                case PaymentServiceConstant.PREPAID_CCARD:
                case PaymentServiceConstant.CHARGE_CARD:
                    noOfBalOrDate = getAccountDetailsResp.getBalOrDates().stream().filter(x -> PaymentServiceConstant.OUTSTANDING_BALANCE.equals(x.get("typeOfBal"))).findFirst();
                    break;
                default:
                    noOfBalOrDate = getAccountDetailsResp.getBalOrDates().stream().filter(x -> PaymentServiceConstant.AVAILABLE_BALANCE.equals(x.get("typeOfBal"))).findFirst();
            }
            if(null != noOfBalOrDate.get()) {
                double amnt = Double.parseDouble(noOfBalOrDate.get().get("amountInCentsOrDate")) / 100;
                return new BigDecimal(amnt).setScale(2, RoundingMode.HALF_UP);
            }
        }
        return new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
    }

    public static BillPayment createNonOnlineBillPayment(CustomerDetails customerDetails, String txnAmt, String billAcctNo, String payeeCode) {
        String toAcctCode = null;
        switch(payeeCode) {
            case "210":
                toAcctCode = "31";
                break;
            case "211":
                toAcctCode = "32";
                break;
            case "212":
                toAcctCode = "33";
                break;
            default:
                toAcctCode = "19";
        }

        // TODO: Below are additional fields necessary for Non-online bill payment "UOBPYZZZ", we will cover it soon, #WONG
        // TODO: reference M2UGenericBillPaymentServices.setGeneralFnServerServicesExIn()
//        getFnServerServices().addToExtendedInput("credit_card_no", "00000000000000000000");
//        getFnServerServices().addToExtendedInput("expiry_date", "0000");
//        getFnServerServices().addToExtendedInput("cvv", "   ");

        // TODO: At the moment we only support MAX 1 non online bill payment per request
        BillPayment billPayment = new BillPayment();
        // TODO: Checked with @HuiLee, DPE only support normal Bill Payment, not Zakat Payment
        billPayment.setServiceCode("03");
        billPayment.setFromAcctCode(customerDetails.getFromAccount().getAccountCode());
        billPayment.setToAcctCode(toAcctCode);
        billPayment.setPayeeCode(payeeCode);
        billPayment.setIndividualEffectPaymentDate(TODAY_EFFECTIVE_DATE);
        billPayment.setCurrencyCode(customerDetails.getFromAccount().getCurrencyCode());
        billPayment.setTxnAmount(txnAmt);
        billPayment.setBillAcctNo(billAcctNo);

        String customerName = null;
        String customerNo = null;
        if ("02".equalsIgnoreCase(customerDetails.getCustomerType())) {
            // TODO: Handling for company
            customerName = customerDetails.getCompanyName();
            customerNo = customerDetails.getCompanyRegNo();
        } else {
            // TODO: Handling for standard customer, if no new IC, fallback using old IC
            customerName = customerDetails.getCustomerName();
            if (!StringUtils.isEmptyString(customerDetails.getCustomerIcBusreg())) {
                customerNo = customerDetails.getCustomerIcBusreg();
            } else {
                customerNo = customerDetails.getCustomerOldIc();
            }
        }
        billPayment.setCustName(customerName);
        billPayment.setIcNoBusRegNo(customerNo);

        // TODO: We dont support other CC in MBB_CC_DETAILS at the moment, so default below values
        billPayment.setCNo("00000000000000000000");
        billPayment.setExpiryDate("0000");
        billPayment.setCvv("   ");

        return billPayment;
    }
}
