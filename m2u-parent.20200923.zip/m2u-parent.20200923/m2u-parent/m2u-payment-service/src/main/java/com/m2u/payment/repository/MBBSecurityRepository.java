package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBSecurity;
import com.m2u.payment.entity.MBBSecurityId;
import org.springframework.data.repository.CrudRepository;

public interface MBBSecurityRepository extends CrudRepository<MBBSecurity, MBBSecurityId> {
}
