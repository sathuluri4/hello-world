package com.m2u.payment.repository;

import com.m2u.payment.entity.BVUserProfile;
import org.springframework.data.repository.CrudRepository;

public interface BVUserProfileRepository extends CrudRepository<BVUserProfile, Long> {
}
