package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBServiceDetails;
import com.m2u.payment.entity.MBBServiceDetailsId;
import org.springframework.data.repository.CrudRepository;

public interface MBBServiceDetailsRepository extends CrudRepository<MBBServiceDetails, MBBServiceDetailsId> {
}

