package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_PAYMENT_LIMIT")
@Entity
public class MBBPaymentLimit implements Serializable {

    @EmbeddedId
    private MBBPaymentLimitId mbbPaymentLimitId;

    @Column(name = "MAX_LIMIT")
    private Long maxLimit;
}
