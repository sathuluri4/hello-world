package com.m2u.payment.model;

import lombok.Data;

@Data
public abstract class AbstractAccount {

    private String displayNo;
    private String name;
    private int idx;
    private String type;
    private String currency;

    // Account Extra Info
    private String serviceName;
    private boolean transferFromAcct;
    private boolean transferToAcct;
    private boolean thirdPartyTransferFromAcct;
    private boolean thirdPartyTransferToAcct;
    private boolean onlinePaymentFromAcct;
    private boolean nonOnlinePaymentFromAcct;
    private boolean chequeServicesFromAcct;
    private boolean electronicShareApplicationToAcct;
    private boolean policyRenewalFromAcct;
    private boolean requestAcctStatementFromAcct;
    private boolean fixDepositFromAcct;
    private boolean fixDepositToAcct;
    private boolean eremittanceFromAcct;
    private boolean epfFromAcct;
    private boolean shareInvestmentCenterSMFAcct;
    private boolean fundAllocationFromAcct;
    private boolean fixDepositUpliftmentToAcct;
    private boolean addressFromAcct;
    private boolean billPaymentToAcct;
    private boolean maxihomeRedrawToAcct;
    private boolean premierPAFromAcct;
    private boolean fpxFromAcct;
    private boolean jointAcctFromAcct;
    private boolean jompayFromAcct;
    private boolean payFromAcct;
}
