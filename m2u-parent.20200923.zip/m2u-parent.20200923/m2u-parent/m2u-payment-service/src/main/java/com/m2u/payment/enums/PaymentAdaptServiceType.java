package com.m2u.payment.enums;

public enum PaymentAdaptServiceType {

    // NOTIFY
    ATTEMPT_LOGIN_USERNAME_NOTIFY ("ATTEMPT_LOGIN_USERNAME_NOTIFY", null),
    LOGIN_USERNAME_PASSWORD_FAILED_NOTIFY ("LOGIN_USERNAME_PASSWORD_FAILED_NOTIFY", null),
    GET_CUSTOMER_INFO_FROM_CLARITY_NOTIFY("GET_CUSTOMER_INFO_FROM_CLARITY_NOTIFY", null),
    CREATE_PAYMENT_TO_CLARITY_NOTIFY ("CREATE_PAYMENT_TO_CLARITY_NOTIFY", null),
    ;

    String adaptServiceName;
    String clientDefinedEventType;

    PaymentAdaptServiceType(String adaptServiceName, String clientDefinedEventType) {
        this.adaptServiceName = adaptServiceName;
        this.clientDefinedEventType = clientDefinedEventType;
    }

    public String getAdaptServiceName() {
        return adaptServiceName;
    }

    public String getClientDefinedEventType() {
        return clientDefinedEventType;
    }
}
