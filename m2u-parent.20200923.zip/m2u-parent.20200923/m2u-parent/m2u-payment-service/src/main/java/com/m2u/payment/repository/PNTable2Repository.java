package com.m2u.payment.repository;

import com.m2u.payment.entity.PNTable2;
import org.springframework.data.repository.CrudRepository;

public interface PNTable2Repository extends CrudRepository<PNTable2, String> {
}
