package com.m2u.payment.enums;

public enum PaymentAction {

    LOGIN ("Login"),
    CONTINUE ("Continue"),
    CONFIRM ("Confirm"),
    ;

    String description;

    PaymentAction (String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
