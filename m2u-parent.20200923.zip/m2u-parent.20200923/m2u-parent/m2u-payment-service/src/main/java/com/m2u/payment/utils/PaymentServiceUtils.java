package com.m2u.payment.utils;

import com.m2u.common.enums.Channel;
import com.m2u.common.exception.JSONException;
import com.m2u.common.utils.JSONUtils;
import com.m2u.common.utils.M2UUtils;
import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class PaymentServiceUtils {

    private PaymentServiceUtils() {}

    public static String convertObjectToJSON(Object obj) throws PaymentException {
        try {
            return JSONUtils.convertObjectToJSON(obj);
        } catch (JSONException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.DATA_PARSING_FAILED, e.getMessage(), e);
        }
    }

    public static <T> T convertJSONToObject(Class<T> t, String json) throws PaymentException {
        try {
            return JSONUtils.convertJSONToObject(t, json);
        } catch (JSONException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.DATA_PARSING_FAILED, e.getMessage(), e);
        }
    }

    public static void isValidToken(String expectedToken, String actualToken) throws PaymentException {
        if(!M2UUtils.isTokenValid(expectedToken, actualToken)) {
            String errorDetails = String.format("Unmatched token detected actual [%s] expected [%s]", actualToken, expectedToken);
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.TOKEN_VALIDATION_FAILED, errorDetails);
        }
    }

    public static void checkIsSystemDowntime() throws PaymentException {
        boolean isSystemDown = M2UUtils.isSystemDowntime();
        if(isSystemDown) {
            String errorDetails = "System is having downtime now";
            log.error(errorDetails);
            throw new PaymentException(PaymentServiceStatus.SERVICE_UNAVAILABLE, errorDetails);
        }
    }

    public static String getDisplayCurrency(String currencyCode) {
        // TODO: In future we need to support more currency code
        switch(currencyCode) {
            case "SGD":
                return "S$";
            default:
                // TODO: If nothing match, Malaysia currency code will be pick
                return "RM";
        }
    }

    public static String formatAmountWithCountryCurrency(BigDecimal amount, String countryCode) {
        return String.format("%s%,.2f", PaymentServiceUtils.getDisplayCurrency(countryCode), amount.doubleValue());
    }

    public static Map<String, String> createErrorMap(String errorCode, String errorMessage, Channel channel) {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("errorCode", errorCode);
        errorMap.put("errorMessage", errorMessage);
        errorMap.put("channel", channel.name());
        return errorMap;
    }
}
