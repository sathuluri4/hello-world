package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Table(name="MBB_RELAY")
@Entity
public class MBBRelay implements Serializable {

    @EmbeddedId
    private MBBRelayId mbbRelayId;

    @Column(name = "UPDATE_TIMESTAMP")
    private LocalDateTime updateTimestamp;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "FROM_CURRENCY_CODE")
    private String fromCurrencyCode;

    @Column(name = "FROM_ACC_BALANCE")
    private String fromAccBalance;

    @Column(name = "TO_CURRENCY_CODE")
    private String toCurrencyCode;

    @Column(name = "TO_ACC_BALANCE")
    private String toAccBalance;

    @Column(name = "VALUE_DATE")
    private String valueDate;

    @Column(name = "APPROVAL_CODE")
    private String approvalCode;

    @Column(name = "RECHARGE_CODE")
    private String rechargeCode;

    @Column(name = "SERIAL_NUMBER")
    private String serialNumber;

    @Column(name = "LOGIN_NAME")
    private String loginName;

    @Column(name = "LOGIN_PSWD")
    private String loginPswd;

    @Column(name = "REFERENCE_NUMBER")
    private String referenceNumber;

    @Column(name = "SEQUENCE_ID")
    private String sequenceId;

    @Column(name = "POINTS_EARNED")
    private String pointEarned;

    @Column(name = "SERVICE_TRANSACTION_ID")
    private String serviceTransactionId;

    @Column(name = "MONEY_CONTROL_DATE")
    private String moneyControlDate;

    @Column(name = "MTCN")
    private String mtcn;

    @Column(name = "RETURN_DATE_TIME")
    private String returnDateTime;

    @Column(name = "REVERSAL_INDICATOR")
    private String reversalIndicator;

    @Column(name = "SERVICE_CHARGE")
    private String serviceCharge;

    @Column(name = "GST_AMOUNT")
    private String gstAmount;

    @Column(name = "TOTAL_AMOUNT")
    private String totalAmount;

    @Column(name = "PAYMENT_RESPONSE_CODE")
    private String paymentResponseCode;

    @Column(name = "REJECT_CODE")
    private String rejectCode;

    // TODO: Check again see this columns is final? because not found it at SIT2 schema
//    @Column(name = "FUND_PRICE")
//    private String fundPrice;
//
//    @Column(name = "UNITS_ALLOTED")
//    private String unitsAlloted;
//
//    @Column(name = "SALES_CHARGE_PERCENTAGE")
//    private String salesChargePercentage;
//
//    @Column(name = "SALES_CHARGE_AMOUNT")
//    private String salesChargeAmount;
//
//    @Column(name = "SST_AMOUNT")
//    private String sstAmount;
//
//    @Column(name = "TAX_INVOICE_NO")
//    private String taxInvoiceNo;
}
