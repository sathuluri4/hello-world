package com.m2u.payment.utils;

import com.m2u.common.exception.CryptographicException;
import com.m2u.common.exception.EncryptionKeyPairException;
import com.m2u.common.model.EncryptionKeyPair;
import com.m2u.common.utils.CryptographicUtils;
import com.m2u.common.utils.EncryptionKeyPairUtils;
import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SecurityUtils {

    private SecurityUtils() {}

    public static EncryptionKeyPair createEncryptionKeyPair() throws PaymentException {
        try {
            return EncryptionKeyPairUtils.createEncryptionKeyPair();
        } catch(EncryptionKeyPairException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }

    public static String decryptEncryptedData(String data, String sessionId, String privateKey) throws PaymentException {
        try {
            return EncryptionKeyPairUtils.decryptEncryptedData(data, sessionId, privateKey);
        } catch (EncryptionKeyPairException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }

    public static String encryptCardNo(String cardNo) throws PaymentException {
        try {
            return CryptographicUtils.encrypt(cardNo);
        } catch (CryptographicException e) {
            log.error(e.getMessage(), e);
            throw new PaymentException(PaymentServiceStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }
}
