package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MBBPaymentLimitId implements Serializable {

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "PAYEE_CODE")
    private String payeeCode;

    public MBBPaymentLimitId() {}

    public MBBPaymentLimitId(Long userId, String payeeCode) {
        this.userId = userId;
        this.payeeCode = payeeCode;
    }

    public int hashCode() {
        return Objects.hash(this.userId, this.payeeCode);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MBBPaymentLimitId)) {
            return false;
        }
        MBBPaymentLimitId pk = (MBBPaymentLimitId) obj;
        return pk.userId == this.userId
            && pk.payeeCode.equals(this.payeeCode);
    }
}
