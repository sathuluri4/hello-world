package com.m2u.payment.enums;

public enum AdaptResponseCode {

    USER_IS_REMOVED (1502, "User is removed"),
    ;

    int reasonCode;
    String desc;

    AdaptResponseCode(int reasonCode, String desc) {
        this.reasonCode = reasonCode;
        this.desc = desc;
    }

    public int getReasonCode() {
        return reasonCode;
    }

    public String getDesc() {
        return desc;
    }
}
