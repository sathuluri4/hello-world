package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBProductInfo;
import com.m2u.payment.entity.MBBProductInfoId;
import org.springframework.data.repository.CrudRepository;

public interface MBBProductInfoRepository extends CrudRepository<MBBProductInfo, MBBProductInfoId> {
}
