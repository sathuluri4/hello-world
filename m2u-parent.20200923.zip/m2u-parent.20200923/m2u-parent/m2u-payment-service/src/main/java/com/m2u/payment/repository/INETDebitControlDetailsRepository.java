package com.m2u.payment.repository;

import com.m2u.payment.entity.INETDebitControlDetails;
import com.m2u.payment.entity.INETDebitControlDetailsId;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface INETDebitControlDetailsRepository extends CrudRepository<INETDebitControlDetails, INETDebitControlDetailsId> {

    @Query("select count(*), sum(a.transactionAmount) " +
        "from INETDebitControlDetails a " +
        "where a.inetDebitControlDetailsId.userId = :userId " +
        "and a.inetDebitControlDetailsId.payeeCode = :payeeCode " +
        "and trunc(a.inetDebitControlDetailsId.transactionDate) = trunc(:currentDate)")
    List<Object[]> countTotalTxnsAndToTalAmounts(Long userId, String payeeCode, LocalDateTime currentDate);
}
