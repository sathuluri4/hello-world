package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBPayeeGeneralList;
import com.m2u.payment.entity.MBBPayeeGeneralListId;
import org.springframework.data.repository.CrudRepository;

public interface MBBPayeeGeneralListRepository extends CrudRepository<MBBPayeeGeneralList, MBBPayeeGeneralListId> {
}
