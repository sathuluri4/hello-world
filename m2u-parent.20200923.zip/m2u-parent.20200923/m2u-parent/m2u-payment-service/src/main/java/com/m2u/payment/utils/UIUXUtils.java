package com.m2u.payment.utils;

import com.m2u.common.utils.StringUtils;
import com.m2u.payment.model.Account;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UIUXUtils {

    private static final String LABEL = "label";
    private static final String VALUE = "value";
    
    private UIUXUtils() {}

    public static Map<String, Object> createField(String label, String fieldName, String value, String type, List<Object> options,
        String maxFieldLength, boolean isRequired, String minValue, String maxValue, String placeHolderText, String helpText, boolean isFavoriteField,
              String accordianGroupLabel, String accordianGroupLabelIndex, List<Object> preConditions, boolean isReadonly) {

        Map<String, Object> field = new HashMap<>();
        field.put(LABEL, label);
        field.put("fieldName", fieldName);
        field.put(VALUE, value);
        field.put("type", type);
        field.put("options", options);
        field.put("maxFieldLength", maxFieldLength != null ? Integer.valueOf(maxFieldLength) : null);
        field.put("isRequired", isRequired);
        field.put("minValue", minValue != null ? Double.valueOf(minValue) : null);
        field.put("maxValue", maxValue != null ? Double.valueOf(maxValue) : null);
        field.put("placeHolderText", placeHolderText);
        field.put("helpText", helpText);
        field.put("isFavoriteField", isFavoriteField);
        field.put("accordianGroupLabel", accordianGroupLabel);
        field.put("accordianGroupLabelIndex", accordianGroupLabelIndex != null ? Integer.valueOf(accordianGroupLabelIndex) : null);
        field.put("preConditions", preConditions);
        field.put("isReadonly", isReadonly);

        return field;
    }

    public static Map<String, Object> createItemBlock(String fieldName, String label, String type, String align, String action,
        List<Object> params, Map<String, Object> callbackProps, String mode, boolean requireValidation, boolean responseRequired, String className) {
        
        Map<String, Object> actionMap = new HashMap<>();
        actionMap.put("actionURL", action);
        actionMap.put("actionType", "restAPI");
        actionMap.put("requireValidation", requireValidation);
        actionMap.put("responseRequired", responseRequired);

        Map<String, Object> item = new HashMap<>();
        item.put("fieldName", fieldName);
        item.put(LABEL, label);
        item.put("type", type);
        item.put("align", align);        
        item.put("action", actionMap);
        item.put("params", params);
        item.put("callbackProps", callbackProps);
        item.put("mode", mode);

        Map<String, Object> style = new HashMap<>();
        style.put("weight", 2);
        if (StringUtils.isEmptyString(className)) {
            style.put("className", "saveButton pull-right");
        } else {
            style.put("className", className);
        }

        item.put("style", style);

        return item;
    }

    public static List<Object> createDynamicFields(List<Object> items, String sectionTitle) {
        List<Object> dynamicFields = new ArrayList<>();
        List<Object> itemsList = new ArrayList<>();

        if (!StringUtils.isEmptyString(sectionTitle)) {
            Map<String, Object> itemOne = new HashMap<>();
            itemOne.put("type", "imageHeader");
            itemOne.put(VALUE, sectionTitle);
            itemsList.add(itemOne);
        }

        itemsList.addAll(items);
        Map<String, Object> itemContent = new HashMap<>();
        itemContent.put("type", "container");
        itemContent.put("items", itemsList);
        dynamicFields.add(itemContent);

        return dynamicFields;
    }

    public static Map<String, Object> createSummaryItem(String value, String type, String label, String subLabel, String subValue) {
        Map<String, Object> field = new HashMap<>();
        field.put(VALUE, value);
        field.put("type", type);
        field.put(LABEL, label);

        if(null != subLabel && null != subValue) {
            field.put("subLabel", subLabel);
            field.put("subValue", subValue);
        }

        return field;
    }

    public static Map<String, Object> createActionItems(String actionURL, String mode, String status, String type, String value, Map<String, Object> callbackProps, List<Object> items) {
        Map<String, Object> action = new HashMap<>();
        action.put("actionType", "restAPI");
        action.put("actionURL", actionURL);

        Map<String, Object> field = new HashMap<>();
        field.put("action", action);
        field.put("mode", mode);
        field.put("status", status);
        field.put("type", type);
        field.put(VALUE, value);
        field.put("callbackProps", callbackProps);
        field.put("items", items);
        
        return field;
    }

    public static List<Object> createAccountOptions(List<Account> accounts) {
        List<Object> options = new ArrayList<>();

        for(Account acct : accounts) {
            Map<String, Object> option = new HashMap<>();
            option.put(VALUE, acct.getAccountNo());
            option.put(LABEL, acct.getName());
            option.put("subLabel", acct.getDisplayNo());
            option.put("idx", acct.getIdx());

            options.add(option);
        }
        
        return options;
    }
}
