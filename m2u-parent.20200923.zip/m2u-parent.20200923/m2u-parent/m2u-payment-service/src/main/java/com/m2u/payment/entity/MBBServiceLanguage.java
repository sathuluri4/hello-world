package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_SERVICE_LANGUAGE")
@Entity
public class MBBServiceLanguage implements Serializable {

    @EmbeddedId
    private MBBServiceLanguageId mbbServiceLanguageId;

    @Column(name="SERVICE_NAME")
    private String serviceName;

    @Column(name="MAIN_NOTE1")
    private String mainNote1;

    @Column(name="MAIN_NOTE2")
    private String mainNote2;

    @Column(name="MAIN_NOTE3")
    private String mainNote3;

    @Column(name="MAIN_NOTE4")
    private String mainNote4;

    @Column(name="MAIN_NOTE5")
    private String mainNote5;

    @ManyToOne
    @MapsId("oid")
    @JoinColumn(name="oid")
    private MBBServiceList mbbServiceList;
}
