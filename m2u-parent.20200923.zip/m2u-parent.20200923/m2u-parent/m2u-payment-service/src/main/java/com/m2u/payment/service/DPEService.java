package com.m2u.payment.service;

import com.m2u.payment.dto.*;
import com.m2u.payment.exception.PaymentException;

import java.io.ByteArrayInputStream;

public interface DPEService {

    InitializationResponseDTO initialization(InitializationRequestDTO req) throws PaymentException;
    PreAuthenticationResponseDTO preAuthentication(PreAuthenticationRequestDTO req) throws PaymentException;
    PostAuthenticationResponseDTO postAuthentication(PostAuthenticationRequestDTO req) throws PaymentException;
    TxnConfirmationResponseDTO confirmTransaction(TxnConfirmationRequestDTO req) throws PaymentException;
    CreateOTPResponseDTO createOTP(CreateOTPRequestDTO req) throws PaymentException;
    TxnCompletionResponseDTO completeTransaction(TxnCompletionRequestDTO req) throws PaymentException;
    ByteArrayInputStream generatePDFReceipt(PDFReceiptGenerationRequestDTO req) throws PaymentException;
}
