package com.m2u.payment.repository;

import com.m2u.payment.entity.SMSTable;
import com.m2u.payment.entity.SMSTableId;
import org.springframework.data.repository.CrudRepository;

public interface SMSTableRepository extends CrudRepository<SMSTable, SMSTableId> {
}
