package com.m2u.payment.utils;

import com.m2u.payment.entity.MBBServiceDetails;
import com.m2u.payment.entity.MBBServiceDetailsNew;
import com.m2u.payment.entity.MBBServiceLanguage;
import com.m2u.payment.entity.MBBServiceList;
import com.m2u.payment.model.DCCNote;
import com.m2u.payment.repository.MBBServiceListRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class DCCUtils {

    private static MBBServiceListRepository mbbServiceListRepository;

    private DCCUtils() {}

    @Autowired
    private synchronized void setMBBServiceListRepository(MBBServiceListRepository mbbServiceListRepo){
        mbbServiceListRepository = mbbServiceListRepo;
    }

    public static DCCNote getDCCNote(String serviceName, String serviceCode, String locale) {
        List<Object[]> objs = mbbServiceListRepository.findByServiceCodeAndSubServiceCodeAndLocale(serviceName, serviceCode, locale);

        DCCNote dccNote = null;

        // TODO: Below is just forming the ServiceInfoBean
        if(!objs.isEmpty()) {
            Object[] obj = objs.get(0);
            MBBServiceList mbbServiceList = (MBBServiceList) obj[0];
            MBBServiceLanguage mbbServiceLanguage = (MBBServiceLanguage) obj[1];
            MBBServiceDetails mbbServiceDetails = (MBBServiceDetails) obj[2];
            MBBServiceDetailsNew mbbServiceDetailsNew = (MBBServiceDetailsNew) obj[3];

            dccNote = new DCCNote();

            dccNote.setOid(mbbServiceList.getOid());
            dccNote.setServiceName(mbbServiceList.getServiceName());
            dccNote.setSmsService(mbbServiceList.getSmsService());
            dccNote.setSmsMinAmount(mbbServiceList.getMinimumSmsAmount());
            dccNote.setStatus(mbbServiceList.getStatus());

            if(null != mbbServiceLanguage) {
                dccNote.setMainNote1(mbbServiceLanguage.getMainNote1());
                dccNote.setMainNote2(mbbServiceLanguage.getMainNote2());
                dccNote.setMainNote3(mbbServiceLanguage.getMainNote3());
                dccNote.setMainNote4(mbbServiceLanguage.getMainNote4());
                dccNote.setMainNote5(mbbServiceLanguage.getMainNote5());
            } else {
                dccNote.setMainNote1(mbbServiceList.getMainNote1());
                dccNote.setMainNote2(mbbServiceList.getMainNote2());
                dccNote.setMainNote3(mbbServiceList.getMainNote3());
                dccNote.setMainNote4(mbbServiceList.getMainNote4());
                dccNote.setMainNote5(mbbServiceList.getMainNote5());
            }

            if(null != mbbServiceDetailsNew) {
                dccNote.setSubServiceName(mbbServiceDetailsNew.getSubServiceName());
                dccNote.setDenominator(mbbServiceDetailsNew.getDenominator());
                dccNote.setMaxLimit(mbbServiceDetailsNew.getMaxLimit());
                dccNote.setSubNote1(mbbServiceDetailsNew.getNote1());
                dccNote.setSubNote2(mbbServiceDetailsNew.getNote2());
                dccNote.setSubNote3(mbbServiceDetailsNew.getNote3());
                dccNote.setSubNote4(mbbServiceDetailsNew.getNote4());
                dccNote.setSubNote5(mbbServiceDetailsNew.getNote5());
            } else if (null != mbbServiceDetails) {
                dccNote.setSubServiceName(mbbServiceDetails.getSubServiceName());
                dccNote.setDenominator(mbbServiceDetails.getDenominator());
                dccNote.setMaxLimit(mbbServiceDetails.getMaxLimit());
                dccNote.setSubNote1(mbbServiceDetails.getNote1());
                dccNote.setSubNote2(mbbServiceDetails.getNote2());
                dccNote.setSubNote3(mbbServiceDetails.getNote3());
                dccNote.setSubNote4(mbbServiceDetails.getNote4());
                dccNote.setSubNote5(mbbServiceDetails.getNote5());
            }
        }

        return dccNote;
    }
}
