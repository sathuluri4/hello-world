package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBAdapt;
import org.springframework.data.repository.CrudRepository;

public interface MBBAdaptRepository extends CrudRepository<MBBAdapt, Long> {
}
