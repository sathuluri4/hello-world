package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class INETReceiptDetailsId implements Serializable {

    @Column(name = "CREATE_TIME")
    private LocalDateTime createTime;

    @Column(name = "TRANSACTION_REF_ID")
    private String transactionRefId;

    public INETReceiptDetailsId() {}

    public INETReceiptDetailsId(LocalDateTime createTime, String transactionRefId) {
        this.createTime = createTime;
        this.transactionRefId = transactionRefId;
    }

    public int hashCode() {
        return Objects.hash(this.createTime, this.transactionRefId);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof INETReceiptDetailsId)) {
            return false;
        }
        INETReceiptDetailsId pk = (INETReceiptDetailsId) obj;
        return pk.createTime.isEqual(this.createTime)
            && pk.transactionRefId.equals(this.transactionRefId);
    }
}
