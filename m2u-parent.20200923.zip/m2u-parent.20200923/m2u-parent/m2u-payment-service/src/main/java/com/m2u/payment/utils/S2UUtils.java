package com.m2u.payment.utils;

import com.m2u.common.constants.DCCConstant;
import com.m2u.payment.model.DCCNote;
import com.m2u.payment.resources.M2UApplicationResources;
import com.m2u.payment.resources.M2UBusinessOptionsResources;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class S2UUtils {

    private static final String LABEL_FIELD = "label";
    private static final String VALUE_FIELD  = "value";
    private static final String IS_DEFAULT_FIELD  = "isDefault";
    private static final String IS_REGISTERED_FIELD  = "isRegistered";
    private static final String NOTIFICATION_MESSAGE_FIELD  = "notificationMessage";

    private static final String GENERAL_TRNSIGN_PROPERTY = "general.TRNSIGN";
    private static final String GENERAL_TAC_PROPERTY = "general.TAC";

    private S2UUtils() {}

    public static boolean isS2UUser(String customerType) {
        switch(customerType) {
            case "09":
            case "14":
            case "24":
            case "26":
            case "39":
                return false;
            default:
                return true;
        }
    }

    public static List<Map<String, Object>> getSecureTypes(boolean isTACRequired, String customerType, String s2uIndicator, double txnAmt, String locale) {
        List<Map<String, Object>> secureTypes = null;
        // TODO: Checked with @HuiLee we should based on payee setting in DB to enable or disabled TAC authorisation (S2U or SMS TAC), if it is OFF skip all S2U and TAC checking
        if(isTACRequired) {
            boolean isS2UOn = false;
            boolean isTxnSignRegistered = false;
            String authTxnInd = null;
            String custS2UIndicator = s2uIndicator;
            double txnLimit = 0.0;

            // TODO: Reference BVUtils.getNoteFromDCCS2u()
            String serviceName = M2UBusinessOptionsResources.getValue("secure2u.subservice.details");
            DCCNote dccNote = DCCUtils.getDCCNote(serviceName, "SEC7000", locale);

            if(null != dccNote && DCCConstant.DCC_ACTIVE.equals(dccNote.getStatus())) {
                isS2UOn = true;

                if(null != dccNote.getMaxLimit()) {
                    txnLimit = dccNote.getMaxLimit().doubleValue();
                }
                if(null != custS2UIndicator && "01".equals(custS2UIndicator)) {
                    isTxnSignRegistered = true;
                }

                authTxnInd = dccNote.getSubNote1();
                if(null == authTxnInd) {
                    authTxnInd = "3";
                }
            }

            // TODO: Reference Secure2uUtil.getSecureTypes()
            boolean isS2UUser = S2UUtils.isS2UUser(customerType);
            secureTypes = S2UUtils.getSecureOptions(isS2UUser, isS2UOn, txnLimit, txnAmt, authTxnInd, isTxnSignRegistered, locale);
        }

        return secureTypes;
    }

    public static List<Map<String, Object>> getSecureOptions(boolean isS2UUser, boolean isS2UOn, double txnLimit, double amount, String authTxnInd, boolean isTxnSignRegistered, String locale) {
        List<Map<String, Object>> secureOptions = new ArrayList<>();
        Map<String, Object> secureMap1 = null;
        Map<String, Object> secureMap2 = null;
        Map<String, Object> secureMap3 = null;

        if(isS2UUser) {
            if(isS2UOn) {
                if(txnLimit > 0 && amount > txnLimit) {
                    secureMap1 = new HashMap<>();
                    secureMap1.put(LABEL_FIELD, M2UApplicationResources.getValue(GENERAL_TRNSIGN_PROPERTY, locale));
                    secureMap1.put(VALUE_FIELD, "004");
                } else {
                    if(authTxnInd.equals("1") || authTxnInd.equals("4") || authTxnInd.equals("5") || authTxnInd.equals("7")){
                        secureMap1 = new HashMap<>();
                        secureMap1.put(LABEL_FIELD, M2UApplicationResources.getValue(GENERAL_TRNSIGN_PROPERTY, locale));
                        secureMap1.put(VALUE_FIELD, "004");
                    }
                    if(authTxnInd.equals("2") || authTxnInd.equals("4") || authTxnInd.equals("6") || authTxnInd.equals("7")){
                        secureMap2 = new HashMap<>();
                        secureMap2.put(LABEL_FIELD, M2UApplicationResources.getValue("general.SOFTTKN", locale));
                        secureMap2.put(VALUE_FIELD, "005");
                    }
                    if(authTxnInd.equals("3") || authTxnInd.equals("5") || authTxnInd.equals("6") || authTxnInd.equals("7")){
                        secureMap3 = new HashMap<>();
                        secureMap3.put(LABEL_FIELD, M2UApplicationResources.getValue(GENERAL_TAC_PROPERTY, locale));
                        secureMap3.put(VALUE_FIELD, "000");
                    }
                }
            } else {
                secureMap3=new HashMap<>();
                secureMap3.put(LABEL_FIELD, M2UApplicationResources.getValue(GENERAL_TAC_PROPERTY, locale));
                secureMap3.put(VALUE_FIELD, "000");
                secureMap3.put(IS_DEFAULT_FIELD, true);
            }

            if(!isTxnSignRegistered){
                secureMap1 = new HashMap<>();
                secureMap1.put(LABEL_FIELD, M2UApplicationResources.getValue(GENERAL_TRNSIGN_PROPERTY, locale));
                secureMap1.put(VALUE_FIELD, "004");
                secureMap1.put(IS_REGISTERED_FIELD, false);
                secureMap1.put(NOTIFICATION_MESSAGE_FIELD, M2UApplicationResources.getValue("secure2u.unregistered.digitalsigning.note", locale));

                secureMap2 = new HashMap<>();
                secureMap2.put(LABEL_FIELD, M2UApplicationResources.getValue("general.SOFTTKN", locale));
                secureMap2.put(VALUE_FIELD, "005");
                secureMap2.put(IS_REGISTERED_FIELD, false);
                secureMap2.put(NOTIFICATION_MESSAGE_FIELD, M2UApplicationResources.getValue("secure2u.unregistered.digitaltac.note", locale));

                secureMap3 = new HashMap<>();
                secureMap3.put(LABEL_FIELD, M2UApplicationResources.getValue(GENERAL_TAC_PROPERTY, locale));
                secureMap3.put(VALUE_FIELD, "000");
                secureMap3.put(IS_REGISTERED_FIELD, true);
                secureMap3.put(IS_DEFAULT_FIELD, true);

            } else {
                if(null != secureMap1){
                    secureMap1.put(IS_DEFAULT_FIELD, true);
                    secureMap1.put(IS_REGISTERED_FIELD, true);
                    secureMap1.put(NOTIFICATION_MESSAGE_FIELD, M2UApplicationResources.getValue("general.trnsign.tooltip", locale));
                }
                if(null != secureMap2){
                    secureMap2.put(IS_REGISTERED_FIELD, true);
                    secureMap2.put(NOTIFICATION_MESSAGE_FIELD, M2UApplicationResources.getValue("general.softTkn.tooltip", locale));
                }
            }
        } else {
            secureMap3 = new HashMap<>();
            secureMap3.put(LABEL_FIELD, M2UApplicationResources.getValue(GENERAL_TAC_PROPERTY, locale));
            secureMap3.put(VALUE_FIELD, "000");
            secureMap3.put(IS_DEFAULT_FIELD, true);
        }

        if(null != secureMap1) {
            secureOptions.add(secureMap1);
        }
        if(null != secureMap2) {
            secureOptions.add(secureMap2);
        }
        if(null != secureMap3){
            secureMap3.put(IS_REGISTERED_FIELD, true);
            secureMap3.put(NOTIFICATION_MESSAGE_FIELD, M2UApplicationResources.getValue("general.tac.tooltip", locale));
            secureOptions.add(secureMap3);
        }

        return secureOptions;
    }
}
