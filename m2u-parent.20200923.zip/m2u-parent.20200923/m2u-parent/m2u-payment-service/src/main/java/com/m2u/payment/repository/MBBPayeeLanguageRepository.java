package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBPayeeLanguage;
import org.springframework.data.repository.CrudRepository;

public interface MBBPayeeLanguageRepository extends CrudRepository<MBBPayeeLanguage, Long> {
}
