package com.m2u.payment.model;

import lombok.Data;
import lombok.ToString;

import java.math.BigDecimal;

@ToString(callSuper = true)
@Data
public class Account extends AbstractAccount {

    private String accountNo;
    private String accountCode;
    private String currencyCode;
    private BigDecimal balance;
    private String displayBalAmt;
}
