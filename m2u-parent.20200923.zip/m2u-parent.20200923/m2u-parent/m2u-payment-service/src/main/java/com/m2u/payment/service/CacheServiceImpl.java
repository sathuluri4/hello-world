package com.m2u.payment.service;

import com.m2u.common.utils.M2UUtils;
import com.m2u.payment.dto.ResetM2UCacheRequestDTO;
import com.m2u.payment.dto.ResetM2UCacheResponseDTO;
import com.m2u.payment.enums.CacheType;
import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Slf4j
@Service
public class CacheServiceImpl implements CacheService {

    @Autowired
    private CacheManager cacheManager;

    @Override
    public ResetM2UCacheResponseDTO resetM2UCache(ResetM2UCacheRequestDTO req, String target) throws PaymentException {
        switch(target) {
            case "dcc":
                resetM2UCache(CacheType.M2U_DCC_CACHE.getCacheName());
                break;
            case "payment":
                resetM2UCache(CacheType.M2U_PAYMENT_CACHE.getCacheName());
                break;
            case "all":
                resetAllM2UCaches();
                break;
            default:
                String errorDetails = String.format("Unsupported cache [%s] detected", target);
                log.error(errorDetails);
                throw new PaymentException(PaymentServiceStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        ResetM2UCacheResponseDTO resp = new ResetM2UCacheResponseDTO();
        resp.setSessionId(M2UUtils.createSessionId());
        resp.setEngineId(req.getEngineId());
        resp.setCurrentDate(LocalDateTime.now());
        resp.setError(null);
        resp.setDeviceTokenCookie(req.getDeviceTokenCookie());
        resp.setDeviceTokenFSO(req.getDeviceTokenFSO());

        return resp;
    }

    private void resetM2UCache(String cacheName) {
        cacheManager.getCache(cacheName).clear();
        log.info("M2U cache [{}] reset successfully", cacheName);
    }

    private void resetAllM2UCaches() {
        for(String cacheName : cacheManager.getCacheNames()) {
            resetM2UCache(cacheName);
        }
    }
}
