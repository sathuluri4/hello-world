package com.m2u.payment.config;

import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.xml.rpc.ServiceException;
import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.util.Properties;

@Slf4j
@Component
public class PassItOnConfiguration {

    private static final Properties properties = new Properties();

    private PassItOnConfiguration(
        @Value("${m2u.payment.pass-it-on.config-path}") String path) throws MalformedURLException, ServiceException, PaymentException {

        try (FileInputStream in = new FileInputStream(path)) {
            properties.load(in);
        } catch (Exception e) {
            String errorDetails = String.format("Failed to read content from [%s]", path);
            log.error(errorDetails, e);
            throw new PaymentException(PaymentServiceStatus.INTERNAL_SERVER_ERROR, errorDetails, e);
        }
    }

    public static String getProperty(String key) {
        return properties.get(key).toString();
    }
}
