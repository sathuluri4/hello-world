package com.m2u.payment.repository;

import com.m2u.payment.entity.MBBPaymentLimit;
import com.m2u.payment.entity.MBBPaymentLimitId;
import org.springframework.data.repository.CrudRepository;

public interface MBBPaymentLimitRepository extends CrudRepository<MBBPaymentLimit, MBBPaymentLimitId> {

    MBBPaymentLimit findByMbbPaymentLimitIdUserIdAndMbbPaymentLimitIdPayeeCode(Long userId, String payeeCode);
}
