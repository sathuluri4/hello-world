package com.m2u.payment.model;

import lombok.Data;
import lombok.ToString;

@ToString(callSuper = true)
@Data
public class CreditCard extends AbstractAccount {

    private String cardNo;
    private String cardBrand;
    private String cvv2CVC2;
    private String expiryMonth;
    private String expiryYear;
    private String description;
    private String cardStatus;
    private String logDate;
    private String ccNumberSecured;
    private String cvv2CVC2Secured;
}
