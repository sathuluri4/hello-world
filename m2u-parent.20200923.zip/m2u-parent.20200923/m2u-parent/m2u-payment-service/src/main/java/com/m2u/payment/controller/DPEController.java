package com.m2u.payment.controller;

import com.m2u.payment.dto.*;
import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import com.m2u.payment.service.DPEService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.net.UnknownHostException;

@Slf4j
@RestController
public class DPEController extends AbstractController {
    
    // TODO: Temporary solution, think a way how to create unique ID per SpringBoot instance
    @Value("${m2u.payment.engine-id}")
    private String engineId;

    @Autowired
    private DPEService DPEService;

    @PostMapping(path = "/v1/initialization",
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<InitializationResponseDTO> initialization(HttpServletRequest httpReq, @RequestBody InitializationRequestDTO req) {
        try {
            log.debug(SLF4J_REQ_TEMPLATE, req);
            init(httpReq, req);
            InitializationResponseDTO resp = DPEService.initialization(req);
            resp.setStatusCode(PaymentServiceStatus.SUCCESS.getStatusCode());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return ResponseEntity.ok(resp);
        } catch (PaymentException e) {
            InitializationResponseDTO resp = new InitializationResponseDTO(req.getSessionId(), null, engineId, e.getStatus().getStatusCode(), e.getMessage());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, e.getStatus().getHttpStatus());
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION_OCCURRED, e);
            InitializationResponseDTO resp = new InitializationResponseDTO(req.getSessionId(), null, engineId, PaymentServiceStatus.UNEXPECTED_EXCEPTION);
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(path = "/v1/pre-authentication",
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PreAuthenticationResponseDTO> preAuthentication(HttpServletRequest httpReq, @RequestBody PreAuthenticationRequestDTO req) {
        try {
            log.debug(SLF4J_REQ_TEMPLATE, req);
            init(httpReq, req);
            PreAuthenticationResponseDTO resp = DPEService.preAuthentication(req);
            resp.setStatusCode(PaymentServiceStatus.SUCCESS.getStatusCode());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return ResponseEntity.ok(resp);
        } catch (PaymentException e) {
            PreAuthenticationResponseDTO resp = new PreAuthenticationResponseDTO(req.getSessionId(), getLastToken(req.getSessionId()), engineId, e.getStatus().getStatusCode(), e.getMessage());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, e.getStatus().getHttpStatus());
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION_OCCURRED, e);
            PreAuthenticationResponseDTO resp = new PreAuthenticationResponseDTO(req.getSessionId(), getLastToken(req.getSessionId()), engineId, PaymentServiceStatus.UNEXPECTED_EXCEPTION);
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(path = "/v1/post-authentication",
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PostAuthenticationResponseDTO> postAuthentication(HttpServletRequest httpReq, @RequestBody PostAuthenticationRequestDTO req) {
        try {
            log.debug(SLF4J_REQ_TEMPLATE, req);
            init(httpReq, req);
            PostAuthenticationResponseDTO resp = DPEService.postAuthentication(req);
            resp.setStatusCode(PaymentServiceStatus.SUCCESS.getStatusCode());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return ResponseEntity.ok(resp);
        } catch (PaymentException e) {
            PostAuthenticationResponseDTO resp = new PostAuthenticationResponseDTO(req.getSessionId(), getLastToken(req.getSessionId()), engineId, e.getStatus().getStatusCode(), e.getMessage());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, e.getStatus().getHttpStatus());
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION_OCCURRED, e);
            PostAuthenticationResponseDTO resp = new PostAuthenticationResponseDTO(req.getSessionId(), getLastToken(req.getSessionId()), engineId, PaymentServiceStatus.UNEXPECTED_EXCEPTION);
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(path = "/v1/txn-confirmation",
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TxnConfirmationResponseDTO> txnConfirmation(HttpServletRequest httpReq, @RequestBody TxnConfirmationRequestDTO req) throws UnknownHostException {
        try {
            log.debug(SLF4J_REQ_TEMPLATE, req);
            init(httpReq, req);
            TxnConfirmationResponseDTO resp = DPEService.confirmTransaction(req);
            resp.setStatusCode(PaymentServiceStatus.SUCCESS.getStatusCode());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return ResponseEntity.ok(resp);
        } catch (PaymentException e) {
            TxnConfirmationResponseDTO resp = new TxnConfirmationResponseDTO(req.getSessionId(), getLastToken(req.getSessionId()), engineId, e.getStatus().getStatusCode(), e.getMessage());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, e.getStatus().getHttpStatus());
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION_OCCURRED, e);
            TxnConfirmationResponseDTO resp = new TxnConfirmationResponseDTO(req.getSessionId(), getLastToken(req.getSessionId()), engineId, PaymentServiceStatus.UNEXPECTED_EXCEPTION);
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(path = "/v1/otp-creation",
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CreateOTPResponseDTO> createOTP(HttpServletRequest httpReq, @RequestBody CreateOTPRequestDTO req) {
        try {
            log.debug(SLF4J_REQ_TEMPLATE, req);
            init(httpReq, req);
            CreateOTPResponseDTO resp = DPEService.createOTP(req);
            resp.setStatusCode(PaymentServiceStatus.SUCCESS.getStatusCode());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return ResponseEntity.ok(resp);
        } catch (PaymentException e) {
            CreateOTPResponseDTO resp = new CreateOTPResponseDTO(req.getSessionId(), getLastToken(req.getSessionId()), engineId, e.getStatus().getStatusCode(), e.getMessage());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, e.getStatus().getHttpStatus());
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION_OCCURRED, e);
            CreateOTPResponseDTO resp = new CreateOTPResponseDTO(req.getSessionId(), getLastToken(req.getSessionId()), engineId, PaymentServiceStatus.UNEXPECTED_EXCEPTION);
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(path = "/v1/txn-completion",
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TxnCompletionResponseDTO> txnCompletion(HttpServletRequest httpReq, @RequestBody TxnCompletionRequestDTO req) {
        try {
            log.debug(SLF4J_REQ_TEMPLATE, req);
            init(httpReq, req);
            TxnCompletionResponseDTO resp = DPEService.completeTransaction(req);
            resp.setStatusCode(PaymentServiceStatus.SUCCESS.getStatusCode());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return ResponseEntity.ok(resp);
        } catch (PaymentException e) {
            TxnCompletionResponseDTO resp = new TxnCompletionResponseDTO(req.getSessionId(), req.getToken(), engineId, e.getStatus().getStatusCode(), e.getMessage());
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, e.getStatus().getHttpStatus());
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION_OCCURRED, e);
            TxnCompletionResponseDTO resp = new TxnCompletionResponseDTO(req.getSessionId(), req.getToken(), engineId, PaymentServiceStatus.UNEXPECTED_EXCEPTION);
            log.debug(SLF4J_RESP_TEMPLATE, resp);
            return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @GetMapping(path = "/v1/receipt-generation",
//        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
    @PostMapping(path = "/v1/receipt-generation",
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> pdfReceiptGeneration(
        HttpServletRequest httpReq, HttpServletResponse httpResp, @RequestBody PDFReceiptGenerationRequestDTO req) {

        try {
            log.debug(SLF4J_REQ_TEMPLATE, req);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=Receipt.pdf");
            headers.add("Access-Control-Allow-Origin", "*");
            headers.add("Access-Control-Allow-Headers", "X-Requested-With");

            ByteArrayInputStream byteArrayInputStream = DPEService.generatePDFReceipt(req);
            return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(byteArrayInputStream));
        } catch (Exception e) {
            String errorDetails = String.format("Failed to generate PDF receipt. sessionId [%s] token [%s] engineId [%s]", req.getSessionId(), req.getToken(), engineId);
            log.error(errorDetails, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}