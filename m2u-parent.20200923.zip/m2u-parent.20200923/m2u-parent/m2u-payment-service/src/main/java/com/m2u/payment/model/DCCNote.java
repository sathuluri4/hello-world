package com.m2u.payment.model;

import lombok.Data;

@Data
public class DCCNote {

    private Long oid = null;
    private String serviceName = null;
    private Long smsService = null;
    private Long smsMinAmount = null;
    private String mainNote1 = null;
    private String mainNote2 = null;
    private String mainNote3 = null;
    private String mainNote4 = null;
    private String mainNote5 = null;
    private Long status = null;

    // TODO: From MBB_SERVICE_DETAILS/MBB_SERVICE_DETAILS_NEW
    private String subServiceName = null;
    private Long denominator = null;
    private Long maxLimit = null;
    private String subNote1;
    private String subNote2;
    private String subNote3;
    private String subNote4;
    private String subNote5;
}
