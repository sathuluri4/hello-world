package com.m2u.payment.utils;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorker;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.itextpdf.tool.xml.css.CssFile;
import com.itextpdf.tool.xml.css.StyleAttrCSSResolver;
import com.itextpdf.tool.xml.html.Tags;
import com.itextpdf.tool.xml.parser.XMLParser;
import com.itextpdf.tool.xml.pipeline.css.CSSResolver;
import com.itextpdf.tool.xml.pipeline.css.CssResolverPipeline;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipelineContext;
import com.m2u.common.utils.DateTimeUtils;
import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.enums.TransactionStatus;
import com.m2u.payment.exception.PaymentException;
import com.m2u.payment.model.PayeeDetails;
import com.m2u.payment.resources.M2UApplicationResources;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@Component
public class ReceiptUtils {

    private static final String NEW_EMPTY_LINE = "<td>&nbsp;<strong>%s</strong></td>\n";
    
    private static final String PAYMENT_RECEIPT_TEMPLATE = new StringBuilder()
            .append("<div>\n")
            .append("<h1></h1>\n")
            .append("</div>\n")
            .append("<div id='content'>\n")
            .append("<table width='100%%' cellspacing='0' cellpadding='0' border='0'>\n")
            .append("<tr>\n")
            .append("<td><img src='/bv_data/images/m2u_logo.gif' border='0'/></td>\n")
            .append("</tr>\n")
            .append("<tr><td>&nbsp;</td></tr>\n")
            .append("</table>\n")
            .append("<h2><b>%s</b></h2>\n") // TYPE OF PAYMENT
            .append("<br/>\n")
            .append("<table width='100%%' cellspacing='0' cellpadding='0' border='0'>\n")
            .append("<tr>\n")
            .append("<td>%s:</td>\n") // STATUS LABEL
            .append("<td>&nbsp;<strong><span class='%s'>%s</span></strong></td>\n") // STATUS VALUE
            .append("</tr>\n")
            .append("<tr><td colspan='2'>&nbsp;</td></tr>\n")
            .append("<tr>\n")
            .append("<td>%s:</td>\n") // REFERENCE NO LABEL
            .append(NEW_EMPTY_LINE) // REFERENCE NO VALUE
            .append("</tr>\n")
            .append("<tr><td colspan='2'>&nbsp;</td></tr>\n")
            .append("<tr>\n")
            .append("<td>%s:</td>\n") // TXN DATE LABEL
            .append(NEW_EMPTY_LINE) // TXN DATE VALUE
            .append("</tr>\n")
            .append("<tr><td colspan='2'>&nbsp;</td></tr>\n")
            .append("<tr>\n")
            .append("<td>%s:</td>\n") // TXN AMOUNT LABEL
            .append(NEW_EMPTY_LINE) // TXN AMOUNT VALUE
            .append("</tr>\n")
            .append("<tr><td colspan='2'>&nbsp;</td></tr>\n")
            .append("<tr>\n")
            .append("<td>%s:</td>\n") // FROM ACCT LABEL
            .append(NEW_EMPTY_LINE) // FROM ACCT VALUE
            .append("</tr>\n")
            .append("<tr><td colspan='2'>&nbsp;</td></tr>\n")
            .append("%s") // OTHERS
            .append("<tr><td colspan='2'>&nbsp;</td></tr>\n")
            .append("</table>\n")
            .append("</div>\n")
            .append("<div id='footer'>\n")
            .append("<p>%s:&nbsp;<strong>%s</strong></p>\n") // NOTE LABEL, NOTE VALUE
            .append("<br/>\n")
            .append("</div>\n")
            .toString();

    private static String receiptImagePath;

    private ReceiptUtils() {}

    @Value("${m2u.payment.receipt-image-path}")
    public synchronized void setReceiptImagePath(String imagePath) {
        receiptImagePath = imagePath;
    }

    public static Map<String, String> getReceiptMap(PayeeDetails payeeDetails, String billAcctNo, String billRefNo, String locale) {
        // TODO: Is it necessary to use LinkedHashMap? Is it because of the sequence ordering? Check further when free
        Map<String, String> receiptMap = new LinkedHashMap<>();
        // TODO: Reference M2UMerchantMakePaymentServices.setCorporationNameBean(), by default it need to be display
        receiptMap.put(M2UApplicationResources.getValue("m1200.corporationName", locale), payeeDetails.getFullName());

        // TODO: billAcctHolderNameBean is not set in DPE process, skip related logic

        // TODO: Reference M2UMerchantMakePaymentServices.setBillAccountNoBean()
        String billAccountNoLabel = (null != payeeDetails.getBillAcctDisplayName()) ? payeeDetails.getBillAcctDisplayName() : M2UApplicationResources.getValue("m1200.billAcctNum", locale);
        receiptMap.put(billAccountNoLabel, billAcctNo);

        // TODO: Reference M2UMerchantMakePaymentServices.setBillReferenceNoBean()
        String billRefNoLabel = (null != payeeDetails.getBillRefDisplayName()) ? payeeDetails.getBillRefDisplayName() : M2UApplicationResources.getValue("m1200.referenceNo", locale);
        receiptMap.put(billRefNoLabel, billRefNo);

        return receiptMap;
    }

    public static String getReceiptParamsString(Map<String, String> receiptMap, String delimiter) {
        StringBuilder strB = new StringBuilder();
        for(Map.Entry<String, String> entry : receiptMap.entrySet()) {
            strB.append(entry.getKey()).append(delimiter).append(entry.getValue()).append(delimiter);
        }
        if(receiptMap.size() > 0) {
            strB.deleteCharAt(strB.lastIndexOf(delimiter));
        }

        return strB.toString();
    }

    public static ByteArrayInputStream generateReceiptPDF(PayeeDetails payeeDetails, String txnType, String billAcctNo, String billRefNo,
        String fromAcctNo, String displayTxnAmt, String note, TransactionStatus status, String locale) throws PaymentException {

        String statusLabel = M2UApplicationResources.getValue("general.status", locale);

        String cssClass = null;
        String displayStatus = null;
        // TODO: We might want to add more option in future
        switch(status) {
            case SUCCESSFUL:
                cssClass = "success";
                displayStatus = M2UApplicationResources.getValue("recpt.general.status.successful", locale);
                break;
            case UNSUCCESSFUL:
                cssClass = "error";
                displayStatus = M2UApplicationResources.getValue("recpt.general.status.unsuccessful", locale);
                break;
            default:
                String errorDetails = String.format("Unsupported status [%s] detected while generate PDF receipt", status);
                log.error(errorDetails);
                throw new PaymentException(PaymentServiceStatus.INTERNAL_SERVER_ERROR, errorDetails);
        }

        String refLabel = M2UApplicationResources.getValue("general.reference.number", locale);
        String txnDateLabel = M2UApplicationResources.getValue("general.transaction.date", locale);
        String displayDate = DateTimeUtils.formatLocalDateTime(LocalDateTime.now(), "dd MMM yyyy");
        String displayTxnAmtLabel = M2UApplicationResources.getValue("general.amount", locale);
        String fromAcctNoLabel = M2UApplicationResources.getValue("general.fromAccount", locale);
        String noteLabel = M2UApplicationResources.getValue("general.note", locale);
        String receiptOthers = getReceiptOthers(payeeDetails, billAcctNo, billRefNo, locale);

        String receiptContent = String.format(PAYMENT_RECEIPT_TEMPLATE,
            txnType, statusLabel, cssClass, displayStatus, refLabel, billRefNo, txnDateLabel, displayDate,
                displayTxnAmtLabel, displayTxnAmt, fromAcctNoLabel, fromAcctNo, receiptOthers, noteLabel, note);
        receiptContent = receiptContent.replaceAll("\"", "'");

        String mibReceipt = M2UApplicationResources.getValue("general.note.mib.receipt", locale);
        String companyNo = new StringBuffer()
            .append("<div>\n")
            .append(" ").append(mibReceipt).append("\n")
            .append("</div>\n").toString();
        companyNo = companyNo.replaceAll("\"", "'");

        try {
            Document document = new Document(PageSize.A4);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            PdfWriter writer = PdfWriter.getInstance(document, outputStream);
            document.open();

            CSSResolver cssResolver = new StyleAttrCSSResolver();
            InputStream cssInputStream = ReceiptUtils.class.getClassLoader().getResourceAsStream("receipt.css");
            CssFile cssFile = XMLWorkerHelper.getCSS(cssInputStream);
            cssResolver.addCss(cssFile);

            HtmlPipelineContext htmlContext = new HtmlPipelineContext(null);
            htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());

            PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
            HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
            CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

            XMLWorker worker = new XMLWorker(css, true);
            XMLParser p = new XMLParser(worker);

            InputStream receiptContentInputStream = new ByteArrayInputStream(receiptContent.getBytes());
            InputStream companyNoInputStream = new ByteArrayInputStream(companyNo.getBytes());

            // TODO: Reference:
            // https://kb.itextpdf.com/home/it5kb/examples/xml-worker-examples
            // https://www.programcreek.com/java-api-examples/?api=com.itextpdf.tool.xml.XMLWorkerHelper

            p.parse(receiptContentInputStream);
            Image receiptImage = Image.getInstance(receiptImagePath);
            receiptImage.scalePercent(70f);
            document.add(receiptImage);
            p.parse(companyNoInputStream);

            document.close();

            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (DocumentException | IOException e) {
            String errorDetails = "Failed to generate PDF receipt";
            log.error(errorDetails, e);
            throw new PaymentException(PaymentServiceStatus.INTERNAL_SERVER_ERROR, errorDetails, e);
        }
    }

    private static String getReceiptOthers(PayeeDetails payeeDetails, String billAcctNo, String billRefNo, String locale) {
        Map<String, String> receiptMap = getReceiptMap(payeeDetails, billAcctNo, billRefNo, locale);

        StringBuilder strB = new StringBuilder();
        for(Map.Entry<String, String> entry : receiptMap.entrySet()) {
            if(null == entry.getKey()) {
                strB.append(String.format("<tr><td colspan=\"2\">%s</td>", entry.getValue()));
            } else {
                strB
                    .append(String.format("<tr><td>%s :</td>", entry.getKey()))
                    .append(String.format("<td>&nbsp;<strong>%s</strong></td></tr>", entry.getValue()))
                    .append("<tr><td colspan='2'>&nbsp;</td></tr>\n");
            }
        }
        return strB.toString();
    }
}
