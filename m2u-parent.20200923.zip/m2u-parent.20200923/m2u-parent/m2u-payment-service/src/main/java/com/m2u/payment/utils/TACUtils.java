package com.m2u.payment.utils;

public class TACUtils {

    private static final String S2U_VERIFICATION_TAC_VALUE = "      ";

    private TACUtils() {}

    public static String getTAC(String s2uType, String tacValue) {
        String finalTACValue = null;
        // 000 - SMS TAC
        // 004 - Host push S2U notification, user approve it from registered app
        // 005 - Secure TAC (User generate S2U tac in APP themselves)
        if("000".equals(s2uType) || "005".equals(s2uType)) {
            finalTACValue = tacValue;
        } else if ("004".equals(s2uType)){
            // TODO: If user choose S2U Verification, TAC value is not required to be set in req, we will fixed it with 6 spaces
            finalTACValue = S2U_VERIFICATION_TAC_VALUE;
        }
        return finalTACValue;
    }
}
