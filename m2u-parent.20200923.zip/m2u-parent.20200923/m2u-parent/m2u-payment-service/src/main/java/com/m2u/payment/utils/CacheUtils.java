package com.m2u.payment.utils;

import com.m2u.payment.exception.CacheException;
import com.m2u.payment.service.M2UCacheService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CacheUtils {

    private static M2UCacheService m2UCacheService;

    @Autowired
    public synchronized void setM2UCacheService(M2UCacheService m2UCacheSvc) {
        m2UCacheService = m2UCacheSvc;
    }

    private CacheUtils() {}

    public static String createCache(String json) throws CacheException {
        try {
            return m2UCacheService.createCache(json);
        } catch(Exception e) {
            String errorDetails = String.format("Failed to create cache with value [%s]. errorMessage [%s]", json, e.getMessage());
            log.error(errorDetails, e);
            throw new CacheException(errorDetails);
        }

    }

    public static String updateCache(String json) throws CacheException {
        try {
            return m2UCacheService.updateCache(json);
        } catch(Exception e) {
            String errorDetails = String.format("Failed to update cache with value [%s]. errorMessage [%s]", json, e.getMessage());
            log.error(errorDetails, e);
            throw new CacheException(errorDetails);
        }
    }

    public static String getCache(String mapName, String key) throws CacheException {
        try {
            return m2UCacheService.getCache(mapName, key);
        } catch(Exception e) {
            String errorDetails = String.format("Failed to get cache with map [%s] key [%s]. errorMessage [%s]", mapName, key, e.getMessage());
            log.error(errorDetails, e);
            throw new CacheException(errorDetails);
        }
    }

//    private static final RestTemplate restTemplate = new RestTemplate();
//    private static final HttpHeaders headers = new HttpHeaders();
//
//    private static String cacheURI;
//    private static String cacheURIWithParams;
//
//    private CacheUtils(
//        @Value("${m2u.cache.connect-timeout: 10000}") int connectTimeout,
//        @Value("${m2u.cache.read-timeout: 10000}") int readTimeout) {
//
//        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
//        factory.setConnectTimeout(connectTimeout);
//        factory.setReadTimeout(readTimeout);
//
//        restTemplate.setRequestFactory(factory);
//        headers.setContentType(MediaType.APPLICATION_JSON);
//    }
//
//    @Value("${m2u.cache.uri}")
//    public synchronized void setCacheURI(String uri) {
//        cacheURI = uri;
//        cacheURIWithParams = new StringBuilder(cacheURI).append("?name={name}&key={key}").toString();
//    }
//
//    public static String createCache(String json) throws CacheException {
//        HttpEntity<String> entity = new HttpEntity<>(json, headers);
//        ResponseEntity<String> respEntity = restTemplate.exchange(cacheURI, HttpMethod.POST, entity, String.class);
//        if(!HttpStatus.OK.equals(respEntity.getStatusCode())) {
//            String errorDetails = String.format("Failed to create cache with value [%s]. Response status [%s] details [%s]",
//                json, respEntity.getStatusCode(), respEntity.getBody());
//            log.error(errorDetails);
//            throw new CacheException(errorDetails);
//        }
//        return respEntity.getBody();
//    }
//
//    public static String updateCache(String json) throws CacheException {
//        HttpEntity<String> entity = new HttpEntity<>(json, headers);
//        ResponseEntity<String> respEntity = restTemplate.exchange(cacheURI, HttpMethod.PUT, entity, String.class);
//        if(!HttpStatus.OK.equals(respEntity.getStatusCode())) {
//            String errorDetails = String.format("Failed to update cache with value [%s]. Response status [%s] details [%s]",
//                json, respEntity.getStatusCode(), respEntity.getBody());
//            log.error(errorDetails);
//            throw new CacheException(errorDetails);
//        }
//        return respEntity.getBody();
//    }
//
//    public static String getCache(String mapName, String key) throws CacheException {
//        Map<String, String> uriVariables = new HashMap<>();
//        uriVariables.put("name", mapName);
//        uriVariables.put("key", key);
//        ResponseEntity<String> respEntity = restTemplate.getForEntity(cacheURIWithParams, String.class, uriVariables);
//        if(!HttpStatus.OK.equals(respEntity.getStatusCode())) {
//            String errorDetails = String.format("Failed to get cache with map [%s] key [%s]. Response status [%s] details [%s]",
//                mapName, key, respEntity.getStatusCode(), respEntity.getBody());
//            log.error(errorDetails);
//            throw new CacheException(errorDetails);
//        }
//        return respEntity.getBody();
//    }
}
