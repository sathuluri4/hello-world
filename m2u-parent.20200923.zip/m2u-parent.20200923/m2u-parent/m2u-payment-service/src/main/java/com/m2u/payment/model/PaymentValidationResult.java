package com.m2u.payment.model;

import lombok.Data;

@Data
public class PaymentValidationResult {

    private Long maxLimit;
    private Double maxAmount;
    private Long maxTxn;
}
