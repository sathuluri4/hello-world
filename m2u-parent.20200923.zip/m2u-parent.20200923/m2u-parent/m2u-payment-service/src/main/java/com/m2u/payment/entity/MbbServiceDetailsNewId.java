package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MbbServiceDetailsNewId implements Serializable {

    @Column(name="OID")
    private Long oid;

    @Column(name="SUB_SERVICE_CODE")
    private String subServiceCode;

    @Column(name="LOCALE")
    private String locale;

    public MbbServiceDetailsNewId() {}

    public MbbServiceDetailsNewId(Long oid, String subServiceCode, String locale) {
        this.oid = oid;
        this.subServiceCode = subServiceCode;
        this.locale = locale;
    }

    public int hashCode() {
        return Objects.hash(this.oid, this.subServiceCode, this.locale);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MbbServiceDetailsNewId)) {
            return false;
        }
        MbbServiceDetailsNewId pk = (MbbServiceDetailsNewId) obj;
        return pk.oid == this.oid
            && pk.subServiceCode.equals(this.subServiceCode)
            && pk.locale.equals(this.locale);
    }
}
