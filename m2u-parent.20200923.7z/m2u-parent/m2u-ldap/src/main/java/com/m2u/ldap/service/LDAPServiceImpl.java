package com.m2u.ldap.service;

import com.m2u.common.utils.StringUtils;
import com.m2u.ldap.exception.LDAPException;
import com.m2u.ldap.model.LDAPUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

@Slf4j
@Service
public class LDAPServiceImpl implements LDAPService {

    @Value("${m2u.ldap.url}")
    private String ldapURL;

    @Value("${m2u.ldap.username}")
    private String ldapUsername;

    @Value("${m2u.ldap.password}")
    private String ldapPassword;

    @Value("${m2u.ldap.ssl}")
    private boolean isSslEnabled;

    public LDAPUser getLDAPUser(String username) throws LDAPException {
        log.debug("Get LDAP User with username [{}]", username);
        DirContext ctx = null;
        try {
            String entryDN = getEntryDN(username);
            // TODO: OUD username/password authentication failed, check with @Junaidi
//            ctx = connectToLDAP(ldapUsername, ldapUsername);
            ctx = connectToLDAP(null, null);
            SearchControls ctls = new SearchControls();
            ctls.setReturningObjFlag(false);
            ctls.setSearchScope(SearchControls.OBJECT_SCOPE);
            String filter = "mbbuserid=".concat(username);
            NamingEnumeration<SearchResult> enumeration = ctx.search(entryDN, filter, ctls);
            SearchResult result = enumeration.next();

            LDAPUser ldapUser = createLDAPUser(result);
            log.debug("Get LDAP User RESP [{}]", ldapUser);
            return ldapUser;
        } catch (NamingException e) {
            String errorDetails = String.format("Failed to get user info from LDAP with username [%s]. Details [%s]", username, e.getMessage());
            log.error(errorDetails, e);
            throw new LDAPException(errorDetails, e);
        } finally {
            if(null != ctx) {
                try {
                    ctx.close();
                } catch (NamingException e) {
                    log.error("Failed to close opened LDAP DirContext", e);
                }
            }
        }
    }

    public LDAPUser authenticateLDAPUser(String username, String password) throws LDAPException {
        log.debug("Authenticate LDAP User with username [{}] password [***]", username);
        DirContext ctx = null;
        try {
            String entryDN = getEntryDN(username);
            // TODO: Validate with username & password from here
            ctx = connectToLDAP(entryDN, password);
            SearchControls ctls = new SearchControls();
            ctls.setReturningObjFlag(false);
            ctls.setSearchScope(SearchControls.OBJECT_SCOPE);
            String filter = "mbbuserid=".concat(username);
            NamingEnumeration<SearchResult> enumeration = ctx.search(entryDN, filter, ctls);
            SearchResult result = enumeration.next();

            LDAPUser ldapUser = createLDAPUser(result);
            log.debug("Authenticated LDAP user RESP [{}]", ldapUser);
            return ldapUser;
        } catch (NamingException e) {
            String errorDetails = String.format("Failed to authenticate LDAP user with username [%s] password [***]. Details [%s]", username, e.getMessage());
            log.error(errorDetails, e);
            throw new LDAPException(e.getMessage(), e);
        } finally {
            if(null != ctx) {
                try {
                    ctx.close();
                } catch (NamingException e) {
                    log.error("Failed to close opened LDAP DirContext", e);
                }
            }
        }
    }

    private DirContext connectToLDAP(String principle, String credentials) throws NamingException {
        // TODO: Somehow LDAP must use HashTable
        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, ldapURL);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");

        if (null != principle) {
            env.put(Context.SECURITY_PRINCIPAL, principle);
        }
        if (null != credentials) {
            env.put(Context.SECURITY_CREDENTIALS, credentials);
        }

        if(isSslEnabled) {
            env.put(Context.SECURITY_PROTOCOL, "TLSv1");
            env.put(Context.REFERRAL, "ignore");
            env.put("java.naming.ldap.factory.socket", "org.apache.directory.api.util.DummySSLSocketFactory");
        }

        return new InitialDirContext(env);
    }

    private static String getEntryDN(String value) {
        return String.format("mbbuserid=%s,ou=People,o=maybank", value);
    }

    private LDAPUser createLDAPUser(SearchResult result) throws NamingException, LDAPException {
        String mbbUserId = result.getAttributes().get("mbbuserid").get().toString();
        String group = null;
        String pan = null;

        NamingEnumeration<?> en = result.getAttributes().get("objectClass").getAll();
        List<String> levels = new ArrayList<>() ;
        while(en.hasMore()) {
            levels.add((String)en.next());
        }

        if(levels.contains("internetbanking")) {
            group = "internetbanking";
            pan = result.getAttributes().get("ibpan2").get().toString();
            if(StringUtils.isEmptyString(pan) || pan.contains(" ")) {
                String errorDetails = String.format("Invalid pan [%s] detected for internetbanking group user [%s]", pan, mbbUserId);
                log.error(errorDetails);
                throw new LDAPException(errorDetails);
            }
        } else if(levels.contains("ibccpublic")) {
            group = "ibccpublic";
            pan = result.getAttributes().get("pancc").get().toString();
            if(StringUtils.isEmptyString(pan) || pan.contains(" ")) {
                String errorDetails = String.format("Invalid pan [%s] detected for ibccpublic group user [%s]", pan, mbbUserId);
                log.error(errorDetails);
                throw new LDAPException(errorDetails);
            }
        } else {
            String errorDetails = String.format("No valid group found for user [%s]. Only [internetbabking/ibccpublic] user group supported", mbbUserId);
            log.error(errorDetails);
            throw new LDAPException(errorDetails);
        }

        LDAPUser ldapUser = new LDAPUser();
        ldapUser.setMbbUserId(mbbUserId);
        ldapUser.setGroup(group);
        ldapUser.setPan(pan);

        return ldapUser;
    }
}
