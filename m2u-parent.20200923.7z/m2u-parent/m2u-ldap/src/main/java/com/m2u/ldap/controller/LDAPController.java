package com.m2u.ldap.controller;

import com.m2u.ldap.model.LDAPUser;
import com.m2u.ldap.service.LDAPService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class LDAPController {

    @Autowired
    private LDAPService ldapService;

    @GetMapping(path = "/v1/users",
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LDAPUser> getLDAPUser(@RequestParam(value = "username") String username) {
        try {
            LDAPUser ldapUser = ldapService.getLDAPUser(username);
            log.debug("LDAPUser [{}] retrieved with username [{}]", ldapUser, username);
            return ResponseEntity.ok(ldapUser);
        } catch (Exception e) {
            log.error("Failed to get LDAP user info with username [{}]", username, e);
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping(path = "/v1/users/authentication",
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LDAPUser> authenticateLDAPUser(
        @RequestParam(value = "username") String username, @RequestParam(value = "password") String password) {

        try {
            LDAPUser ldapUser = ldapService.authenticateLDAPUser(username, password);
            log.debug("LDAPUser [{}] authenticated with username [{}] and password [***]", ldapUser, username);
            return ResponseEntity.ok(ldapUser);
        } catch (Exception e) {
            log.error("Failed to authenticate LDAP user with username [{}] and password [***]", username, e);
            return ResponseEntity.badRequest().build();
        }
    }
}
