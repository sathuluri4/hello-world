package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_PAYEE_LANGUAGE")
@Entity
public class MBBPayeeLanguage implements Serializable {

    @Id
    @Column(name = "OID")
    private Long oid;

    @Column(name = "LOCALE", nullable = false)
    private String locale;

    @Column(name = "FULL_NAME")
    private String fullName;

    @Column(name = "SHORT_NAME")
    private String shortName;

    @Column(name = "BILL_ACCT_DISP_NAME")
    private String billAcctDispName;

    @Column(name = "BILL_ACCT_HOLDER_NAME")
    private String billAcctHolderName;

    @Column(name = "BILL_REF_DISP_NAME")
    private String billRefDispName;

    @Column(name = "SERIAL_NO_NAME")
    private String serialNoName;

    @Column(name = "RECHARGE_CODE_NAME")
    private String rechargeCodeName;

    @Column(name = "NOTE_REQUIRED")
    private String noteRequired;

    @Column(name = "NOTE_REQUIRED2")
    private String noteRequired2;

    @Column(name = "NOTE_REQUIRED3")
    private String noteRequired3;

    @Column(name = "BILL_REF2_DISP_NAME")
    private String billRef2DispName;

    @Column(name = "DOWNTIME_MESSAGE")
    private String downtimeMessage;

    @ManyToOne
    @MapsId("oid")
    @JoinColumn(name="OID")
    private MBBPayeeList mbbPayeeList;
}
