package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class SMSTableId implements Serializable {

    @Column(name = "SMS_CREATESTAMP")
    private LocalDateTime smsCreatestamp;

    @Column(name = "SMS_IBREF_NO")
    private String smsIbrefNo;

    public SMSTableId() {}

    public SMSTableId(LocalDateTime smsCreatestamp, String smsIbrefNo) {
        this.smsCreatestamp = smsCreatestamp;
        this.smsIbrefNo = smsIbrefNo;
    }

    public int hashCode() {
        return Objects.hash(this.smsCreatestamp, this.smsIbrefNo);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof SMSTableId)) {
            return false;
        }
        SMSTableId pk = (SMSTableId) obj;
        return pk.smsCreatestamp.isEqual(this.smsCreatestamp)
            && pk.smsIbrefNo.equals(this.smsIbrefNo);
    }
}
