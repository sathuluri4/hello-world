package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Getter
@Setter
@Table(name="INET_TRANSACTION_LOG")
@Entity
public class INETTransactionLog implements Serializable {

    @EmbeddedId
    private INETTransactionLogId inetTransactionLogId;

    @Column(name = "FROMACCT_ACCTID")
    private String fromacctAcctid;

    @Column(name = "TOACCT_ACCTID")
    private String toacctAcctid;

    @Column(name = "TRANSACTION_AMT")
    private double transactionAmt;

    @Column(name = "DETAILS")
    private String details;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "BILL_ACCTID")
    private String billAcctid;

    @Column(name = "BILL_REF_ID")
    private String billRefId;

    @Column(name = "EFFECTIVE_DATE")
    private String effectiveDate;

    @Column(name = "IP_ADDRESS")
    private String ipAddress;

    @Column(name = "APPROVAL_CODE")
    private String approvalCode;

    @Column(name = "TRANSACTION_DETAILS")
    private String transactionDetails;
}
