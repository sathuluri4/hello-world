package com.m2u.payment.dto;

import lombok.Data;

@Data
public abstract class AbstractRequestDTO {

    private String headerAccept;
    private String headerAcceptCharset;
    private String headerAcceptEncoding;
    private String headerAcceptLanguage;
    private String headerUserAgent;

    private String sessionId;
    private String token;
    private String engineId;
    private String language;
    private String locale;
    private String countryCode;
    private String channel;
    private String devicePrint;
    private String remoteAddress;
    private String serverName;

    private String deviceTokenCookie;
    private String deviceTokenFSO;
}
