package com.m2u.payment.repository;

import com.m2u.payment.entity.INETTransactionLog;
import com.m2u.payment.entity.INETTransactionLogId;
import org.springframework.data.repository.CrudRepository;

public interface INETTransactionLogRepository extends CrudRepository<INETTransactionLog, INETTransactionLogId> {
}
