package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Table(name="MBB_SECURITY")
@Entity
public class MBBSecurity implements Serializable {

    @EmbeddedId
    private MBBSecurityId mbbSecurityId;

    @Column(name = "SESSION_ID", nullable = false)
    private String sessionId;

    @Column(name = "LOGIN_DATETIME", nullable = false)
    private LocalDateTime loginDatetime;

    @Column(name = "IP_ADDRESS")
    private String ipAddress;

    @Column(name = "LANG_CHOICE")
    private String langChoice;

    @ManyToOne
    @MapsId("userId")
    @JoinColumn(name="USER_ID")
    private BVUser bvUser;
}
