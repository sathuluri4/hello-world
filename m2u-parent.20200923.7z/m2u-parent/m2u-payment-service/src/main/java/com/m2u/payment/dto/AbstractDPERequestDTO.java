package com.m2u.payment.dto;

import lombok.Data;

@Data
public abstract class AbstractDPERequestDTO extends AbstractRequestDTO {

    private String referrer;
    // TODO: This is to control the flow in certain controller
    private String action;
    // TODO: This is mainly control values set to dom, js and page id
    private String formAction;
    private String domElements;
    private String jsEvents;
    private String pageId;

    private Integer timeForTheme;
}
