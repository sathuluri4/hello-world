package com.m2u.payment.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.m2u.payment.enums.PaymentServiceStatus;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString(callSuper = true)
@Data
public class TxnConfirmationResponseDTO extends AbstractResponseDTO {

    private String title;
    private List<Object> dynamicFields;
    private List<Map<String, Object>> secureTypes;
    private Boolean isTACRequired;
    private String otpURL;

    public TxnConfirmationResponseDTO() {}

    public TxnConfirmationResponseDTO(String sessionId, String token, String engineId, PaymentServiceStatus status) {
        super(sessionId, token, engineId, status.getStatusCode(), status.getStatusMessage());
    }

    public TxnConfirmationResponseDTO(String sessionId, String token, String engineId, String statusCode, String statusMessage) {
        super(sessionId, token, engineId, statusCode, statusMessage);
    }
}
