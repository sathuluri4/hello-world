package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_ADAPT")
@Entity
public class MBBAdapt implements Serializable {

    @Id
    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "MBB_ADAPT_IMAGE_URL", nullable = false)
    private String mbbAdaptImageUrl;

    @Column(name = "MBB_ADAPT_IMAGE_CAPTION")
    private String mbbAdaptImageCaption;

    @Column(name = "MBB_THEME")
    private String mbbTheme;

    @ManyToOne
    @MapsId("userId")
    @JoinColumn(name="USER_ID")
    private BVUser bvUser;
}
