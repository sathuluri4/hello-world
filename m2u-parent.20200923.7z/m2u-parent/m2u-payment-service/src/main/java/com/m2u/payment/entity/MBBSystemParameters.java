package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Table(name="MBB_SYSTEM_PARAMETERS")
@Entity
public class MBBSystemParameters implements Serializable {

    @Id
    @Column(name = "OID")
    private Long oid;

    @Column(name = "MBB_PARAMETER", nullable = false)
    private String mbbParameter;

    @Column(name = "STORE_ID", nullable = false)
    private Long storeId;

    @Column(name = "CREATION_TIME", nullable = false)
    private LocalDateTime creationTime;

    @Column(name = "STATUS", nullable = false)
    private Long status;

    @Column(name = "DELETED", nullable = false)
    private Long deleted;

    @Column(name = "LAST_MOD_TIME", nullable = false)
    private LocalDateTime lastModTime;

    @Column(name = "MBB_PARAMETER_VALUE", nullable = false)
    private String mbbParameterValue;

    @Column(name = "MBB_PARAMETER_DESCRIPTION")
    private String mbbParameterDescription;
}
