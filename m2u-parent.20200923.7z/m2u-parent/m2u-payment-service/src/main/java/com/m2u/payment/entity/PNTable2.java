package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Getter
@Setter
@Table(name="PN_TABLE2")
@Entity
public class PNTable2 implements Serializable {

    @Id
    @Column(name = "PN_MAYBANK_REFNO")
    private String pnMaybankRefno;

    @Column(name = "PN_PRIORITY")
    private Integer pnPriority;

    @Column(name = "PN_PAYEE_IP")
    private String pnPayeeIp;

    @Column(name = "PN_PAYEE_CODE")
    private String pnPayeeCode;

    @Column(name = "PN_KEY")
    private String pnKey;

    @Column(name = "PN_BILL_AC_NO")
    private String pnBillAcNo;

    @Column(name = "PN_BILL_REF_NO")
    private String pnBillRefNo;

    @Column(name = "PN_TRN_DATE")
    private String pnTrnDate;

    @Column(name = "PN_TRN_TIME")
    private String pnTrnTime;

    @Column(name = "PN_AMOUNT")
    private String pnAmount;

    @Column(name = "PN_STATUS")
    private String pnStatus;

    @Column(name = "PN_DBCR")
    private String pnDbcr;

    @Column(name = "PN_EMAIL1")
    private String pnEmail1;

    @Column(name = "PN_EMAIL2")
    private String pnEmail2;

    @Column(name = "PN_SENDTIME")
    private String pnSendtime;
}
