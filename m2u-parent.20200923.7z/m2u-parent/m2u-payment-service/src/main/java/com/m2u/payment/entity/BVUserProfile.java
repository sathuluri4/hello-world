package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Table(name = "BV_USER_PROFILE")
@Entity
public class BVUserProfile implements Serializable {

    @Id
    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "NAME")
    private String name;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "CITY")
    private String city;

    @Column(name = "STATE")
    private String state;

    @Column(name = "ZIP")
    private String zip;

    @Column(name = "COUNTRY")
    private String country;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "AGE_RANGE")
    private Long ageRange;

    @Column(name = "GENDER")
    private Long gender;

    @Column(name = "INCOME_RANGE")
    private Long incomeRange;

    @Column(name = "NO_HOUSEHOLD")
    private Long noHousehold;

    @Column(name = "MARITAL_STATUS")
    private Long maritalStatus;

    @Column(name = "EMPLOY_STATUS")
    private Long employStatus;

    @Column(name = "OCCUPATION")
    private Long occupation;

    @Column(name = "EDUCATION_LEVEL")
    private Long educationLevel;

    @Column(name = "BUS_PHONE")
    private String busPhone;

    @Column(name = "HOME_PHONE")
    private String homePhone;

    @Column(name = "WANT_MESSAGE")
    private Long wantMessage;

    @Column(name = "INVALID_EMAIL")
    private Long invalidEmail;

    @Column(name = "LAST_LOGIN_DATE")
    private LocalDateTime lastLoginDate;

    @Column(name = "AVG_LOGIN_DAYS")
    private Double avgLoginDays;

    @Column(name = "NUMBER_LOGIN")
    private Long numberLogin;

    @Column(name = "LAST_MOD_TIME")
    private LocalDateTime lastModTime;

    @Column(name = "FN_CUST_ACCT_ID")
    private String fnCustAcctId;

    @Column(name = "FN_CUSTOMER")
    private Long fnCustomer;

    @Column(name = "FN_RESIDENCE")
    private Long fnResidence;

    @Column(name = "FN_STUD_LOAN")
    private Long fnStudLoan;

    @Column(name = "FN_CAR_LOAN")
    private Long fnCarLoan;

    @Column(name = "FN_MORTGAGE")
    private Long fnMortgage;

    @Column(name = "FN_PERS_LOAN")
    private Long fnPersLoan;

    @Column(name = "FN_CONS")
    private Long fnCons;

    @Column(name = "FN_C_CARDS")
    private Long fnCCards;

    @Column(name = "FN_INVEST")
    private Long fnInvest;

    @Column(name = "FN_RETIRE")
    private Long fnRetire;

    @Column(name = "FN_FI_PLAN_AS")
    private Long fnFiPlanAs;

    @Column(name = "FN_FI_PLAN_SW")
    private Long fnFiPlanSw;

    @Column(name = "FN_BASIC_PROD")
    private Long fnBasicProd;

    @Column(name = "FN_ASSETS")
    private Long fnAssets;

    @Column(name = "FN_CR_RATE")
    private Long fnCrRate;

    @Column(name = "FN_CUST_VAL")
    private Long fnCustVal;

    @Column(name = "FN_ACT_DISP_ORD")
    private Long fnActDispOrd;

    @Column(name = "FN_PMT_DISP_ORD")
    private Long fnPmtDispOrd;

    @Column(name = "FN_DOWNLOAD_FMT")
    private String fnDownloadFmt;

    @Column(name = "FN_LAST_DOWNLOAD")
    private LocalDateTime fnLastDownload;

    @Column(name = "FN_BILLPAY_WARN")
    private Long fnBillpayWarn;

    @Column(name = "FN_NEWS_PREF")
    private Long fnNewsPref;

    @Column(name = "FN_DISP_TICKER")
    private Long fnDispTicker;

    @Column(name = "MBB_CUSTOMER_NAME")
    private String mbbCustomerName;

    @Column(name = "MBB_CUSTOMER_TYPE")
    private String mbbCustomerType;

    @Column(name = "MBB_CUSTOMER_IC_BUSREG")
    private String mbbCustomerIcBusreg;

    @Column(name = "MBB_CUSTOMER_DOB")
    private String mbbCustomerDob;

    @Column(name = "MBB_COMPANY_NAME")
    private String mbbCompanyName;

    @Column(name = "MBB_COMPANY_DOI")
    private String mbbCompanyDoi;

    @Column(name = "MBB_COMPANY_REGNO")
    private String mbbCompanyRegno;

    @Column(name = "MBB_COMPANY_ADDR1")
    private String mbbCompanyAddr1;

    @Column(name = "MBB_COMPANY_ADDR2")
    private String mbbCompanyAddr2;

    @Column(name = "MBB_COMPANY_ADDR3")
    private String mbbCompanyAddr3;

    @Column(name = "MBB_COMPANY_ADDR4")
    private String mbbCompanyAddr4;

    @Column(name = "MBB_COMPANY_ADDR5")
    private String mbbCompanyAddr5;

    @Column(name = "MBB_COMPANY_PHONE")
    private String mbbCompanyPhone;

    @Column(name = "MBB_BUS_TYPE")
    private Long mbbBusType;

    @Column(name = "MBB_NO_OF_EMPLOYEES")
    private Long mbbNoOfEmployees;

    @Column(name = "MBB_ANNUAL_TURNOVER")
    private Long mbbAnnualTurnover;

    @Column(name = "MBB_CFI_INVESTMENT")
    private Long mbbCfiInvestment;

    @Column(name = "MBB_CFI_FINANCE")
    private Long mbbCfiFinance;

    @Column(name = "MBB_CFI_CREDITCARD")
    private Long mbbCfiCreditcard;

    @Column(name = "MBB_CFI_ESERVICE")
    private Long mbbCfiEservice;

    @Column(name = "MBB_CFI_INSURANCE")
    private Long mbbCfiInsurance;

    @Column(name = "MBB_CFI_IPRODUCT")
    private Long mbbCfiIproduct;

    @Column(name = "MBB_COMNEWS_FEXCHANGE")
    private Long mbbComnewsFexchange;

    @Column(name = "MBB_COMNEWS_WNEWS")
    private Long mbbComnewsWnews;

    @Column(name = "MBB_COMNEWS_UTRUST")
    private Long mbbComnewsUtrust;

    @Column(name = "MBB_COMNEWS_INSTRUMENT")
    private Long mbbComnewsInstrument;

    @Column(name = "MBB_COMNEWS_KLSE")
    private Long mbbComnewsKlse;

    @Column(name = "MBB_COMNEWS_SMARKET")
    private Long mbbComnewsSmarket;

    @Column(name = "MBB_SALUTATION")
    private String mbbSalutation;

    @Column(name = "MBB_OLD_IC")
    private String mbbOldIc;

    @Column(name = "MBB_RACE")
    private String mbbRace;

    @Column(name = "MBB_GENDER")
    private String mbbGender;

    @Column(name = "MBB_ADDR_LINE1")
    private String mbbAddrLine1;

    @Column(name = "MBB_ADDR_LINE2")
    private String mbbAddrLine2;

    @Column(name = "MBB_ADDR_LINE3")
    private String mbbAddrLine3;

    @Column(name = "MBB_ADDR_LINE4")
    private String mbbAddrLine4;

    @Column(name = "MBB_ADDR_LINE5")
    private String mbbAddrLine5;

    @Column(name = "MBB_CONTACT_HOME")
    private String mbbContactHome;

    @Column(name = "MBB_CONTACT_OFFICE")
    private String mbbContactOffice;

    @Column(name = "MBB_CONTACT_MOBILE1")
    private String mbbContactMobile1;

    @Column(name = "MBB_CONTACT_MOBILE2")
    private String mbbContactMobile2;

    @Column(name = "MBB_CONTACT_FAX")
    private String mbbContactFax;

    @Column(name = "MBB_OFFICE_ADDR_LINE1")
    private String mbbOfficeAddrLine1;

    @Column(name = "MBB_OFFICE_ADDR_LINE2")
    private String mbbOfficeAddrLine2;

    @Column(name = "MBB_WEDDING_ANV")
    private String mbbWeddingAnv;

    @Column(name = "MBB_DEPENDENTS")
    private Long mbbDependents;

    // TODO: Column name mistake
    @Column(name = "MBB_DISPALY_NAME")
    private String mbbDisplayName;

    @Column(name = "MBB_OCCUPATION")
    private Long mbbOccupation;

    @Column(name = "MBB_ANNUAL_INCOME")
    private Long mbbAnnualIncome;

    @Column(name = "MBB_HHOLD_INCOME")
    private Long mbbHholdIncome;

    @Column(name = "MBB_MARITAL_STATUS")
    private String mbbMaritalStatus;

    @Column(name = "MBB_NO_OF_CHILDREN")
    private Long mbbNoOfChildren;

    @Column(name = "MBB_EMAIL_ID")
    private String mbbEmailId;

    @Column(name = "MBB_LANG_SPEAK")
    private String mbbLangSpeak;

    @Column(name = "MBB_INTEREST_MVEHICLE")
    private Long mbbInterestMvehicle;

    @Column(name = "MBB_INTEREST_FASHION")
    private Long mbbInterestFashion;

    @Column(name = "MBB_INTEREST_HDECORATION")
    private Long mbbInterestHdecoration;

    @Column(name = "MBB_INTEREST_COMPUTERS")
    private Long mbbInterestComputers;

    @Column(name = "MBB_INTEREST_ACOLLECTION")
    private Long mbbInterestAcollection;

    @Column(name = "MBB_INTEREST_FDINING")
    private Long mbbInterestFdining;

    @Column(name = "MBB_INTEREST_HEALTH")
    private Long mbbInterestHealth;

    @Column(name = "MBB_INTEREST_SPORTS")
    private Long mbbInterestSports;

    @Column(name = "MBB_INTEREST_TRAVEL")
    private Long mbbInterestTravel;

    @Column(name = "MBB_INTEREST_CMEMB")
    private Long mbbInterestCmemb;

    @Column(name = "MBB_INTEREST_THEATRE")
    private Long mbbInterestTheatre;

    @Column(name = "MBB_INTEREST_OUTDOOR")
    private Long mbbInterestOutdoor;

    @Column(name = "MBB_FINT_INVESTMENT")
    private Long mbbFintInvestment;

    @Column(name = "MBB_FINT_PFINANCE")
    private Long mbbFintPfinance;

    @Column(name = "MBB_FINT_CREDITCARD")
    private Long mbbFintCreditcard;

    @Column(name = "MBB_FINT_INSURANCE")
    private Long mbbFintInsurance;

    @Column(name = "MBB_FINT_STFINANCING")
    private Long mbbFintStfinancing;

    @Column(name = "MBB_FINT_IPRODUCTS")
    private Long mbbFintIproducts;

    @Column(name = "MBB_NEWS_MALAYSIA")
    private Long mbbNewsMalaysia;

    @Column(name = "MBB_MALAYSIA_SPORTS")
    private Long mbbMalaysiaSports;

    @Column(name = "MBB_NEWS_SINGAPORE")
    private Long mbbNewsSingapore;

    @Column(name = "MBB_WORLD_POLITIC")
    private Long mbbWorldPolitic;

    @Column(name = "MBB_HUMAN_INTEREST")
    private Long mbbHumanInterest;

    @Column(name = "MBB_KLSE")
    private Long mbbKlse;

    @Column(name = "MBB_EQUITY_NEWS")
    private Long mbbEquityNews;

    @Column(name = "MBB_ECONOMIC")
    private Long mbbEconomic;

    @Column(name = "MBB_OTH_STOCKREPORT")
    private Long mbbOthStockreport;

    @Column(name = "MBB_PUBLIC_STATUS")
    private String mbbPublicStatus;

    @Column(name = "MBB_TSTAMP")
    private Long mbbTstamp;

    @Column(name = "MBB_FORGET_PW_ATTEMPT")
    private Long mbbForgetPwAttempt;

    @Column(name = "MBB_INSTITUTION_ID")
    private String mbbInstitutionId;

    @Column(name = "BV_SESSION_ID")
    private String bvSessionId;

    @Column(name = "DA_FLAG")
    private Long daFlag;

    @Column(name = "MBB_MOBILE_PUSHREG_FLAG", nullable = false)
    private String mbbMobilePushregFlag;

    @Column(name = "HIDE_ALLBALANCES")
    private String hideAllbalances;

    @OneToOne
    @MapsId("userId")
    @JoinColumn(name="USER_ID")
    private BVUser bvUser;
}
