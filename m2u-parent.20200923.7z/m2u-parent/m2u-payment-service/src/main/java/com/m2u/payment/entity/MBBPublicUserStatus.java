package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Table(name="MBB_SECURITY")
@Entity
public class MBBPublicUserStatus implements Serializable {

    @EmbeddedId
    private MBBPublicUserStatusId mbbPublicUserStatusId;

    @Column(name = "ACTION_DATE", nullable = false)
    private LocalDateTime actionDate;

    @Column(name = "ACTIVITY")
    private String activity;

    @Column(name = "REASON_CODE_ID")
    private String reasonCodeId;

    @Column(name = "ADMIN_USERNAME")
    private String adminUsername;

    @ManyToOne
    @MapsId("userId")
    @JoinColumn(name="USER_ID")
    private BVUser bvUser;
}
