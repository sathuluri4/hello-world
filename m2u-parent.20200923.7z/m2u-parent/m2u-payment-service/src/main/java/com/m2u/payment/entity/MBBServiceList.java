package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Table(name="MBB_SERVICE_LIST")
@Entity
public class MBBServiceList implements Serializable {

    @Id
    @Column(name="OID", nullable = false)
    private Long oid;

    @Column(name="SERVICE_CODE", nullable = false)
    private String serviceCode;

    @Column(name="STORE_ID", nullable = false)
    private Long storeId;

    @Column(name="CREATION_TIME", nullable = false)
    private LocalDateTime creationTime;

    @Column(name="STATUS", nullable = false)
    private Long status;

    @Column(name="DELETED", nullable = false)
    private Long deleted;

    @Column(name="LAST_MOD_TIME", nullable = false)
    private LocalDateTime lastModDate;

    @Column(name="SERVICE_NAME", nullable = false)
    private String serviceName;

    @Column(name="MAIN_NOTE1")
    private String mainNote1;

    @Column(name="MAIN_NOTE2")
    private String mainNote2;

    @Column(name="MAIN_NOTE3")
    private String mainNote3;

    @Column(name="MAIN_NOTE4")
    private String mainNote4;

    @Column(name="MAIN_NOTE5")
    private String mainNote5;

    @Column(name="SMS_SERVICE", nullable = false)
    private Long smsService;

    @Column(name="MINIMUM_SMS_AMOUNT")
    private Long minimumSmsAmount;

    @Column(name="TRANS_LIMIT_BIT")
    private Long transLimitBit;

    @OneToMany(mappedBy = "mbbServiceList", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<MBBServiceLanguage> mbbServiceLanguageList;

    @OneToMany(mappedBy = "mbbServiceList", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<MBBServiceDetails> mbbServiceDetailsList;

    @OneToMany(mappedBy = "mbbServiceList", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<MBBServiceDetailsNew> mbbServiceDetailsNewList;
}
