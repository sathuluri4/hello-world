package com.m2u.payment.controller;

import com.m2u.common.utils.StringUtils;
import com.m2u.payment.cache.DPECache;
import com.m2u.payment.constants.PaymentServiceConstant;
import com.m2u.payment.dto.AbstractRequestDTO;
import com.m2u.payment.exception.CacheException;
import com.m2u.payment.exception.PaymentException;
import com.m2u.payment.utils.CacheUtils;
import com.m2u.payment.utils.PaymentServiceUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.UnknownHostException;

@Slf4j
@Component
public abstract class AbstractController {

    protected static final String SLF4J_REQ_TEMPLATE = "REQ [{}]";
    protected static final String SLF4J_RESP_TEMPLATE = "RESP [{}]";
    protected static final String UNEXPECTED_EXCEPTION_OCCURRED = "Unexpected exception occurred";

    // TODO: Temporary solution, think a way how to create unique ID per SpringBoot instance
    @Value("${m2u.payment.engine-id}")
    private String engineId;

    protected <T extends AbstractRequestDTO> void init(HttpServletRequest req, T t) throws UnknownHostException {
        t.setHeaderAccept(req.getHeader(HttpHeaders.ACCEPT));
        t.setHeaderAcceptCharset(req.getHeader(HttpHeaders.ACCEPT_CHARSET));
        t.setHeaderAcceptEncoding(req.getHeader(HttpHeaders.ACCEPT_ENCODING));
        t.setHeaderAcceptLanguage(req.getHeader(HttpHeaders.ACCEPT_LANGUAGE));
        t.setHeaderUserAgent(req.getHeader(HttpHeaders.USER_AGENT));

        // TODO: Reference M2UControllerAction.retrieveBVRequestEnvProperties()
        // TODO: Check to see does it work in proper UIUX environment, e.g. from WEB/Mobile
        String xfHeader = req.getHeader("X-Forwarded-For");
        if (StringUtils.isEmptyString(xfHeader)) {
            t.setRemoteAddress(req.getRemoteAddr());
        } else {
            t.setRemoteAddress(xfHeader.split(",")[0]);
        }

        t.setServerName(InetAddress.getLocalHost().getHostName());
        t.setEngineId(engineId);
    }

    protected String getLastToken(String sessionId) {
        try {
            String json = CacheUtils.getCache(PaymentServiceConstant.PAYMENT_MAP_NAME, sessionId);
            if(StringUtils.isEmptyString(json)) {
                String errorDetails = String.format("Failed to get cache from cache map [%s] using key [%s]", PaymentServiceConstant.PAYMENT_MAP_NAME, sessionId);
                log.warn(errorDetails);
                return null;
            }
            DPECache cache = PaymentServiceUtils.convertJSONToObject(DPECache.class, json);
            return cache.getToken();
        } catch (PaymentException | CacheException e) {
            String errorDetails = String.format("Failed to get cache from cache map [%s] using key [%s]", PaymentServiceConstant.PAYMENT_MAP_NAME, sessionId);
            log.error(errorDetails, e);
            return null;
        }
    }
}
