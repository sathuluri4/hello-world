package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_PRODUCT_INFO")
@Entity
public class MBBProductInfo implements Serializable {

    @EmbeddedId
    private MBBProductInfoId mbbProductInfoId;

    @Column(name = "CC_DISPLAY_NAME")
    private String ccDisplayName;

    @ManyToOne
    @MapsId("oid")
    @JoinColumn(name="OID")
    private MBBProductList mbbProductList;
}
