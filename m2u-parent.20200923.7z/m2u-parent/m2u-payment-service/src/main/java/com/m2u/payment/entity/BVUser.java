package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Table(name="BV_USER")
@Entity
public class BVUser implements Serializable {

    @Id
    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "ACCOUNT_ID")
    private Long accountId;

    @Column(name = "USER_ALIAS")
    private String userAlias;

    @Column(name = "PASSWORD")
    private String password;

    @Column(name = "PMT_PREFERENCE")
    private String pmtPreference;

    @Column(name = "USER_STATE")
    private Long userState;

    @Column(name = "MODIF_TIME")
    private LocalDateTime modifyTime;

    @OneToOne(mappedBy = "bvUser", cascade = CascadeType.ALL, orphanRemoval = true)
    private BVUserProfile bvUserProfile;

    @OneToMany(mappedBy = "bvUser", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<MBBSecurity> mbbSecurityList;

    @OneToOne(mappedBy = "bvUser", cascade = CascadeType.ALL, orphanRemoval = true)
    private MBBAdapt mbbAdapt;

    @OneToMany(mappedBy = "bvUser", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<MBBPublicUserStatus> mbbPublicUserStatusList;

    @OneToMany(mappedBy = "bvUser", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<MBBCCDetails> mbbCCDetailsList;
}
