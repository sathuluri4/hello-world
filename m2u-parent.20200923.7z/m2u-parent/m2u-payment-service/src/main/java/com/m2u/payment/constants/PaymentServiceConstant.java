package com.m2u.payment.constants;

public final class PaymentServiceConstant {

    private PaymentServiceConstant() {}

    public static final String PAYMENT_MAP_NAME = "PAYMENT";
    public static final String PAYMENT_CACHE_TEMPLATE = "{\"name\":\"PAYMENT\",\"key\":\"%s\",\"value\":%s}";

    public static final String DEFAULT_LOCALE = "en";

    public static final String CURRENT_ACCOUNT = "D";
    public static final String SAVING_ACCOUNT = "S";
    public static final String FOREIGN_CURRENCY_ACCOUNT = "E";
    public static final String GOLD_SAVING_ACCOUNT = "G";

    public static final String CREDIT_CARD = "C";
    public static final String DEBIT_CARD = "Z";
    public static final String PREPAID_CCARD = "J";
    public static final String CHARGE_CARD = "R";

    public static final String LOAN = "L";
    public static final String PERSONAL_LOAN = "N";
    public static final String HIRE_PURCHASE = "H";

    public static final String FIX_DEPOSIT = "T";
    public static final String UNIT_TRUST = "F";
    public static final String PRODUCT_INDICATOR = "PR";

    public static final String CARD_DIGIT_FORMAT_15 ="xxx-xxxx-xxxx-";
    public static final String CARD_DIGIT_FORMAT_16 ="xxxx-xxxx-xxxx-";

    public static final String AVAILABLE_BALANCE = "02";
    public static final String OUTSTANDING_BALANCE = "08";
}
