package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Table(name="SMS_TABLE")
@Entity
public class SMSTable implements Serializable {

    @EmbeddedId
    private SMSTableId smsTableId;

    @Column(name = "SMS_IC_NO")
    private String smsIcNo;

    @Column(name = "SMS_CUST_NAME")
    private String smsCustName;

    @Column(name = "SMS_HP_NO")
    private String smsHpNo;

    @Column(name = "SMS_MESSAGE")
    private String smsMessage;

    @Column(name = "SMS_SERVICE")
    private String smsService;

    @Column(name = "SMS_STATUS")
    private String smsStatus;

    @Column(name = "SMS_GUID")
    private String smsGuid;

    @Column(name = "SMS_SDDATESTAMP")
    private LocalDateTime smsSddatestamp;

    @Column(name = "SMS_RCDATESTAMP")
    private LocalDateTime smsRcdatestamp;

    @Column(name = "SMS_CHECK")
    private String smsCheck;

    @Column(name = "SMS_PRIORITY")
    private String smsPriotity;

    @Column(name = "SMS_GATEWAY")
    private String smsGateway;
}
