package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Getter
@Setter
@Table(name="INET_RECEIPT_DETAILS")
@Entity
public class INETReceiptDetails implements Serializable {

    @EmbeddedId
    private INETReceiptDetailsId inetTransactionLogId;

    @Column(name = "DETAILS")
    private String details;
}
