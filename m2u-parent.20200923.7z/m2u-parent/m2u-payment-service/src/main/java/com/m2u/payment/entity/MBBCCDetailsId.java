package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MBBCCDetailsId implements Serializable {

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "CREDIT_CARD_NUM")
    private String creditCardNum;

    public MBBCCDetailsId() {}

    public MBBCCDetailsId(Long userId, String creditCardNum) {
        this.userId = userId;
        this.creditCardNum = creditCardNum;
    }

    public int hashCode() {
        return Objects.hash(this.userId, this.creditCardNum);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MBBCCDetailsId)) {
            return false;
        }
        MBBCCDetailsId pk = (MBBCCDetailsId) obj;
        return pk.userId == this.userId
            && pk.creditCardNum.equals(this.creditCardNum);
    }
}
