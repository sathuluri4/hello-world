package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class MBBPayeeProductListId implements Serializable {

    @Column(name = "OID")
    private Long oid;

    @Column(name = "PRODUCT_CODE")
    private String productCode;

    public MBBPayeeProductListId() {}

    public MBBPayeeProductListId(Long oid, String productCode) {
        this.oid = oid;
        this.productCode = productCode;
    }

    public int hashCode() {
        return Objects.hash(this.oid, this.productCode);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MBBPayeeProductListId)) {
            return false;
        }
        MBBPayeeProductListId pk = (MBBPayeeProductListId) obj;
        return pk.oid == this.oid
            && pk.productCode.equals(this.productCode);
    }
}
