package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Getter
@Setter
@Table(name = "INET_DEBIT_CONTROL_PARAMETERS")
@Entity
public class INETDebitControlParameters implements Serializable {

    @Id
    @Column(name = "PAYEE_CODE")
    private String payeeCode;

    @Column(name = "NUMBER_OF_DAYS")
    private Long numberOfDays;

    @Column(name = "MAX_TRANSACTION")
    private Long maxTransaction;

    @Column(name = "MAX_AMOUNT")
    private Double maxAmount;

    @Column(name = "MBB_TSTAMP", nullable = false)
    private Long mbbTstamp;

    @Column(name = "CHANNEL_ID")
    private String channelId;
}
