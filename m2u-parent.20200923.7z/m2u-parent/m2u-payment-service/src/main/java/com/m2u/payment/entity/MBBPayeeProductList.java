package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Table(name="MBB_PAYEE_PRODUCT_LIST")
@Entity
public class MBBPayeeProductList implements Serializable {

    @EmbeddedId
    private MBBPayeeProductListId mbbPayeeProductListId;

    @Column(name = "ACCOUNT_TYPE")
    private String accountType;

    @ManyToOne
    @MapsId("oid")
    @JoinColumn(name="OID")
    private MBBPayeeList mbbPayeeList;
}
