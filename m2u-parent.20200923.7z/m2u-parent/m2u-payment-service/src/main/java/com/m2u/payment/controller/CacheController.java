package com.m2u.payment.controller;

import com.m2u.payment.dto.ResetM2UCacheRequestDTO;
import com.m2u.payment.dto.ResetM2UCacheResponseDTO;
import com.m2u.payment.enums.PaymentServiceStatus;
import com.m2u.payment.exception.PaymentException;
import com.m2u.payment.service.CacheService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@RestController
public class CacheController extends AbstractController {

    // TODO: Temporary solution, think a way how to create unique ID per SpringBoot instance
    @Value("${m2u.payment.engine-id}")
    private String engineId;

    @Autowired
    private CacheService CacheService;

    @DeleteMapping(path = "/v1/caches/{target}",
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResetM2UCacheResponseDTO> resetM2UCache(HttpServletRequest httpReq, @RequestBody ResetM2UCacheRequestDTO req, @PathVariable String target) {
        try {
            log.debug(SLF4J_REQ_TEMPLATE.concat(". target [{}]"), req, target);
            init(httpReq, req);
            ResetM2UCacheResponseDTO resp = CacheService.resetM2UCache(req, target);
            resp.setStatusCode(PaymentServiceStatus.SUCCESS.getStatusCode());
            log.debug(SLF4J_RESP_TEMPLATE.concat(". target [{}]"), resp, target);
            return ResponseEntity.ok(resp);
        } catch (PaymentException e) {
            ResetM2UCacheResponseDTO resp = new ResetM2UCacheResponseDTO(req.getSessionId(), null, engineId, e.getStatus().getStatusCode(), e.getMessage());
            log.debug(SLF4J_RESP_TEMPLATE.concat(". target [{}]"), resp, target);
            return new ResponseEntity<>(resp, e.getStatus().getHttpStatus());
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION_OCCURRED, e);
            ResetM2UCacheResponseDTO resp = new ResetM2UCacheResponseDTO(req.getSessionId(), null, engineId, PaymentServiceStatus.UNEXPECTED_EXCEPTION);
            log.debug(SLF4J_RESP_TEMPLATE.concat(". target [{}]"), resp, target);
            return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
