package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Table(name="MBB_PAYEE_LIST")
@Entity
public class MBBPayeeList implements Serializable {

    @Id
    @Column(name = "OID")
    private Long oid;

    @Column(name = "PAYEE_CODE", nullable = false)
    private String payeeCode;

    @Column(name = "STORE_ID", nullable = false)
    private Long storeId;

    @Column(name = "CREATION_TIME", nullable = false)
    private LocalDateTime creationTime;

    @Column(name = "STATUS", nullable = false)
    private Long status;

    @Column(name = "DELETED", nullable = false)
    private Long deleted;

    @Column(name = "LAST_MOD_TIME", nullable = false)
    private LocalDateTime lastModTime;

    @Column(name = "FULL_NAME", nullable = false)
    private String fullName;

    @Column(name = "SHORT_NAME")
    private String shortName;

    @Column(name = "ONLINE_PAYMENT", nullable = false)
    private Long onlinePayment;

    @Column(name = "BILL_ACCT_REQUIRED", nullable = false)
    private Long billAcctRequired;

    @Column(name = "BILL_ACCT_DISP_NAME_REQUIRED")
    private Long billAcctDispNameRequired;

    @Column(name = "BILL_ACCT_DISP_NAME")
    private String billAcctDispName;

    @Column(name = "BILL_ACCT_HOLDER_DISP_NAME_REQ")
    private Long billAcctHolderDispNameReq;

    @Column(name = "BILL_ACCT_HOLDER_NAME")
    private String billAcctHolderName;

    @Column(name = "BILL_REF_REQUIRED", nullable = false)
    private Long billRefRequired;

    @Column(name = "BILL_REF_DISP_NAME_REQUIRED")
    private Long billRefDispNameRequired;

    @Column(name = "BILL_REF_DISP_NAME")
    private String billRefDispName;

    @Column(name = "CREDITCARD_PAYMENT")
    private Long creditcardPayment;

    @Column(name = "MIN_CREDITCARD_PAYMENT")
    private Long minCreditcardPayment;

    @Column(name = "MAX_CREDITCARD_PAYMENT")
    private Long maxCreditcardPayment;

    @Column(name = "PN_ESTATUS")
    private Long pnEstatus;

    @Column(name = "PN_PRIORITY")
    private String pnPriority;

    @Column(name = "PN_PAYEE_IP")
    private String pnPayeeIp;

    @Column(name = "PN_PAYEE_KEY")
    private String pnPayeeKey;

    @Column(name = "IMAGE_NAME")
    private String imageName;

    @Column(name = "TYPE_OF_PAYMENT")
    private String typeOfPayment;

    @Column(name = "REGISTER_INDICATER")
    private Long registerIdicater;

    @Column(name = "EFFECTIVE_DATE")
    private Long effectiveDate;

    @Column(name = "PROGRAM_LINKED")
    private String programLinked;

    @Column(name = "DEBIT_ENGINE_ALLOWED")
    private Long debitEngineAllowed;

    @Column(name = "BILL_PAYMENT_ALLOWED")
    private Long billPaymentAllowed;

    @Column(name = "SERIAL_NO_INDICATER")
    private Long serialNoIndicater;

    @Column(name = "SERIAL_NO_NAME")
    private String serialNoName;

    @Column(name = "RECHARGE_CODE_INDICATER")
    private Long rechargeCodeIndicater;

    @Column(name = "RECHARGE_CODE_NAME")
    private String rechargeCodeName;

    @Column(name = "MIN_PAYMENT")
    private Long minPayment;

    @Column(name = "MIN_PAYMENT_AMOUNT")
    private Long minPaymentAmount;

    @Column(name = "MAX_PAYMENT")
    private Long maxPayment;

    @Column(name = "MAX_PAYMENT_AMOUNT")
    private Long maxPaymentAmount;

    @Column(name = "NOTE_REQUIRED")
    private String noteRequired;

    @Column(name = "NOTE_REQUIRED2")
    private String noteRequired2;

    @Column(name = "NOTE_REQUIRED3")
    private String noteRequired3;

    @Column(name = "IMAGE_NAME_BILLREG")
    private String iamgeNameBillreg;

    @Column(name = "PN_PAYEE_EMAIL1")
    private String pnPayeeEmail1;

    @Column(name = "PN_PAYEE_EMAIL2")
    private String pnPayeeEmail2;

    @Column(name = "MOBILE_FINANCIAL_SERVICES")
    private Long mobileFinancialServices;

    @Column(name = "ESP_ALLOWED")
    private Long espAllowed;

    @Column(name = "AUTHENTICATION_REQUIRED")
    private Long authenticationRequired;

    @Column(name = "TAC_REQUIRED")
    private Long tacRequired;

    @Column(name = "PAYMENT_LIMIT")
    private Long paymentLimit;

    @Column(name = "ONLINE_WEB_PAYMENT")
    private Long onlineWebPayment;

    @Column(name = "PAYEE_WEBSERVICES_URL")
    private String payeeWebservicesUrl;

    @Column(name = "RETURNED_LINK")
    private Long returnedLink;

    @Column(name = "MERCHANT_URL")
    private String merchantUrl;

    @Column(name = "PAYEE_URL")
    private String payeeUrl;

    @Column(name = "BILL_REF2_REQUIRED")
    private Long billRef2Required;

    @Column(name = "BILL_REF2_DISP_NAME_REQUIRED")
    private Long billRef2DispNameRequired;

    @Column(name = "BILL_REF2_DISP_NAME")
    private String billRef2DispName;

    @Column(name = "RECURRING_INDICATOR")
    private Long recurringIndicator;

    @Column(name = "DOWNTIME_MESSAGE")
    private String downtimeMessage;

    @Column(name = "DOWNTIME_BIT")
    private Long downtimeBit;

    @Column(name = "DOWN_START_DATE")
    private LocalDateTime downStartDate;

    @Column(name = "DOWN_END_DATE")
    private LocalDateTime downEndDate;

    @OneToMany(mappedBy = "mbbPayeeList", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<MBBPayeeLanguage> mbbPayeeLanguageList;

    @OneToMany(mappedBy = "mbbPayeeList", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<MBBPayeeProductList> mbbPayeeProductListsList;

    @OneToMany(mappedBy = "mbbPayeeList", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<MBBPayeeGeneralList> mbbPayeeGeneralListsList;
}
