package com.m2u.payment.exception;

import com.m2u.payment.enums.PaymentServiceStatus;

public class PaymentException extends Exception {

    private static final String ERROR_MESSAGE_FORMAT = "%s. %s";
    
    private final PaymentServiceStatus status;

    public PaymentException(PaymentServiceStatus status, String errorDetails) {
        super(String.format(ERROR_MESSAGE_FORMAT, status.getStatusMessage(), errorDetails));
        this.status = status;
    }

    public PaymentException(PaymentServiceStatus status, String errorDetails, Throwable e) {
        super(String.format(ERROR_MESSAGE_FORMAT, status.getStatusMessage(), errorDetails), e);
        this.status = status;
    }

    public PaymentServiceStatus getStatus() {
        return status;
    }
}
