package com.m2u.payment.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Table(name="MBB_PRODUCT_LIST")
@Entity
public class MBBProductList implements Serializable {

    @Id
    @Column(name = "OID")
    private Long oid;

    @Column(name = "PRODUCT_CODE", nullable = false)
    private String productCode;

    @Column(name = "STORE_ID", nullable = false)
    private Long storeId;

    @Column(name = "CREATION_TIME", nullable = false)
    private LocalDateTime creationTime;

    @Column(name = "STATUS", nullable = false)
    private Long status;

    @Column(name = "DELETED", nullable = false)
    private Long deleted;

    @Column(name = "LAST_MOD_TIME", nullable = false)
    private LocalDateTime lastModTime;

    @Column(name = "ACCOUNT_TYPE", nullable = false)
    private String accountType;

    @Column(name = "S_NAME", nullable = false)
    private String sName;

    @Column(name = "L_NAME", nullable = false)
    private String lName;

    @Column(name = "TRF_FR", nullable = false)
    private Long trfFr;

    @Column(name = "TRF_TO", nullable = false)
    private Long trfTo;

    @Column(name = "TRF_3RD_FR", nullable = false)
    private Long trf3rdFr;

    @Column(name = "TRF_3RD_TO", nullable = false)
    private Long trf3rdTo;

    @Column(name = "ONPAY_FR", nullable = false)
    private Long onpayFr;

    @Column(name = "NONPAY_FR", nullable = false)
    private Long nonpayFr;

    @Column(name = "CHQ_FR", nullable = false)
    private Long chqFr;

    @Column(name = "ESA_FR", nullable = false)
    private Long esaFr;

    @Column(name = "PRNW_FR", nullable = false)
    private Long prnwFr;

    @Column(name = "REQ_AC_STAT_FR", nullable = false)
    private Long reqAcStatFr;

    @Column(name = "FDTD_FR", nullable = false)
    private Long fdtdFr;

    @Column(name = "FDTD_TO", nullable = false)
    private Long fdtdTo;

    @Column(name = "EREMITTANCE_FR", nullable = false)
    private Long eremittanceFr;

    @Column(name = "EPF_FR", nullable = false)
    private Long epfFr;

    @Column(name = "SIC_SMF", nullable = false)
    private Long sicSmf;

    @Column(name = "FUND_ALLOCATION_FR", nullable = false)
    private Long fundAllocationFr;

    @Column(name = "FD_UPLIFTMENT_TO", nullable = false)
    private Long fdUpliftmentTo;

    @Column(name = "UNIT_TRUST_FR", nullable = false)
    private Long unitTrustFr;

    @Column(name = "ESP_FROM", nullable = false)
    private Long espFrom;

    @Column(name = "RATE")
    private String rate;

    @Column(name = "RATE_COND")
    private String rateCond;

    @Column(name = "LOYAL_PROG")
    private String loyalProg;

    @Column(name = "TRF_LIMIT")
    private Long trfLimit;

    @Column(name = "SVCS_CHARGE")
    private Long svcsCharge;

    @Column(name = "ADDRESS_FR", nullable = false)
    private Long addressFr;

    @Column(name = "BILLPYMT_TO")
    private Long billpymtTo;

    @Column(name = "MAXIHOME_REDRAW_TO")
    private Long maxihomeRedrawTo;

    @Column(name = "SMS_SERVICE_BIT")
    private Long smsServiceBit;

    @Column(name = "PPA_FR")
    private Long ppaFr;

    @Column(name = "FPX_FR")
    private Long fpxFr;

    @Column(name = "JOINT_FROM")
    private Long jointFrom;

    @Column(name = "JPY_FRA")
    private Long jpyFra;

    @Column(name = "PAY_FRA")
    private Long payFra;

    @Column(name = "CONV_ALLOW")
    private Long convAllow;

    @Column(name = "CONV_TOACC")
    private String convToacc;

    @Column(name = "SA_REQUIRED")
    private Long saRequired;

    @OneToMany(mappedBy = "mbbProductList", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<MBBProductInfo> mbbProductInfoList;
}
