package com.m2u.payment.repository;

import com.m2u.payment.entity.INETPaymentControlDetails;
import com.m2u.payment.entity.INETPaymentControlDetailsId;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface INETPaymentControlDetailsRepository extends CrudRepository<INETPaymentControlDetails, INETPaymentControlDetailsId> {

    @Query("select count(*), sum(a.transactionAmount) " +
        "from INETPaymentControlDetails a " +
        "where a.inetPaymentControlDetailsId.userAlias = :userAlias " +
        "and a.inetPaymentControlDetailsId.payeeCode = :payeeCode " +
        "and a.inetPaymentControlDetailsId.transactionDate >= :beginDate")
    List<Object[]> countTotalTxnsAndToTalAmounts(String userAlias, String payeeCode, LocalDateTime beginDate);
}
