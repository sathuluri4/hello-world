package com.m2u.payment.resources;

import com.m2u.common.utils.StringUtils;
import com.m2u.payment.constants.PaymentServiceConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;

@Slf4j
@Component
public class M2UApplicationResources {

    private static final Map<String, ResourceBundle> propertiesMap = new HashMap<>();

    private M2UApplicationResources(
        @Value("${m2u.payment.supported-locale}") List<String> supportedLocales) {

        for(String localeStr : supportedLocales) {
            Locale locale = null;
            if(!StringUtils.isEmptyString(localeStr)) {
                String[] localeToken = localeStr.split("_");
                if(1 == localeToken.length) {
                    locale = new Locale(localeToken[0]);
                } else if (2 == localeToken.length) {
                    locale = new Locale(localeToken[0], localeToken[1]);
                } else {
                    // If >2 token found, ignore it
                    continue;
                }

                ResourceBundle rb = ResourceBundle.getBundle("M2UApplicationResources", locale);
                propertiesMap.put(localeStr, rb);
            }
        }
    }

    public static String getValue(String key) {
        // TODO: Default to en locale
        return propertiesMap.get(PaymentServiceConstant.DEFAULT_LOCALE).getString(key);
    }

    public static String getValue(String key, String locale) {
        return propertiesMap.get(locale).getString(key);
    }
}
