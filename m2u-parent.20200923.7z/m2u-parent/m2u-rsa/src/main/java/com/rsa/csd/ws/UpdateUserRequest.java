/**
 * UpdateUserRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;

public class UpdateUserRequest  extends com.rsa.csd.ws.GenericRequest  implements java.io.Serializable {
    private com.rsa.csd.ws.CredentialManagementRequestList credentialManagementRequestList;

    private com.rsa.csd.ws.DeviceManagementRequestPayload deviceManagementRequest;

    private com.rsa.csd.ws.EventDataList eventDataList;

    private com.rsa.csd.ws.RunRiskType runRiskType;

    private com.rsa.csd.ws.UserData userData;

    private com.rsa.csd.ws.UserPreference userPreference;

    private com.rsa.csd.ws.ChannelIndicatorType channelIndicator;

    private java.lang.String clientDefinedChannelIndicator;

    public UpdateUserRequest() {
    }

    public UpdateUserRequest(
           com.rsa.csd.ws.GenericActionTypeList actionTypeList,
           com.rsa.csd.ws.ConfigurationHeader configurationHeader,
           com.rsa.csd.ws.DeviceRequest deviceRequest,
           com.rsa.csd.ws.IdentificationData identificationData,
           com.rsa.csd.ws.MessageHeader messageHeader,
           com.rsa.csd.ws.SecurityHeader securityHeader,
           com.rsa.csd.ws.CredentialManagementRequestList credentialManagementRequestList,
           com.rsa.csd.ws.DeviceManagementRequestPayload deviceManagementRequest,
           com.rsa.csd.ws.EventDataList eventDataList,
           com.rsa.csd.ws.RunRiskType runRiskType,
           com.rsa.csd.ws.UserData userData,
           com.rsa.csd.ws.UserPreference userPreference,
           com.rsa.csd.ws.ChannelIndicatorType channelIndicator,
           java.lang.String clientDefinedChannelIndicator) {
        super(
            actionTypeList,
            configurationHeader,
            deviceRequest,
            identificationData,
            messageHeader,
            securityHeader);
        this.credentialManagementRequestList = credentialManagementRequestList;
        this.deviceManagementRequest = deviceManagementRequest;
        this.eventDataList = eventDataList;
        this.runRiskType = runRiskType;
        this.userData = userData;
        this.userPreference = userPreference;
        this.channelIndicator = channelIndicator;
        this.clientDefinedChannelIndicator = clientDefinedChannelIndicator;
    }


    /**
     * Gets the credentialManagementRequestList value for this UpdateUserRequest.
     * 
     * @return credentialManagementRequestList
     */
    public com.rsa.csd.ws.CredentialManagementRequestList getCredentialManagementRequestList() {
        return credentialManagementRequestList;
    }


    /**
     * Sets the credentialManagementRequestList value for this UpdateUserRequest.
     * 
     * @param credentialManagementRequestList
     */
    public void setCredentialManagementRequestList(com.rsa.csd.ws.CredentialManagementRequestList credentialManagementRequestList) {
        this.credentialManagementRequestList = credentialManagementRequestList;
    }


    /**
     * Gets the deviceManagementRequest value for this UpdateUserRequest.
     * 
     * @return deviceManagementRequest
     */
    public com.rsa.csd.ws.DeviceManagementRequestPayload getDeviceManagementRequest() {
        return deviceManagementRequest;
    }


    /**
     * Sets the deviceManagementRequest value for this UpdateUserRequest.
     * 
     * @param deviceManagementRequest
     */
    public void setDeviceManagementRequest(com.rsa.csd.ws.DeviceManagementRequestPayload deviceManagementRequest) {
        this.deviceManagementRequest = deviceManagementRequest;
    }


    /**
     * Gets the eventDataList value for this UpdateUserRequest.
     * 
     * @return eventDataList
     */
    public com.rsa.csd.ws.EventDataList getEventDataList() {
        return eventDataList;
    }


    /**
     * Sets the eventDataList value for this UpdateUserRequest.
     * 
     * @param eventDataList
     */
    public void setEventDataList(com.rsa.csd.ws.EventDataList eventDataList) {
        this.eventDataList = eventDataList;
    }


    /**
     * Gets the runRiskType value for this UpdateUserRequest.
     * 
     * @return runRiskType
     */
    public com.rsa.csd.ws.RunRiskType getRunRiskType() {
        return runRiskType;
    }


    /**
     * Sets the runRiskType value for this UpdateUserRequest.
     * 
     * @param runRiskType
     */
    public void setRunRiskType(com.rsa.csd.ws.RunRiskType runRiskType) {
        this.runRiskType = runRiskType;
    }


    /**
     * Gets the userData value for this UpdateUserRequest.
     * 
     * @return userData
     */
    public com.rsa.csd.ws.UserData getUserData() {
        return userData;
    }


    /**
     * Sets the userData value for this UpdateUserRequest.
     * 
     * @param userData
     */
    public void setUserData(com.rsa.csd.ws.UserData userData) {
        this.userData = userData;
    }


    /**
     * Gets the userPreference value for this UpdateUserRequest.
     * 
     * @return userPreference
     */
    public com.rsa.csd.ws.UserPreference getUserPreference() {
        return userPreference;
    }


    /**
     * Sets the userPreference value for this UpdateUserRequest.
     * 
     * @param userPreference
     */
    public void setUserPreference(com.rsa.csd.ws.UserPreference userPreference) {
        this.userPreference = userPreference;
    }


    /**
     * Gets the channelIndicator value for this UpdateUserRequest.
     * 
     * @return channelIndicator
     */
    public com.rsa.csd.ws.ChannelIndicatorType getChannelIndicator() {
        return channelIndicator;
    }


    /**
     * Sets the channelIndicator value for this UpdateUserRequest.
     * 
     * @param channelIndicator
     */
    public void setChannelIndicator(com.rsa.csd.ws.ChannelIndicatorType channelIndicator) {
        this.channelIndicator = channelIndicator;
    }


    /**
     * Gets the clientDefinedChannelIndicator value for this UpdateUserRequest.
     * 
     * @return clientDefinedChannelIndicator
     */
    public java.lang.String getClientDefinedChannelIndicator() {
        return clientDefinedChannelIndicator;
    }


    /**
     * Sets the clientDefinedChannelIndicator value for this UpdateUserRequest.
     * 
     * @param clientDefinedChannelIndicator
     */
    public void setClientDefinedChannelIndicator(java.lang.String clientDefinedChannelIndicator) {
        this.clientDefinedChannelIndicator = clientDefinedChannelIndicator;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UpdateUserRequest)) return false;
        UpdateUserRequest other = (UpdateUserRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.credentialManagementRequestList==null && other.getCredentialManagementRequestList()==null) || 
             (this.credentialManagementRequestList!=null &&
              this.credentialManagementRequestList.equals(other.getCredentialManagementRequestList()))) &&
            ((this.deviceManagementRequest==null && other.getDeviceManagementRequest()==null) || 
             (this.deviceManagementRequest!=null &&
              this.deviceManagementRequest.equals(other.getDeviceManagementRequest()))) &&
            ((this.eventDataList==null && other.getEventDataList()==null) || 
             (this.eventDataList!=null &&
              this.eventDataList.equals(other.getEventDataList()))) &&
            ((this.runRiskType==null && other.getRunRiskType()==null) || 
             (this.runRiskType!=null &&
              this.runRiskType.equals(other.getRunRiskType()))) &&
            ((this.userData==null && other.getUserData()==null) || 
             (this.userData!=null &&
              this.userData.equals(other.getUserData()))) &&
            ((this.userPreference==null && other.getUserPreference()==null) || 
             (this.userPreference!=null &&
              this.userPreference.equals(other.getUserPreference()))) &&
            ((this.channelIndicator==null && other.getChannelIndicator()==null) || 
             (this.channelIndicator!=null &&
              this.channelIndicator.equals(other.getChannelIndicator()))) &&
            ((this.clientDefinedChannelIndicator==null && other.getClientDefinedChannelIndicator()==null) || 
             (this.clientDefinedChannelIndicator!=null &&
              this.clientDefinedChannelIndicator.equals(other.getClientDefinedChannelIndicator())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCredentialManagementRequestList() != null) {
            _hashCode += getCredentialManagementRequestList().hashCode();
        }
        if (getDeviceManagementRequest() != null) {
            _hashCode += getDeviceManagementRequest().hashCode();
        }
        if (getEventDataList() != null) {
            _hashCode += getEventDataList().hashCode();
        }
        if (getRunRiskType() != null) {
            _hashCode += getRunRiskType().hashCode();
        }
        if (getUserData() != null) {
            _hashCode += getUserData().hashCode();
        }
        if (getUserPreference() != null) {
            _hashCode += getUserPreference().hashCode();
        }
        if (getChannelIndicator() != null) {
            _hashCode += getChannelIndicator().hashCode();
        }
        if (getClientDefinedChannelIndicator() != null) {
            _hashCode += getClientDefinedChannelIndicator().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UpdateUserRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UpdateUserRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("credentialManagementRequestList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "credentialManagementRequestList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialManagementRequestList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceManagementRequest");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "deviceManagementRequest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceManagementRequestPayload"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("eventDataList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "eventDataList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "EventDataList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("runRiskType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "runRiskType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "RunRiskType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "userData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UserData"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userPreference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "userPreference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UserPreference"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channelIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "channelIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChannelIndicatorType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientDefinedChannelIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "clientDefinedChannelIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
