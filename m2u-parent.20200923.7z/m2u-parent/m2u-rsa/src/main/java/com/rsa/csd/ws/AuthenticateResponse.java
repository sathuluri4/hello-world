/**
 * AuthenticateResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;

public class AuthenticateResponse  extends com.rsa.csd.ws.GenericResponse  implements java.io.Serializable {
    private com.rsa.csd.ws.CredentialAuthResultList credentialAuthResultList;

    private com.rsa.csd.ws.DeviceManagementResponsePayload deviceManagementResponse;

    private com.rsa.csd.ws.RequiredCredentialList requiredCredentialList;

    public AuthenticateResponse() {
    }

    public AuthenticateResponse(
           com.rsa.csd.ws.DeviceResult deviceResult,
           com.rsa.csd.ws.IdentificationData identificationData,
           com.rsa.csd.ws.MessageHeader messageHeader,
           com.rsa.csd.ws.StatusHeader statusHeader,
           com.rsa.csd.ws.CredentialAuthResultList credentialAuthResultList,
           com.rsa.csd.ws.DeviceManagementResponsePayload deviceManagementResponse,
           com.rsa.csd.ws.RequiredCredentialList requiredCredentialList) {
        super(
            deviceResult,
            identificationData,
            messageHeader,
            statusHeader);
        this.credentialAuthResultList = credentialAuthResultList;
        this.deviceManagementResponse = deviceManagementResponse;
        this.requiredCredentialList = requiredCredentialList;
    }


    /**
     * Gets the credentialAuthResultList value for this AuthenticateResponse.
     * 
     * @return credentialAuthResultList
     */
    public com.rsa.csd.ws.CredentialAuthResultList getCredentialAuthResultList() {
        return credentialAuthResultList;
    }


    /**
     * Sets the credentialAuthResultList value for this AuthenticateResponse.
     * 
     * @param credentialAuthResultList
     */
    public void setCredentialAuthResultList(com.rsa.csd.ws.CredentialAuthResultList credentialAuthResultList) {
        this.credentialAuthResultList = credentialAuthResultList;
    }


    /**
     * Gets the deviceManagementResponse value for this AuthenticateResponse.
     * 
     * @return deviceManagementResponse
     */
    public com.rsa.csd.ws.DeviceManagementResponsePayload getDeviceManagementResponse() {
        return deviceManagementResponse;
    }


    /**
     * Sets the deviceManagementResponse value for this AuthenticateResponse.
     * 
     * @param deviceManagementResponse
     */
    public void setDeviceManagementResponse(com.rsa.csd.ws.DeviceManagementResponsePayload deviceManagementResponse) {
        this.deviceManagementResponse = deviceManagementResponse;
    }


    /**
     * Gets the requiredCredentialList value for this AuthenticateResponse.
     * 
     * @return requiredCredentialList
     */
    public com.rsa.csd.ws.RequiredCredentialList getRequiredCredentialList() {
        return requiredCredentialList;
    }


    /**
     * Sets the requiredCredentialList value for this AuthenticateResponse.
     * 
     * @param requiredCredentialList
     */
    public void setRequiredCredentialList(com.rsa.csd.ws.RequiredCredentialList requiredCredentialList) {
        this.requiredCredentialList = requiredCredentialList;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AuthenticateResponse)) return false;
        AuthenticateResponse other = (AuthenticateResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.credentialAuthResultList==null && other.getCredentialAuthResultList()==null) || 
             (this.credentialAuthResultList!=null &&
              this.credentialAuthResultList.equals(other.getCredentialAuthResultList()))) &&
            ((this.deviceManagementResponse==null && other.getDeviceManagementResponse()==null) || 
             (this.deviceManagementResponse!=null &&
              this.deviceManagementResponse.equals(other.getDeviceManagementResponse()))) &&
            ((this.requiredCredentialList==null && other.getRequiredCredentialList()==null) || 
             (this.requiredCredentialList!=null &&
              this.requiredCredentialList.equals(other.getRequiredCredentialList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCredentialAuthResultList() != null) {
            _hashCode += getCredentialAuthResultList().hashCode();
        }
        if (getDeviceManagementResponse() != null) {
            _hashCode += getDeviceManagementResponse().hashCode();
        }
        if (getRequiredCredentialList() != null) {
            _hashCode += getRequiredCredentialList().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AuthenticateResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AuthenticateResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("credentialAuthResultList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "credentialAuthResultList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialAuthResultList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceManagementResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "deviceManagementResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceManagementResponsePayload"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requiredCredentialList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "requiredCredentialList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "RequiredCredentialList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
