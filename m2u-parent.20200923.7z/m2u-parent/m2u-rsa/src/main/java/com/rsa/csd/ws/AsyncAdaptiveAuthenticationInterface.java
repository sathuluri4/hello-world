/**
 * AsyncAdaptiveAuthenticationInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;

public interface AsyncAdaptiveAuthenticationInterface extends java.rmi.Remote {
    public void notify(com.rsa.csd.ws.NotifyRequest request) throws java.rmi.RemoteException;
    public void analyze(com.rsa.csd.ws.AnalyzeRequest request) throws java.rmi.RemoteException;
}
