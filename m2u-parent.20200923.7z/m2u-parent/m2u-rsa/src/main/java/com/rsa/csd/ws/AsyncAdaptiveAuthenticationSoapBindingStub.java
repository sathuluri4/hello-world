/**
 * AsyncAdaptiveAuthenticationSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;

public class AsyncAdaptiveAuthenticationSoapBindingStub extends org.apache.axis.client.Stub implements com.rsa.csd.ws.AsyncAdaptiveAuthenticationInterface {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[2];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("notify");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://ws.csd.rsa.com", "NotifyRequest"), com.rsa.csd.ws.NotifyRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("analyze");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AnalyzeRequest"), com.rsa.csd.ws.AnalyzeRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

    }

    public AsyncAdaptiveAuthenticationSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public AsyncAdaptiveAuthenticationSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public AsyncAdaptiveAuthenticationSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.1");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://trx.csd.rsa.com", "Action");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.trx.Action.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://trx.csd.rsa.com", "Payload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.trx.Payload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://trx.csd.rsa.com", "TrxSignAuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.trx.TrxSignAuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://trx.csd.rsa.com", "TrxSignAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.trx.TrxSignAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://trx.csd.rsa.com", "TrxSignChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.trx.TrxSignChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://trx.csd.rsa.com", "TrxSignManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.trx.TrxSignManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AccountData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AccountData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AccountOwnershipType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AccountOwnershipType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AccountRelationType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AccountRelationType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AccountType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AccountType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspAuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AcspAuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspAuthenticationRequestData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AcspAuthenticationRequestData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AcspAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspAuthStatusRequestData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AcspAuthStatusRequestData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AcspChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspChallengeRequestData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AcspChallengeRequestData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AcspManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AcspManagementRequestData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AcspManagementRequestData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ActionTypeList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ActionTypeList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "Amount");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.Amount.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AnalyzeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AnalyzeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "APIType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.APIType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ATM");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ATM.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ATMLocation");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ATMLocation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ATMLocationTypes");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ATMLocationTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ATMOwnerType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ATMOwnerType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AuthenticateRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AuthenticateRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AuthenticationLevel");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AuthenticationLevel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "AuthorizationMethod");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.AuthorizationMethod.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "BindingType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.BindingType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestion");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionActionType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionActionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionActionTypeList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionActionTypeList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionChallengeRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionChallengeRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionConfig");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionConfig.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionDataPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionDataPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionIdList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionIdList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeQuestionManagementRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeQuestionManagementRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ChannelIndicatorType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ChannelIndicatorType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ClientDefinedFact");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ClientDefinedFact.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ClientGenCookie");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ClientGenCookie.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ClientReturnData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ClientReturnData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CollectionInitiator");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CollectionInitiator.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CollectionReason");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CollectionReason.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CollectionRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CollectionRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ConfigurationHeader");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ConfigurationHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "Coordinates");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.Coordinates.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CreateUserRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CreateUserRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "Credential");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.Credential.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialChallengeRequestList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialChallengeRequestList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialDataList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialDataList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialManagementRequestList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialManagementRequestList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialProvisioningStatus");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialProvisioningStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialRequestList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialRequestList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialStatus");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "CredentialType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.CredentialType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DataType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.DataType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceActionType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.DeviceActionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceActionTypeList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.DeviceActionTypeList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.DeviceData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceIdentifier");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.DeviceIdentifier.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceManagementRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.DeviceManagementRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "DeviceRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.DeviceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "EmailInfo");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.EmailInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "EmailManagementRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.EmailManagementRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "EventData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.EventData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "EventDataList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.EventDataList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "EventType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.EventType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "ExecutionSpeed");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.ExecutionSpeed.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "FactList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.FactList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "Gender");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.Gender.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "GenericActionType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.GenericActionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "GenericActionTypeList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.GenericActionTypeList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "GenericRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.GenericRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "GeoLocation");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.GeoLocation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "IdentificationData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.IdentificationData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "LoginFailureType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.LoginFailureType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "MessageHeader");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.MessageHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "MessageVersion");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.MessageVersion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "MilterOption");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.MilterOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "MobileDevice");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.MobileDevice.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "NamedValue");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.NamedValue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "NotifyRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.NotifyRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OOBActionType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OOBActionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OOBActionTypeList");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OOBActionTypeList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OOBContactInfoObject");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OOBContactInfoObject.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobEmailAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OobEmailAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobEmailChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OobEmailChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OOBEmailChallengeRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OOBEmailChallengeRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobEmailData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OobEmailData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobEmailManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OobEmailManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OOBInfoRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OOBInfoRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OOBManagementRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OOBManagementRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobPhoneAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OobPhoneAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobPhoneChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OobPhoneChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OOBPhoneChallengeRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OOBPhoneChallengeRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobPhoneData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OobPhoneData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OobPhoneManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OobPhoneManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OtherAccountBankType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OtherAccountBankType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OtherAccountOwnershipType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OtherAccountOwnershipType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OtherAccountType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OtherAccountType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OTPAuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OTPAuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OTPAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OTPAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OTPChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OTPChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "OTPManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.OTPManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "PhoneData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.PhoneData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "PhoneInfo");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.PhoneInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "PhoneManagementRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.PhoneManagementRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "PriceType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.PriceType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "QueryAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.QueryAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "QueryRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.QueryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "RequestType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.RequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "RunRiskType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.RunRiskType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "Schedule");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.Schedule.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "SecurityHeader");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.SecurityHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "StockData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.StockData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "StockTradeData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.StockTradeData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "TermType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.TermType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "TradeType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.TradeType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "TransactionData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.TransactionData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "TransferMediumType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.TransferMediumType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UnsupportedAuthStatusRequestPayload");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.UnsupportedAuthStatusRequestPayload.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UpdateUserRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.UpdateUserRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UserAddress");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.UserAddress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UserData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.UserData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UserName");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.UserName.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UserPreference");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.UserPreference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "UserStatus");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.UserStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "WiFiNetworkData");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.WiFiNetworkData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.csd.rsa.com", "WSUserType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.ws.WSUserType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod1.csd.rsa.com", "ExternalMethod1AuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod1.ws.ExternalMethod1AuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod1.csd.rsa.com", "ExternalMethod1AuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod1.ws.ExternalMethod1AuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod1.csd.rsa.com", "ExternalMethod1ChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod1.ws.ExternalMethod1ChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod1.csd.rsa.com", "ExternalMethod1ManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod1.ws.ExternalMethod1ManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod2.csd.rsa.com", "ExternalMethod2AuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod2.ws.ExternalMethod2AuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod2.csd.rsa.com", "ExternalMethod2AuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod2.ws.ExternalMethod2AuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod2.csd.rsa.com", "ExternalMethod2ChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod2.ws.ExternalMethod2ChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod2.csd.rsa.com", "ExternalMethod2ManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod2.ws.ExternalMethod2ManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod3.csd.rsa.com", "ExternalMethod3AuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod3.ws.ExternalMethod3AuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod3.csd.rsa.com", "ExternalMethod3AuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod3.ws.ExternalMethod3AuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod3.csd.rsa.com", "ExternalMethod3ChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod3.ws.ExternalMethod3ChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.externalmethod3.csd.rsa.com", "ExternalMethod3ManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.externalmethod3.ws.ExternalMethod3ManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "Action");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.Action.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "AddressInfo");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.AddressInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "Answer");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.Answer.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "BirthdayInfo");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.BirthdayInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "KBAAuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.KBAAuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "KBAAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.KBAAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "KBAChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.KBAChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "KBAManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.KBAManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "NameInfo");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.NameInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "PersonInfo");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.PersonInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "SSNInfo");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.SSNInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.kba.csd.rsa.com", "SSNType");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.kba.ws.SSNType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.oobbio.csd.rsa.com", "OOBBioAuthAuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobbio.ws.OOBBioAuthAuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobbio.csd.rsa.com", "OOBBioAuthAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobbio.ws.OOBBioAuthAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobbio.csd.rsa.com", "OOBBioAuthChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobbio.ws.OOBBioAuthChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobbio.csd.rsa.com", "OOBBioAuthManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobbio.ws.OOBBioAuthManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobgen.csd.rsa.com", "Action");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobgen.ws.Action.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://ws.oobgen.csd.rsa.com", "OOBGenAuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobgen.ws.OOBGenAuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobgen.csd.rsa.com", "OOBGenAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobgen.ws.OOBGenAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobgen.csd.rsa.com", "OOBGenChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobgen.ws.OOBGenChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobgen.csd.rsa.com", "OOBGenManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobgen.ws.OOBGenManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobgen.csd.rsa.com", "OOBPhoneInfo");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobgen.ws.OOBPhoneInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobsms.csd.rsa.com", "OOBSMSAuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobsms.ws.OOBSMSAuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobsms.csd.rsa.com", "OOBSMSAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobsms.ws.OOBSMSAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobsms.csd.rsa.com", "OOBSMSChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobsms.ws.OOBSMSChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.oobsms.csd.rsa.com", "OOBSMSManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.oobsms.ws.OOBSMSManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.otpmobileapp.csd.rsa.com", "OTPMobileAppAuthenticationRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.otpmobileapp.ws.OTPMobileAppAuthenticationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.otpmobileapp.csd.rsa.com", "OTPMobileAppAuthStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.otpmobileapp.ws.OTPMobileAppAuthStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.otpmobileapp.csd.rsa.com", "OTPMobileAppChallengeRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.otpmobileapp.ws.OTPMobileAppChallengeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ws.otpmobileapp.csd.rsa.com", "OTPMobileAppManagementRequest");
            cachedSerQNames.add(qName);
            cls = com.rsa.csd.otpmobileapp.ws.OTPMobileAppManagementRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public void notify(com.rsa.csd.ws.NotifyRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("rsa:notify:Notify");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "notify"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {request});

    }

    public void analyze(com.rsa.csd.ws.AnalyzeRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("rsa:analyze:Analyze");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "analyze"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {request});

    }

}
