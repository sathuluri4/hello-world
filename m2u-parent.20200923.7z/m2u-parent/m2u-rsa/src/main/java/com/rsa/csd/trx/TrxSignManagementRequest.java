/**
 * TrxSignManagementRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.trx;

public class TrxSignManagementRequest  extends com.rsa.csd.ws.AcspManagementRequest  implements java.io.Serializable {
    private com.rsa.csd.trx.Action action;

    private java.lang.String publicKey;

    private java.lang.String entropy;

    private java.lang.String indicies;

    public TrxSignManagementRequest() {
    }

    public TrxSignManagementRequest(
           java.lang.String opcode,
           com.rsa.csd.trx.Action action,
           java.lang.String publicKey,
           java.lang.String entropy,
           java.lang.String indicies) {
        super(
            opcode);
        this.action = action;
        this.publicKey = publicKey;
        this.entropy = entropy;
        this.indicies = indicies;
    }


    /**
     * Gets the action value for this TrxSignManagementRequest.
     * 
     * @return action
     */
    public com.rsa.csd.trx.Action getAction() {
        return action;
    }


    /**
     * Sets the action value for this TrxSignManagementRequest.
     * 
     * @param action
     */
    public void setAction(com.rsa.csd.trx.Action action) {
        this.action = action;
    }


    /**
     * Gets the publicKey value for this TrxSignManagementRequest.
     * 
     * @return publicKey
     */
    public java.lang.String getPublicKey() {
        return publicKey;
    }


    /**
     * Sets the publicKey value for this TrxSignManagementRequest.
     * 
     * @param publicKey
     */
    public void setPublicKey(java.lang.String publicKey) {
        this.publicKey = publicKey;
    }


    /**
     * Gets the entropy value for this TrxSignManagementRequest.
     * 
     * @return entropy
     */
    public java.lang.String getEntropy() {
        return entropy;
    }


    /**
     * Sets the entropy value for this TrxSignManagementRequest.
     * 
     * @param entropy
     */
    public void setEntropy(java.lang.String entropy) {
        this.entropy = entropy;
    }


    /**
     * Gets the indicies value for this TrxSignManagementRequest.
     * 
     * @return indicies
     */
    public java.lang.String getIndicies() {
        return indicies;
    }


    /**
     * Sets the indicies value for this TrxSignManagementRequest.
     * 
     * @param indicies
     */
    public void setIndicies(java.lang.String indicies) {
        this.indicies = indicies;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TrxSignManagementRequest)) return false;
        TrxSignManagementRequest other = (TrxSignManagementRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.publicKey==null && other.getPublicKey()==null) || 
             (this.publicKey!=null &&
              this.publicKey.equals(other.getPublicKey()))) &&
            ((this.entropy==null && other.getEntropy()==null) || 
             (this.entropy!=null &&
              this.entropy.equals(other.getEntropy()))) &&
            ((this.indicies==null && other.getIndicies()==null) || 
             (this.indicies!=null &&
              this.indicies.equals(other.getIndicies())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getPublicKey() != null) {
            _hashCode += getPublicKey().hashCode();
        }
        if (getEntropy() != null) {
            _hashCode += getEntropy().hashCode();
        }
        if (getIndicies() != null) {
            _hashCode += getIndicies().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TrxSignManagementRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "TrxSignManagementRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("action");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "action"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "Action"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publicKey");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "publicKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("entropy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "entropy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicies");
        elemField.setXmlName(new javax.xml.namespace.QName("http://trx.csd.rsa.com", "indicies"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
