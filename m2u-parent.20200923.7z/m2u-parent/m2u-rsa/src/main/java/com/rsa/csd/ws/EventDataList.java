/**
 * EventDataList.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.rsa.csd.ws;

public class EventDataList  implements java.io.Serializable {
    private com.rsa.csd.ws.EventData[] eventData;

    public EventDataList() {
    }

    public EventDataList(
           com.rsa.csd.ws.EventData[] eventData) {
           this.eventData = eventData;
    }


    /**
     * Gets the eventData value for this EventDataList.
     * 
     * @return eventData
     */
    public com.rsa.csd.ws.EventData[] getEventData() {
        return eventData;
    }


    /**
     * Sets the eventData value for this EventDataList.
     * 
     * @param eventData
     */
    public void setEventData(com.rsa.csd.ws.EventData[] eventData) {
        this.eventData = eventData;
    }

    public com.rsa.csd.ws.EventData getEventData(int i) {
        return this.eventData[i];
    }

    public void setEventData(int i, com.rsa.csd.ws.EventData _value) {
        this.eventData[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EventDataList)) return false;
        EventDataList other = (EventDataList) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.eventData==null && other.getEventData()==null) || 
             (this.eventData!=null &&
              java.util.Arrays.equals(this.eventData, other.getEventData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEventData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEventData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEventData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EventDataList.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "EventDataList"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("eventData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "eventData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.csd.rsa.com", "EventData"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
