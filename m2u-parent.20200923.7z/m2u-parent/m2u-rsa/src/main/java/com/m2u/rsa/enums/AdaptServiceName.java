package com.m2u.rsa.enums;

import com.rsa.csd.ws.EventType;
import com.rsa.csd.ws.GenericActionType;
import com.rsa.csd.ws.RequestType;
import com.rsa.csd.ws.RunRiskType;

public enum AdaptServiceName {

    // NOTIFY
    ATTEMPT_LOGIN_USERNAME_NOTIFY (new GenericActionType[] { GenericActionType.SET_USER_STATUS }, RequestType.NOTIFY, EventType.SESSION_SIGNIN, null),
    LOGIN_USERNAME_PASSWORD_FAILED_NOTIFY (new GenericActionType[] { GenericActionType.SET_USER_STATUS }, RequestType.NOTIFY, EventType.SESSION_SIGNIN, null),
    GET_CUSTOMER_INFO_FROM_CLARITY_NOTIFY(new GenericActionType[] { GenericActionType.SET_USER_STATUS }, RequestType.NOTIFY, EventType.SESSION_SIGNIN, null),
    CREATE_PAYMENT_TO_CLARITY_NOTIFY(new GenericActionType[] { GenericActionType.SET_USER_STATUS }, RequestType.NOTIFY, EventType.PAYMENT, null),

    // CREATE USER
    LOGIN_NOT_ENROLL_CREATE_USER (new GenericActionType[] { GenericActionType.SET_USER_STATUS, GenericActionType.SET_USER_GROUP }, RequestType.CREATEUSER, EventType.SESSION_SIGNIN, RunRiskType.ALL),
    ;

    GenericActionType[] genericActionTypeArray;
    EventType eventType;
    RequestType requestType;
    RunRiskType runRiskType;

    AdaptServiceName(GenericActionType[] genericActionTypeArray, RequestType requestType, EventType eventType, RunRiskType runRiskType) {
        this.genericActionTypeArray = genericActionTypeArray;
        this.requestType = requestType;
        this.eventType = eventType;
        this.runRiskType = runRiskType;
    }

    public GenericActionType[] getGenericActionTypeArray() {
        return genericActionTypeArray;
    }

    public RequestType getRequestType() {
        return requestType;
    }

    public EventType getEventType() {
        return eventType;
    }

    public RunRiskType getRunRiskType() {
        return runRiskType;
    }
}
