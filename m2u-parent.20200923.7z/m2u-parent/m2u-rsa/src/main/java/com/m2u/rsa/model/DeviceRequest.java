package com.m2u.rsa.model;

import lombok.Data;

@Data
public class DeviceRequest {

    private String devicePrint;
    private String deviceTokenCookie;
    private String deviceTokenFSO;
    private String accept;
    private String acceptCharset;
    private String acceptEncoding;
    private String acceptLanguage;
    private String referrer;
    private String userAgent;
    private String remoteAddress;
    private String domElements;
    private String jsEvents;
    private String pageId;
}
