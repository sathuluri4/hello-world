package com.m2u.rsa.service;

import com.m2u.rsa.config.AdaptConfiguration;
import com.m2u.rsa.createuser.AbstractCreateUser;
import com.m2u.rsa.createuser.LoginNotEnrollCreateUser;
import com.m2u.rsa.dto.AdaptCreateUserRequestDTO;
import com.m2u.rsa.dto.AdaptCreateUserResponseDTO;
import com.m2u.rsa.dto.AdaptNotifyRequestDTO;
import com.m2u.rsa.dto.AdaptNotifyResponseDTO;
import com.m2u.rsa.enums.AdaptServiceName;
import com.m2u.rsa.exception.AdaptException;
import com.m2u.rsa.notify.*;
import com.rsa.csd.ws.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AdaptServiceImpl implements AdaptService {

    @Override
    public AdaptNotifyResponseDTO notify(AdaptNotifyRequestDTO req) throws AdaptException {
        log.debug("AdaptNotifyRequest REQ [{}]", req);
        AdaptNotifyResponseDTO resp = new AdaptNotifyResponseDTO();

        if(!isSwitchOn()) {
            log.debug("Adapt switch is off");
            // TODO: Think a proper response
            resp.setStatusCode(10001);
            return resp;
        }

        try {
            AdaptServiceName adaptServiceName = getAdaptServiceNameByServiceName(req.getServiceName(), req.getSessionId());

            AbstractNotify notify = null;
            switch (adaptServiceName) {
                case ATTEMPT_LOGIN_USERNAME_NOTIFY:
                    notify = new AttemptLoginUsernameNotify(req, adaptServiceName);
                    break;
                case LOGIN_USERNAME_PASSWORD_FAILED_NOTIFY:
                    notify = new LoginUsernamePasswordFailedNotify(req, adaptServiceName);
                    break;
                case GET_CUSTOMER_INFO_FROM_CLARITY_NOTIFY:
                    notify = new GetCustomerInfoFromClarityNotify(req, adaptServiceName);
                    break;
                case CREATE_PAYMENT_TO_CLARITY_NOTIFY:
                    notify = new CreatePaymentToClarityNotify(req, adaptServiceName);
                    break;
                default:
                    String errorDetails = String.format("AdaptServiceName [%s] not supported at the moment. session Id [%s]", adaptServiceName, req.getSessionId());
                    log.error(errorDetails);
                    throw new AdaptException(errorDetails);
            }

            NotifyResponse notifyResp = notify.invoke();
            StatusHeader sHeader = notifyResp.getStatusHeader();
            String desc = sHeader.getReasonDescription();
            int statusCode = sHeader.getStatusCode();
            int reasonCode = sHeader.getReasonCode();
            resp.setDesc(desc);
            resp.setStatusCode(statusCode);
            resp.setReasonCode(reasonCode);

            DeviceResult dResult = notifyResp.getDeviceResult();
            DeviceData dData = null;
            if(null != dResult && null != (dData = dResult.getDeviceData())) {
                resp.setDeviceTokenCookie(dData.getDeviceTokenCookie());
                resp.setDeviceTokenFSO(dData.getDeviceTokenFSO());
            }
        } catch(AdaptException e) {
            throw e;
        } catch (Exception e) {
            String errorDetails = String.format("Unexpected exception occurred. sessionId [%s] eventDesc [%s] serviceName [%s]",
                req.getSessionId(), req.getEventDesc(), req.getServiceName());
            log.error(errorDetails, e);
            throw new AdaptException(errorDetails, e);
        }
        log.debug("AdaptNotifyResponse RESP [{}]", resp);
        return resp;
    }

    @Override
    public AdaptCreateUserResponseDTO createUser(AdaptCreateUserRequestDTO req) throws AdaptException {
        log.debug("AdaptCreateUserRequest REQ [{}]", req);
        AdaptCreateUserResponseDTO resp = new AdaptCreateUserResponseDTO();

        if(!isSwitchOn()) {
            log.debug("Adapt switch is off");
            // TODO: Think a proper response
            resp.setStatusCode(10001);
            return resp;
        }

        try {
            AdaptServiceName adaptServiceName = getAdaptServiceNameByServiceName(req.getServiceName(), req.getSessionId());

            AbstractCreateUser createUser = null;
            switch (adaptServiceName) {
                case LOGIN_NOT_ENROLL_CREATE_USER:
                    createUser = new LoginNotEnrollCreateUser(req, adaptServiceName);
                    break;
                default:
                    String errorDetails = String.format("AdaptServiceName [%s] not supported at the moment. session Id [%s]", adaptServiceName, req.getSessionId());
                    log.error(errorDetails);
                    throw new AdaptException(errorDetails);
            }

            CreateUserResponse createUserResp = createUser.invoke();
            StatusHeader sHeader = createUserResp.getStatusHeader();
            String desc = sHeader.getReasonDescription();
            int statusCode = sHeader.getStatusCode();
            int reasonCode = sHeader.getReasonCode();
            resp.setDesc(desc);
            resp.setStatusCode(statusCode);
            resp.setReasonCode(reasonCode);

            DeviceResult dResult = createUserResp.getDeviceResult();
            DeviceData dData = null;
            if(null != dResult && null != (dData = dResult.getDeviceData())) {
                resp.setDeviceTokenCookie(dData.getDeviceTokenCookie());
                resp.setDeviceTokenFSO(dData.getDeviceTokenFSO());
            }
        } catch(AdaptException e) {
            throw e;
        } catch (Exception e) {
            String errorDetails = String.format("Unexpected exception occurred. sessionId [%s] eventDesc [%s] serviceName [%s]",
                req.getSessionId(), req.getEventDesc(), req.getServiceName());
            log.error(errorDetails, e);
            throw new AdaptException(errorDetails, e);
        }
        log.debug("AdaptCreateUserResponse RESP [{}]", resp);
        return resp;
    }

    private boolean isSwitchOn() {
        String rsaSwitch = AdaptConfiguration.getProperty("SWITCH");
        if(null == rsaSwitch) {
            return false;
        }
        return "0".equals(rsaSwitch);
    }

    private AdaptServiceName getAdaptServiceNameByServiceName(String serviceName, String sessionId) throws AdaptException {
        try {
            return AdaptServiceName.valueOf(serviceName);
        } catch (Exception e) {
            String errorDetails = String.format("Unsupported service name detected [%s]. session Id [%s]", serviceName, sessionId);
            log.error(errorDetails, e);
            throw new AdaptException(errorDetails, e);
        }
    }
}
