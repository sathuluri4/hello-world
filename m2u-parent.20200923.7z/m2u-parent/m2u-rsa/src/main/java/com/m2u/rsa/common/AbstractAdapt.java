package com.m2u.rsa.common;

import com.m2u.common.utils.DateTimeUtils;
import com.m2u.rsa.dto.AbstractAdaptRequestDTO;
import com.m2u.rsa.enums.AdaptServiceName;
import com.m2u.rsa.exception.AdaptException;
import com.m2u.rsa.utils.AdaptMessageHelper;
import com.rsa.csd.ws.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

@Slf4j
@Data
public abstract class AbstractAdapt<T extends GenericResponse> {

	private GenericActionTypeList genericActionTypeList;
	private EventDataList eventDataList;
	private DeviceRequest deviceRequest;
	private IdentificationData identificationData;
	private MessageHeader messageHeader;
	private SecurityHeader securityHeader;
	private ChannelIndicatorType channelIndicatorType;

	private AbstractAdaptRequestDTO req;
	private AdaptServiceName adaptServiceName = null;
	private String sdf = null;

	public AbstractAdapt(AbstractAdaptRequestDTO req, AdaptServiceName adaptServiceName) throws AdaptException {
		this.req = req;
		this.adaptServiceName = adaptServiceName;

		if(StringUtils.isEmpty(req.getSessionId())) {
			String errorDetails = "Missing mandatory session id";
			throw new AdaptException(errorDetails);
		}

		LocalDateTime now = LocalDateTime.now();
		sdf = DateTimeUtils.formatLocalDateTime(LocalDateTime.now(), "yyyy-MM-dd'T'HH:mm:ssz");

		if (StringUtils.isEmpty(req.getTxnId())) {
			ZonedDateTime zdt = ZonedDateTime.of(now, ZoneId.systemDefault());
			String txnId = new StringBuilder(req.getUserId()).append(zdt.toInstant().toEpochMilli()).toString();
			req.setTxnId(txnId);
		}

		// Generic Action Type
		genericActionTypeList = AdaptMessageHelper.createGenericActionType(adaptServiceName.getGenericActionTypeArray());

		if(null == req.getDeviceRequest().getDeviceTokenCookie()) {
			req.getDeviceRequest().setDeviceTokenCookie("");
		}
		if(null == req.getDeviceRequest().getDeviceTokenFSO()) {
			req.getDeviceRequest().setDeviceTokenFSO("");
		}
		if(null == req.getDeviceRequest().getDomElements()) {
			req.getDeviceRequest().setDomElements("");
		}
		if(null == req.getDeviceRequest().getJsEvents()) {
			req.getDeviceRequest().setJsEvents("");
		}
		if(null == req.getDeviceRequest().getPageId()) {
			req.getDeviceRequest().setPageId("");
		}

		// Device Request
		deviceRequest = AdaptMessageHelper.createDeviceRequest(
			req.getDeviceRequest().getDevicePrint(),
			req.getDeviceRequest().getDeviceTokenCookie(),
			req.getDeviceRequest().getDeviceTokenFSO(),
			req.getDeviceRequest().getAccept(),
			req.getDeviceRequest().getAcceptCharset(),
			req.getDeviceRequest().getAcceptEncoding(),
			req.getDeviceRequest().getAcceptLanguage(),
			req.getDeviceRequest().getReferrer(),
			req.getDeviceRequest().getRemoteAddress(),
			req.getDeviceRequest().getUserAgent(),
			req.getDeviceRequest().getDomElements(),
			req.getDeviceRequest().getJsEvents(),
			req.getDeviceRequest().getPageId()
		);

		// Identification Data
		identificationData = AdaptMessageHelper.createIdentificationData(
			req.getIdentificationData().getClientSessionId(),
			req.getTxnId(),
			req.getIdentificationData().getClientSegment(),
			"MaybankMy",
			null,
			null,
			"MY",
			"en",
			req.getIdentificationData().getUserLoginName(),
			req.getIdentificationData().getUsername(),
			UserStatus.VERIFIED,
			WSUserType.PERSISTENT
		);


		// Message Header
		messageHeader = AdaptMessageHelper.createMessageHeader(req.getTxnId(), adaptServiceName.getRequestType(), sdf);

		// Security Header
		securityHeader = AdaptMessageHelper.createSecurityHeader();

		switch(req.getChannel()) {
			case "M":
				channelIndicatorType = ChannelIndicatorType.MOBILE;
				break;
			case "W":
				channelIndicatorType = ChannelIndicatorType.WEB;
				break;
			default:
				String errorDetails = String.format("Channel type [%s] is not supported. sessionId [%s]", req.getChannel(), req.getSessionId());
				log.error(errorDetails);
				throw new AdaptException(errorDetails);
		}
	}

	public abstract T invoke() throws AdaptException;
}