package com.m2u.rsa.createuser;

import com.m2u.rsa.dto.AdaptCreateUserRequestDTO;
import com.m2u.rsa.enums.AdaptServiceName;
import com.m2u.rsa.exception.AdaptException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
public class LoginNotEnrollCreateUser extends AbstractCreateUser {

    public LoginNotEnrollCreateUser(AdaptCreateUserRequestDTO req, AdaptServiceName adaptServiceName) throws AdaptException {
        super(req, adaptServiceName);
    }
}
