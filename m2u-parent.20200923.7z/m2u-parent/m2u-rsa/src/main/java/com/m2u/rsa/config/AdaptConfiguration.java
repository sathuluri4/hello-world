package com.m2u.rsa.config;

import com.m2u.rsa.exception.AdaptException;
import com.rsa.csd.ws.AdaptiveAuthentication;
import com.rsa.csd.ws.AdaptiveAuthenticationInterface;
import com.rsa.csd.ws.AdaptiveAuthenticationLocator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.xml.rpc.ServiceException;
import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

@Slf4j
@Component
public class AdaptConfiguration {

    private static final Properties properties = new Properties();

    private static AdaptiveAuthenticationInterface invoker;

    private AdaptConfiguration(@Value("${m2u.rsa.config-path}") String path) throws MalformedURLException, ServiceException, AdaptException {
        try (FileInputStream in = new FileInputStream(path)) {
            properties.load(in);
        } catch (Exception e) {
            String errorDetails = String.format("Failed to read content from [%s]", path);
            log.error(errorDetails, e);
            throw new AdaptException(errorDetails, e);
        }

        URL adaptWSDL = new URL(properties.getProperty("WSDL"));
        AdaptiveAuthentication locator = new AdaptiveAuthenticationLocator();
        invoker = locator.getAdaptiveAuthentication(adaptWSDL);
    }

    public static String getProperty(String key) {
        return properties.get(key).toString();
    }

    public static AdaptiveAuthenticationInterface getInvoker() {
        return invoker;
    }
}
