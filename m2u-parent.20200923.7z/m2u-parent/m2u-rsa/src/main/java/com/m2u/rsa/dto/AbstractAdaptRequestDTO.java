package com.m2u.rsa.dto;

import com.m2u.rsa.model.DeviceRequest;
import com.m2u.rsa.model.IdentificationData;
import lombok.Data;

@Data
public abstract class AbstractAdaptRequestDTO {

    private String serviceName;
    private String eventDesc;
    private String sessionId;
    private String txnId;
    private String userId;
    private String customerType;
    private String channel;

    // Device Request
    private DeviceRequest deviceRequest = new DeviceRequest();

    // Identification Data
    private IdentificationData identificationData = new IdentificationData();

    // Event Data List
    private String clientDefinedEventType;

    // Transaction Data
    // TODO: At the moment dont need for DPE
}
