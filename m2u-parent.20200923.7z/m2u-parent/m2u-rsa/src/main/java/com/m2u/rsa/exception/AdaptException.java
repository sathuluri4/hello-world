package com.m2u.rsa.exception;

public class AdaptException extends Exception {

    public AdaptException(String message) {
        super(message);
    }

    public AdaptException(String message, Throwable e) {
        super(message, e);
    }
}
