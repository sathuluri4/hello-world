package com.m2u.rsa.model;

import lombok.Data;

@Data
public class IdentificationData {

    private String clientSessionId;
    private String clientTransactionId;
    private String clientSegment;
    private String orgName;
    // TODO: IMPORTANT!!! If set sessionId set, RSA will perform matching verification
    private String sessionId;
    private String txnId;
    private String userCountry;
    private String userLanguage;
    private String userLoginName;
    private String username;
}
