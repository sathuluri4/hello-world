package com.m2u.rsa.utils;

import com.m2u.common.utils.StringUtils;
import com.m2u.rsa.config.AdaptConfiguration;
import com.rsa.csd.ws.*;

public class AdaptMessageHelper {

    private AdaptMessageHelper() {}

    public static MessageHeader createMessageHeader(String requestId, RequestType requestType, String timeStamp) {
        String api = AdaptConfiguration.getProperty("APITYPE");
        String version = AdaptConfiguration.getProperty("VERSION");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setApiType(APIType.fromValue(api));
        messageHeader.setRequestId(requestId);
        messageHeader.setRequestType(requestType);
        messageHeader.setTimeStamp(timeStamp);
        messageHeader.setVersion(MessageVersion.fromString(version));

        return messageHeader;
    }

    public static IdentificationData createIdentificationData(
        String clientSessionId, String clientTransactionId, String groupName,
        String orgName, String sessionId, String transactionId, String userCountry,
        String userLanguage, String userLoginName, String userName, UserStatus userStatus,
        WSUserType userType) {

        IdentificationData identificationData = new IdentificationData();
        identificationData.setClientSessionId(clientSessionId);
        identificationData.setClientTransactionId(clientTransactionId);
        identificationData.setGroupName(groupName);
        identificationData.setOrgName(orgName);
        identificationData.setSessionId(sessionId);
        identificationData.setTransactionId(transactionId);
        identificationData.setUserCountry(userCountry);
        identificationData.setUserLanguage(userLanguage);
        identificationData.setUserLoginName(userLoginName);
        identificationData.setUserName(userName);
        identificationData.setUserStatus(userStatus);
        identificationData.setUserType(userType);

        return identificationData;
    }

    public static DeviceRequest createDeviceRequest(
        String devicePrint, String deviceTokenCookie, String deviceTokenFSO, String httpAccept,
        String httpAcceptChars, String httpAcceptEncoding, String httpAcceptLanguage,
        String httpReferrer, String ipAddress, String userAgent) {

        DeviceRequest deviceRequest = new DeviceRequest();

        if (!StringUtils.isEmptyString(devicePrint)) {
            deviceRequest.setDevicePrint(devicePrint);
        }

        deviceRequest.setDeviceTokenCookie(deviceTokenCookie);
        deviceRequest.setDeviceTokenFSO(deviceTokenFSO);
        deviceRequest.setHttpAccept(httpAccept);
        deviceRequest.setHttpAcceptChars(httpAcceptChars);
        deviceRequest.setHttpAcceptEncoding(httpAcceptEncoding);
        deviceRequest.setHttpAcceptLanguage(httpAcceptLanguage);
        deviceRequest.setHttpReferrer(httpReferrer);
        deviceRequest.setIpAddress(ipAddress);
        deviceRequest.setUserAgent(userAgent);

        return deviceRequest;
    }

    public static DeviceRequest createDeviceRequest(
        String devicePrint, String deviceTokenCookie, String deviceTokenFSO, String httpAccept,
        String httpAcceptChars, String httpAcceptEncoding, String httpAcceptLanguage,
        String httpReferrer, String ipAddress, String userAgent,
        String domElements, String jsEvents, String pageId) {

        DeviceRequest deviceRequest = new DeviceRequest();

        if (!StringUtils.isEmptyString(devicePrint)) {
            deviceRequest.setDevicePrint(devicePrint);
        }

        deviceRequest.setDeviceTokenCookie(deviceTokenCookie);
        deviceRequest.setDeviceTokenFSO(deviceTokenFSO);
        deviceRequest.setHttpAccept(httpAccept);
        deviceRequest.setHttpAcceptChars(httpAcceptChars);
        deviceRequest.setHttpAcceptEncoding(httpAcceptEncoding);
        deviceRequest.setHttpAcceptLanguage(httpAcceptLanguage);
        deviceRequest.setHttpReferrer(httpReferrer);
        deviceRequest.setIpAddress(ipAddress);
        deviceRequest.setUserAgent(userAgent);
        deviceRequest.setDomElements(domElements);
        deviceRequest.setJsEvents(jsEvents);
        deviceRequest.setPageId(pageId);

        return deviceRequest;
    }

    public static SecurityHeader createSecurityHeader() {
        String callerCredential = AdaptConfiguration.getProperty("CREDENTIAL");
        String callerId = AdaptConfiguration.getProperty("CALLERID");
        String method = AdaptConfiguration.getProperty("METHOD");

        SecurityHeader securityHeader = new SecurityHeader();

        securityHeader.setCallerCredential(callerCredential);
        securityHeader.setCallerId(callerId);
        securityHeader.setMethod(AuthorizationMethod.fromValue(method));

        return securityHeader;
    }

    public static EventDataList createEventDataList(String eventDescription, EventType eventType) {
        EventData eventData = new EventData();
        eventData.setEventDescription(eventDescription);
        eventData.setEventType(eventType);

        EventDataList eventDataList = new EventDataList();
        EventData[] edArray = { eventData };
        eventDataList.setEventData(edArray);

        return eventDataList;
    }

    public static EventDataList createEventDataList(
        String eventDescription, EventType eventType, String clientDefinedEventType) {

        EventData eventData = new EventData();
        eventData.setEventDescription(eventDescription);
        eventData.setEventType(eventType);
        eventData.setClientDefinedEventType(clientDefinedEventType);

        EventDataList eventDataList = new EventDataList();
        EventData[] edArray = { eventData };
        eventDataList.setEventData(edArray);

        return eventDataList;
    }

    public static EventDataList createEventDataList(
        String eventDescription, EventType eventType, TransactionData transactionData) {

        EventData eventData = new EventData();
        eventData.setEventDescription(eventDescription);
        eventData.setEventType(eventType);
        eventData.setTransactionData(transactionData);

        EventDataList eventDataList = new EventDataList();
        EventData[] edArray = { eventData };
        eventDataList.setEventData(edArray);

        return eventDataList;
    }

    public static EventDataList createEventDataList(
        String eventDescription, EventType eventType,
        String clientDefinedEventType, TransactionData transactionData) {

        EventData eventData = new EventData();
        eventData.setEventDescription(eventDescription);
        eventData.setEventType(eventType);
        eventData.setClientDefinedEventType(clientDefinedEventType);
        eventData.setTransactionData(transactionData);

        EventDataList eventDataList = new EventDataList();
        EventData[] edArray = { eventData };
        eventDataList.setEventData(edArray);

        return eventDataList;
    }

    public static EventDataList createEventDataList(
        String eventDescription, EventType eventType,
        String clientDefinedEventType, TransactionData transactionData,
        FactList factList ) {

        EventData eventData = new EventData();
        eventData.setEventDescription(eventDescription);
        eventData.setEventType(eventType);
        eventData.setClientDefinedAttributeList(factList);
        eventData.setClientDefinedEventType(clientDefinedEventType);
        eventData.setTransactionData(transactionData);

        EventDataList eventDataList = new EventDataList();
        EventData[] edArray = { eventData };
        eventDataList.setEventData(edArray);

        return eventDataList;
    }

    public static EventDataList createEventDataList(
        String eventDescription, EventType eventType,
        TransactionData transactionData, FactList factList ) {

        EventData eventData = new EventData();
        eventData.setEventDescription(eventDescription);
        eventData.setEventType(eventType);
        eventData.setClientDefinedAttributeList(factList);
        eventData.setTransactionData(transactionData);

        EventDataList eventDataList = new EventDataList();
        EventData[] edArray = { eventData };
        eventDataList.setEventData(edArray);

        return eventDataList;
    }

    public static UserData createUserData(
        Boolean business, String lastAccountOpenDate, String lastOnlineServicePasswordChangeDate,
        String onlineServiceEnrollDate, Amount totalAvailableBalance, Amount totalCreditLimit,
        Amount totalCreditsUsed, UserAddress userAddress, UserName userNameData, Boolean vip) {

        UserData userData = new UserData();
        userData.setBusiness(business);
        userData.setLastAccountOpenDate(lastAccountOpenDate);
        userData.setLastOnlineServicePasswordChangeDate(lastOnlineServicePasswordChangeDate);
        userData.setOnlineServiceEnrollDate(onlineServiceEnrollDate);
        userData.setTotalAvailableBalance(totalAvailableBalance);
        userData.setTotalCreditLimit(totalCreditLimit);
        userData.setTotalCreditsUsed(totalCreditsUsed);
        userData.setUserAddress(userAddress);
        userData.setUserNameData(userNameData);
        userData.setVIP(vip);

        return userData;
    }

    public static GenericActionTypeList createGenericActionType(GenericActionType[] gatArray) {
        GenericActionTypeList genericActionTypeList = new GenericActionTypeList();
        genericActionTypeList.setGenericActionTypes(gatArray);

        return genericActionTypeList;
    }
}
