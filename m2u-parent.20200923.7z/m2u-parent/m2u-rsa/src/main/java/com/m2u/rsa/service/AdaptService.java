package com.m2u.rsa.service;

import com.m2u.rsa.dto.AdaptCreateUserRequestDTO;
import com.m2u.rsa.dto.AdaptCreateUserResponseDTO;
import com.m2u.rsa.dto.AdaptNotifyRequestDTO;
import com.m2u.rsa.dto.AdaptNotifyResponseDTO;
import com.m2u.rsa.exception.AdaptException;

public interface AdaptService {

    AdaptNotifyResponseDTO notify(AdaptNotifyRequestDTO req) throws AdaptException;
    AdaptCreateUserResponseDTO createUser(AdaptCreateUserRequestDTO req) throws AdaptException;
}
