package com.m2u.rsa.notify;

import com.m2u.rsa.dto.AdaptNotifyRequestDTO;
import com.m2u.rsa.enums.AdaptServiceName;
import com.m2u.rsa.exception.AdaptException;
import com.rsa.csd.ws.EventType;
import com.rsa.csd.ws.UserData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
public class AttemptLoginUsernameNotify extends AbstractNotify {
	private UserData userData;

	public AttemptLoginUsernameNotify(AdaptNotifyRequestDTO req, AdaptServiceName adaptServiceName) throws AdaptException {
		super(req, adaptServiceName);

		if(EventType.SESSION_SIGNIN.equals(adaptServiceName.getEventType())){
			userData = new UserData();
			userData.setLastAccountOpenDate(getSdf());
			getNotifyRequest().setUserData(userData);
		}
	}
}
