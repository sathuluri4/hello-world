package com.m2u.rsa.createuser;

import com.m2u.rsa.common.AbstractAdapt;
import com.m2u.rsa.config.AdaptConfiguration;
import com.m2u.rsa.dto.AdaptCreateUserRequestDTO;
import com.m2u.rsa.enums.AdaptServiceName;
import com.m2u.rsa.exception.AdaptException;
import com.rsa.csd.ws.CreateUserRequest;
import com.rsa.csd.ws.CreateUserResponse;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
public abstract class AbstractCreateUser extends AbstractAdapt<CreateUserResponse> {
    private CreateUserRequest createUserRequest;
    private CreateUserResponse createUserResponse;

    public AbstractCreateUser(AdaptCreateUserRequestDTO req, AdaptServiceName adaptServiceName) throws AdaptException {
        super(req, adaptServiceName);

        createUserRequest = new CreateUserRequest();
        createUserRequest.setActionTypeList(getGenericActionTypeList());
        createUserRequest.setDeviceRequest(getDeviceRequest());
        createUserRequest.setIdentificationData(getIdentificationData());
        createUserRequest.setMessageHeader(getMessageHeader());
        createUserRequest.setSecurityHeader(getSecurityHeader());
        createUserRequest.setChannelIndicator(getChannelIndicatorType());
        createUserRequest.setRunRiskType(adaptServiceName.getRunRiskType());
    }

    @Override
    public CreateUserResponse invoke() throws AdaptException {
        try {
            createUserResponse = AdaptConfiguration.getInvoker().createUser(createUserRequest);
            return createUserResponse;
        } catch (Exception e) {
            String errorDetails = String.format("Failed to send notify request with sessionId [%s] eventDesc [%s] eventType [%s]",
                getReq().getSessionId(), getReq().getEventDesc(), getAdaptServiceName().getEventType());
            log.error(errorDetails, e);
            throw new AdaptException(errorDetails, e);
        }
    }
}
