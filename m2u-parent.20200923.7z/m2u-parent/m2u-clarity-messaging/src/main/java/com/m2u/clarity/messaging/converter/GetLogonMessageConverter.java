package com.m2u.clarity.messaging.converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.GetLogonRequestDTO;
import com.m2u.clarity.messaging.dto.GetLogonResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.ClarityCommonProperties;
import com.m2u.clarity.messaging.properties.GetLogonProperties;
import com.m2u.clarity.messaging.utils.ClarityMessagingUtils;
import com.m2u.clarity.messaging.utils.JposUtils;
import lombok.extern.slf4j.Slf4j;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component("GetLogonMessageConverter")
public class GetLogonMessageConverter extends AbstractMessageConverter implements MessageConverter<GetLogonRequestDTO, GetLogonResponseDTO> {

    @Autowired
    private ClarityCommonProperties clarityCommonProp;

    @Autowired
    private GetLogonProperties getLogonProp;

    private GenericPackager packager;
    private GenericPackager packagerSsi03;

    @Autowired
    public GetLogonMessageConverter(
        @Value("${m2u.clarity.messaging.jpos.packager.get-logon.default}") String packagerConfig,
        @Value("${m2u.clarity.messaging.jpos.packager.get-logon.03}") String packagerSsi03Config) throws ClarityMessagingException {

        this.packager = JposUtils.setupPackager(packagerConfig);
        this.packagerSsi03 = JposUtils.setupPackager(packagerSsi03Config);
    }

    @Override
    public String convertRequestMessage(GetLogonRequestDTO request) throws ClarityMessagingException {
        try {
            StringBuilder convertedMessage = new StringBuilder();
            GetLogonProperties.Request reqConfig = getLogonProp.getRequest();
            GetLogonProperties.RequestDataElement reqDataElement = reqConfig.getDataElement();
            GetLogonProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();

            // Validating request data before proceed further
            validateRequestData(request);

            // Generate request message wrapper
            String messageType = reqConfig.getMessageTypes().get(request.getSubServiceId());
            String reqMessageWrapper = ClarityMessagingUtils.generateReqMessageWrapper(request, messageType);
            convertedMessage.append(reqMessageWrapper);

            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(getRequestPackager(request.getSubServiceId()));
            isoMsg.set(0, reqConfig.getMessageTypeId());
            // PrimaryBitmap is calculate and set by JPOS during packing
            isoMsg.set(2, request.getPan());
            isoMsg.set(3, reqDataElement.getProcessingCodes().get(request.getCountryCode()));
            isoMsg.set(22, reqDataElement.getPointOfServices().get(request.getCountryCode()));
            isoMsg.set(37, reqDataElement.getRetrievalRefNo());
            isoMsg.set(41, reqDataElement.getTerminalIds().get(request.getCountryCode()));

            if ("01".equals(request.getSubServiceId()) || "02".equals(request.getSubServiceId())) {
                isoMsg.set(52, request.getClearPin());
            }

            StringBuilder additionalData = new StringBuilder();
            String serviceCodeKey = getServiceCodeKey(request);

            // Always set occurrences size to 1
            additionalData
                    .append(reqAdditionalData.getServiceCodes().get(serviceCodeKey))
                    .append("01")
                    .append(request.getSubServiceId());
            isoMsg.set(61, additionalData.toString());

            // Call jPOS to generate ISO8583 message
            convertedMessage.append(new String(isoMsg.pack()));
            return convertedMessage.toString();
        } catch (ISOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                    request.getTxnRefId(),
                    ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getCode(),
                    ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }

    @Override
    public GetLogonResponseDTO convertResponseMessage(GetLogonRequestDTO request, String response) throws ClarityMessagingException {
        try {
            StringBuilder strB = new StringBuilder(response);

            // Parse response message wrapper
            GetLogonResponseDTO getLogonResponseDTO = parseRespMessageWrapper(request, GetLogonResponseDTO.class, response, strB);

            // Replace dummy primary bitmap responded from CLARITY, jPOS need actual primary bitmap for parsing message
            replaceRespBitmaps(request, response, getLogonProp.getResponse().getPrimaryBitmap(), strB);

            // Parse ISO8583 message
            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.unpack(strB.toString().getBytes());

            getLogonResponseDTO.setSystemAuditTrailNo(isoMsg.getString(11));
            getLogonResponseDTO.setDateTime(isoMsg.getString(12));
            getLogonResponseDTO.setRetrievalRefNo(isoMsg.getString(37));
            getLogonResponseDTO.setActionCode(isoMsg.getString(39));
            getLogonResponseDTO.setTerminalId(isoMsg.getString(41));

            String bit62Data = isoMsg.getString(62);
            Map<String, Object> dataMap = null;
            if (null != bit62Data && bit62Data.length() > 0) {
                StringBuilder strB62 = new StringBuilder(bit62Data);
                List<Map<String, Object>> dataList = parseRespFields(request, getLogonProp.getResponse().getAdditionalData().get(request.getSubServiceId()), bit62Data, strB62);

                // Always take the first index for root object
                dataMap = dataList.get(0);
            } else {
                dataMap = new HashMap<>(0);
            }

            ObjectMapper mapper = new ObjectMapper();
            // Updating values to existing object
            mapper.readerForUpdating(getLogonResponseDTO).readValue(mapper.writeValueAsBytes(dataMap));

            return getLogonResponseDTO;

        } catch (ISOException | IOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                    request.getTxnRefId(),
                    ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getCode(),
                    ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }

    private GenericPackager getRequestPackager(String subServiceId) {
        if ("03".equals(subServiceId)) {
            // SSI03 need packager with Clear PIN skip
            return packagerSsi03;
        } else {
            return packager;
        }
    }

    private String getServiceCodeKey(GetLogonRequestDTO request) {
        if (null != request.getServiceCode()) {
            // If service code provide, append it to country for lookup later, e.g. SGFT-LOA
            return String.format("%s%s", request.getCountryCode(), request.getServiceCode());
        } else {
            return request.getCountryCode();
        }
    }

    private void validateRequestData(GetLogonRequestDTO request) throws ClarityMessagingException {
        GetLogonProperties.RequestDataElement reqDataElement = getLogonProp.getRequest().getDataElement();
        GetLogonProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();

        validateDataAgainstMap(request, reqDataElement.getProcessingCodes(), request.getCountryCode(), "ProcessingCode");
        validateDataAgainstMap(request, reqDataElement.getPointOfServices(), request.getCountryCode(), "PointOfService");
        validateDataAgainstMap(request, reqDataElement.getTerminalIds(), request.getCountryCode(), "TerminalId");

        // Validate Additional Data
        validateDataAgainstList(request, reqAdditionalData.getSubServiceIds(), request.getSubServiceId(), "SubServiceId");

        if (("01".equals(request.getSubServiceId()) || "02".equals(request.getSubServiceId()))
                && null == request.getClearPin()) {
            String errorDetails = String.format("Clear PIN is compulsory for SubServiceId [%s]. txnRefId [%s]", request.getSubServiceId(), request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        String serviceCodeKey = getServiceCodeKey(request);
        if (null == reqAdditionalData.getServiceCodes().get(serviceCodeKey)) {
            String errorDetails = String.format("Unsupported ServiceCode [%s]. txnRefId [%s]", serviceCodeKey, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        validateDataAgainstList(request, reqAdditionalData.getSubServiceIds(), request.getSubServiceId(), "ServiceCode");
    }
}