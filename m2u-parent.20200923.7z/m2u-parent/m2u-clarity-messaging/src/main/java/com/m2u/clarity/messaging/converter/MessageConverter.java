package com.m2u.clarity.messaging.converter;

import com.m2u.clarity.messaging.dto.AbstractRequestDTO;
import com.m2u.clarity.messaging.dto.AbstractResponseDTO;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;

public interface MessageConverter<T extends AbstractRequestDTO, S extends AbstractResponseDTO> {

    String convertRequestMessage(T request) throws ClarityMessagingException;
    S convertResponseMessage(T request, String response) throws ClarityMessagingException;
}
