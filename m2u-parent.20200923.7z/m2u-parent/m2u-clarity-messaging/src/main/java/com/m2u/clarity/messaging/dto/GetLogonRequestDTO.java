package com.m2u.clarity.messaging.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;

@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class GetLogonRequestDTO extends AbstractRequestDTO {

    protected String subServiceId;
    private String clearPin;
    private String serviceCode;
}
