package com.m2u.clarity.messaging.dto;

import lombok.Data;

@Data
public abstract class AbstractResponseDTO {

    protected String txnRefId;
    protected String systemAuditTrailNo;
    protected String dateTime;
    protected String actionCode;
    protected String sessionId;
    protected String terminalId;
    protected String receiptNo;
    protected String responseCode;
    protected String responseDesc;
    protected String errorCode;
    protected String errorDesc;
}
