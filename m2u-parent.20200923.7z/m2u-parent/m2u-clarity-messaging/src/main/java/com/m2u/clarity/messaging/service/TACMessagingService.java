package com.m2u.clarity.messaging.service;

import com.m2u.clarity.messaging.dto.CreateTACRequestDTO;
import com.m2u.clarity.messaging.dto.CreateTACResponseDTO;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;

public interface TACMessagingService {

    CreateTACResponseDTO createTAC(CreateTACRequestDTO request) throws ClarityMessagingException;
}
