package com.m2u.clarity.messaging.constants;

public final class ClarityMessaging {

    private ClarityMessaging() {}

    // Request Message Wrapper
    public static final String REQ_MSG_WRAPPER_PREFIX = "prefix";
    public static final String REQ_MSG_WRAPPER_APP_ID = "appId";
    public static final String REQ_MSG_WRAPPER_SRC_ID = "srcId";
    public static final String REQ_MSG_WRAPPER_DEST_ID = "destId";
    public static final String REQ_MSG_WRAPPER_MSG_STAT = "msgStat";
    public static final String REQ_MSG_WRAPPER_SESSION_ID = "sessionId";
    public static final String REQ_MSG_WRAPPER_RESERVE = "reserve";

    // Common
    public static final String END_OF_MESSAGE = "FF";
}
