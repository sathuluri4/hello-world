package com.m2u.clarity.messaging.exception;

import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;

public class ClarityMessagingException extends Exception {

    private final ClarityMessagingStatus statusCode;

    public ClarityMessagingException(ClarityMessagingStatus statusCode, String errorDetails) {
        super(statusCode.getDesc().concat(". ").concat(errorDetails));
        this.statusCode = statusCode;
    }

    public ClarityMessagingException(ClarityMessagingStatus statusCode, String errorDetails, Throwable cause) {
        super(statusCode.getDesc().concat(". ").concat(errorDetails), cause);
        this.statusCode = statusCode;
    }

    public ClarityMessagingStatus getStatusCode() {
        return statusCode;
    }
}
