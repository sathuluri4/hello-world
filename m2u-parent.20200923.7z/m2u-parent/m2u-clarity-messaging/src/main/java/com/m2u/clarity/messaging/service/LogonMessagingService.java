package com.m2u.clarity.messaging.service;

import com.m2u.clarity.messaging.dto.GetLogonRequestDTO;
import com.m2u.clarity.messaging.dto.GetLogonResponseDTO;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;

public interface LogonMessagingService {

    GetLogonResponseDTO getLogon(GetLogonRequestDTO request) throws ClarityMessagingException;
}
