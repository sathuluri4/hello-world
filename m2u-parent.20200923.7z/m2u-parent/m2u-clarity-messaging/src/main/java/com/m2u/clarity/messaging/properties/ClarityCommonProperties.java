package com.m2u.clarity.messaging.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ConfigurationProperties(prefix="m2u.clarity.messaging.common")
@Data
public class ClarityCommonProperties {

    private Map<String, String> reqMsgWrapper = new HashMap<>();
    private List<Field> respMsgWrapper = new ArrayList<>();
}
