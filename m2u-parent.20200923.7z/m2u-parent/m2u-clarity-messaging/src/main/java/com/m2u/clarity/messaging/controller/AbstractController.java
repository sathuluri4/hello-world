package com.m2u.clarity.messaging.controller;

import com.m2u.clarity.messaging.constants.ClarityMessaging;
import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.AbstractRequestDTO;
import com.m2u.clarity.messaging.dto.AbstractResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.properties.ClarityCommonProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.lang.reflect.InvocationTargetException;

@Slf4j
public abstract class AbstractController {

    @Autowired
    private ClarityCommonProperties clarityCommonProp;

    protected <T> T createErrorResponse(Class<T> type, AbstractRequestDTO request, ClarityMessagingStatus statusCode, String errorDetails) {
        AbstractResponseDTO response = null;
        try {
            Class<AbstractResponseDTO> errorClass = (Class<AbstractResponseDTO>) Class.forName(type.getName());
            response = errorClass.getDeclaredConstructor().newInstance();

            response.setTxnRefId(request.getTxnRefId());
            response.setDateTime(request.getCreationDateTime());
            // If error happened set to use ReqMsgWrapper Session ID
            response.setSessionId(clarityCommonProp.getReqMsgWrapper().get(ClarityMessaging.REQ_MSG_WRAPPER_SESSION_ID));
            response.setErrorCode(statusCode.getCode());
            response.setErrorDesc(errorDetails);
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.UNEXPECTED_EXCEPTION.getCode(),
                ClarityMessagingStatus.UNEXPECTED_EXCEPTION.getDesc(), e);
        }
        return (T) response;
    }
}
