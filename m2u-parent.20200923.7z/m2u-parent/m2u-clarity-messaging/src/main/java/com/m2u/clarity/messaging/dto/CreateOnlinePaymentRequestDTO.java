package com.m2u.clarity.messaging.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;

@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CreateOnlinePaymentRequestDTO extends AbstractRequestDTO {

    private String txnAmount;
    private Integer tacLength;
    private String tac;
    private String serviceRestrictCode;
    private String txnCurrencyCode;
    private String effectiveDate;
    private String fromAcctNo;
    private String toAcctNo;
    private String serviceCode;
    private String fromAcctCode;
    private String toAcctCode;
    private String payeeCode;
    private String refNo;
    private String thirdPartyAcctNo;
    private String billAcctNo;
    private String recipientRef;
    private String otherPaymentDesc;
    private String smsAlertBit;
    private String smsUserId;
    private String selfNotifMobileNo;
    private String thirdPartyNotifMobileNo;
}
