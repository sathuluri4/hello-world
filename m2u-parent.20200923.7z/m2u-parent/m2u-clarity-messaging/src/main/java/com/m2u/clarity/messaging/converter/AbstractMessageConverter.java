package com.m2u.clarity.messaging.converter;

import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.AbstractRequestDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.Field;
import com.m2u.clarity.messaging.utils.ClarityMessagingUtils;
import com.m2u.clarity.messaging.utils.Iso8583Utils;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

@Slf4j
public abstract class AbstractMessageConverter {

    public void validateDataAgainstMap(AbstractRequestDTO request, Map<String, String> mapData, String compareData, String name) throws ClarityMessagingException {
        if(null == mapData.get(compareData)) {
            String errorDetails = String.format("Unsupported %s [%s]. txnRefId [%s]", name, compareData, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }
    }

    public void validateDataAgainstList(AbstractRequestDTO request, List<String> listData, String compareData, String name) throws ClarityMessagingException {
        if (!listData.contains(compareData)) {
            String errorDetails = String.format("Unsupported %s [%s]. txnRefId [%s]", name, compareData, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }
    }

    public void validateDataAgainstDateFormat(AbstractRequestDTO request, String format, String compareData, String name) throws ClarityMessagingException {
        try {
            // Check to ensure date time in right format
            SimpleDateFormat formatter = new SimpleDateFormat(format);
            formatter.setLenient(false);
            formatter.parse(compareData);
        } catch (ParseException e) {
            String errorDetails = String.format("Invalid %s detected [%s], failed to parse to format [%s]. txnRefId [%s]", name, compareData, format, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(), errorDetails, e);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails, e);
        }
    }

    public <T> T parseRespMessageWrapper(AbstractRequestDTO request, Class<T> type, String response, StringBuilder strB) throws ClarityMessagingException {
        T t = null;
        try {
            t = ClarityMessagingUtils.parseRespMessageWrapper(type, strB);
        } catch (ClarityMessagingException e) {
            String errorDetails = String.format("Failed to parse response message wrapper from response [%s]. txnRefId [%s]", response, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_RESPONSE_DATA.getCode(),
                ClarityMessagingStatus.INVALID_RESPONSE_DATA.getDesc(),
                errorDetails, e);
            throw e;
        }
        return t;
    }

    public void replaceRespBitmaps(AbstractRequestDTO request, String response, String primaryBitmap, StringBuilder strB) throws ClarityMessagingException {
        try {
            Iso8583Utils.replaceBitmaps(strB, primaryBitmap);
        } catch (ClarityMessagingException e) {
            String errorDetails = String.format("Failed to replace bitmaps from response [%s]. txnRefId [%s]", response, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_RESPONSE_DATA.getCode(),
                ClarityMessagingStatus.INVALID_RESPONSE_DATA.getDesc(),
                errorDetails, e);
            throw e;
        }
    }

    public List<Map<String, Object>> parseRespFields(AbstractRequestDTO request, List<Field> fields, String data, StringBuilder strB) throws ClarityMessagingException {
        List<Map<String, Object>> dataList = null;
        try {
            dataList = Iso8583Utils.parseFields(strB, fields, 1);
        } catch (ClarityMessagingException e) {
            String errorDetails = String.format("Failed to parse data [%s]. txnRefId [%s]", data, request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_RESPONSE_DATA.getCode(),
                ClarityMessagingStatus.INVALID_RESPONSE_DATA.getDesc(),
                errorDetails, e);
            throw e;
        }
        return dataList;
    }
}
