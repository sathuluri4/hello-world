package com.m2u.clarity.messaging.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ConfigurationProperties(prefix="m2u.clarity.messaging.get-account-details")
@Data
public class GetAccountDetailsProperties {

    private final Request request = new Request();
    private final Response response = new Response();

    @Data
    public static class Request {
        private String messageType;
        private String messageTypeId;
        private RequestDataElement dataElement;
    }

    @Data
    public static class RequestDataElement {
        private Map<String, String> processingCodes = new HashMap<>();
        private Map<String, String> pointOfServices = new HashMap<>();
        private String retrievalRefNo;
        private Map<String, String> terminalIds = new HashMap<>();
        private RequestAdditionalData additionalData;
    }

    @Data
    public static class RequestAdditionalData {
        private String serviceCode;
        private Field subServiceCode;
        private Field accountType;
        private Field accountNo;
        private Field fdCertificateNo;
        private Field currencyCode;
        private List<String> creditCardType = new ArrayList<>();
    }

    @Data
    public static class Response {
        private String primaryBitmap;
        private List<Field> additionalData = new ArrayList<>();
    }
}
