package com.m2u.clarity.messaging.service;

import com.m2u.clarity.messaging.dto.GetAccountDetailsRequestDTO;
import com.m2u.clarity.messaging.dto.GetAccountDetailsResponseDTO;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;

public interface AccountDetailsMessagingService {

    GetAccountDetailsResponseDTO getAccountDetails(GetAccountDetailsRequestDTO request) throws ClarityMessagingException;
}
