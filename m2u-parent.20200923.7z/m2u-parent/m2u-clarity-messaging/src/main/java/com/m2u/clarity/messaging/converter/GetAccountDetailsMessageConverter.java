package com.m2u.clarity.messaging.converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.GetAccountDetailsRequestDTO;
import com.m2u.clarity.messaging.dto.GetAccountDetailsResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.ClarityCommonProperties;
import com.m2u.clarity.messaging.properties.GetAccountDetailsProperties;
import com.m2u.clarity.messaging.utils.ClarityMessagingUtils;
import com.m2u.clarity.messaging.utils.Iso8583Utils;
import com.m2u.clarity.messaging.utils.JposUtils;
import lombok.extern.slf4j.Slf4j;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component("GetAccountDetailsMessageConverter")
public class GetAccountDetailsMessageConverter extends AbstractMessageConverter implements MessageConverter<GetAccountDetailsRequestDTO, GetAccountDetailsResponseDTO> {

    @Autowired
    private ClarityCommonProperties clarityCommonProp;

    @Autowired
    private GetAccountDetailsProperties getAccountDetailsProp;

    private GenericPackager packager;

    @Autowired
    public GetAccountDetailsMessageConverter(
        @Value("${m2u.clarity.messaging.jpos.packager.get-account-details.default}") String packagerConfig) throws ClarityMessagingException {

        this.packager = JposUtils.setupPackager(packagerConfig);
    }

    @Override
    public String convertRequestMessage(GetAccountDetailsRequestDTO request) throws ClarityMessagingException {
        try {
            StringBuilder convertedMessage = new StringBuilder();
            GetAccountDetailsProperties.Request reqConfig = getAccountDetailsProp.getRequest();
            GetAccountDetailsProperties.RequestDataElement reqDataElement = reqConfig.getDataElement();
            GetAccountDetailsProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();

            // Validating request data before proceed further
            validateRequestData(request);
            // Update request data, e.g. replace with default values, padding, etc
            updateRequestData(request);

            // Generate request message wrapper
            String messageType = reqConfig.getMessageType();
            String reqMessageWrapper = ClarityMessagingUtils.generateReqMessageWrapper(request, messageType);
            convertedMessage.append(reqMessageWrapper);

            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.set(0, reqConfig.getMessageTypeId());
            // PrimaryBitmap is calculate and set by JPOS during packing
            isoMsg.set(2, request.getPan());
            isoMsg.set(3, reqDataElement.getProcessingCodes().get(request.getCountryCode()));
            isoMsg.set(22, reqDataElement.getPointOfServices().get(request.getCountryCode()));
            isoMsg.set(37, reqDataElement.getRetrievalRefNo());
            isoMsg.set(41, reqDataElement.getTerminalIds().get(request.getCountryCode()));

            StringBuilder additionalData = new StringBuilder();

            additionalData
                .append(reqAdditionalData.getServiceCode())
                .append(request.getSubServiceCode())
                .append(request.getAccountType())
                .append(request.getAccountNo())
                .append(request.getFdCertificateNo())
                .append(request.getCurrencyCode())
                .append(request.getCreditCardType());
            isoMsg.set(61, additionalData.toString());

            // Call jPOS to generate ISO8583 message
            convertedMessage.append(new String(isoMsg.pack()));
            return convertedMessage.toString();
        } catch (ISOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getCode(),
                ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }
    
    @Override
    public GetAccountDetailsResponseDTO convertResponseMessage(GetAccountDetailsRequestDTO request, String response) throws ClarityMessagingException {
        try {
            StringBuilder strB = new StringBuilder(response);

            // Parse response message wrapper
            GetAccountDetailsResponseDTO getAccountDetailsResponseDTO = parseRespMessageWrapper(request, GetAccountDetailsResponseDTO.class, response, strB);

            // Replace dummy primary bitmap responded from CLARITY, jPOS need actual primary bitmap for parsing message
            replaceRespBitmaps(request, response, getAccountDetailsProp.getResponse().getPrimaryBitmap(), strB);

            // Parse ISO8583 message
            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.unpack(strB.toString().getBytes());

            getAccountDetailsResponseDTO.setSystemAuditTrailNo(isoMsg.getString(11));
            getAccountDetailsResponseDTO.setDateTime(isoMsg.getString(12));
            getAccountDetailsResponseDTO.setRetrievalRefNo(isoMsg.getString(37));
            getAccountDetailsResponseDTO.setActionCode(isoMsg.getString(39));
            getAccountDetailsResponseDTO.setTerminalId(isoMsg.getString(41));

            String bit62Data = isoMsg.getString(62);
            Map<String, Object> dataMap = null;
            if (null != bit62Data && bit62Data.length() > 0) {
                StringBuilder strB62 = new StringBuilder(bit62Data);
                List<Map<String, Object>> dataList = parseRespFields(request, getAccountDetailsProp.getResponse().getAdditionalData(), bit62Data, strB62);

                // Always take the first index for root object
                dataMap = dataList.get(0);
            } else {
                dataMap = new HashMap<>(0);
            }

            ObjectMapper mapper = new ObjectMapper();
            // Updating values to existing object
            mapper.readerForUpdating(getAccountDetailsResponseDTO).readValue(mapper.writeValueAsBytes(dataMap));

            return getAccountDetailsResponseDTO;

        } catch (ISOException | IOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getCode(),
                ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }

    private void validateRequestData(GetAccountDetailsRequestDTO request) throws ClarityMessagingException {
        GetAccountDetailsProperties.RequestDataElement reqDataElement = getAccountDetailsProp.getRequest().getDataElement();
        GetAccountDetailsProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();

        validateDataAgainstMap(request, reqDataElement.getProcessingCodes(), request.getCountryCode(), "ProcessingCode");
        validateDataAgainstMap(request, reqDataElement.getPointOfServices(), request.getCountryCode(), "PointOfService");
        validateDataAgainstMap(request, reqDataElement.getTerminalIds(), request.getCountryCode(), "TerminalId");

        // Validate Additional Data
        validateDataAgainstList(request, reqAdditionalData.getCreditCardType(), request.getCreditCardType(), "CreditCardType");
        Iso8583Utils.validateField(request.getSubServiceCode(), reqAdditionalData.getSubServiceCode());
        Iso8583Utils.validateField(request.getAccountType(), reqAdditionalData.getAccountType());
        Iso8583Utils.validateField(request.getAccountNo(), reqAdditionalData.getAccountNo());
        Iso8583Utils.validateField(request.getFdCertificateNo(), reqAdditionalData.getFdCertificateNo());
        Iso8583Utils.validateField(request.getCurrencyCode(), reqAdditionalData.getCurrencyCode());
    }

    private void updateRequestData(GetAccountDetailsRequestDTO request) {
        GetAccountDetailsProperties.RequestAdditionalData reqAdditionalData = getAccountDetailsProp.getRequest().getDataElement().getAdditionalData();
        request.setAccountType(Iso8583Utils.padFieldData(request.getAccountType(), reqAdditionalData.getAccountType()));
    }
}