package com.m2u.clarity.messaging.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;

@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class GetAccountDetailsRequestDTO extends AbstractRequestDTO {

    private String subServiceCode;
    private String accountType;
    private String accountNo;
    private String fdCertificateNo;
    private String currencyCode;
    private String creditCardType;
}
