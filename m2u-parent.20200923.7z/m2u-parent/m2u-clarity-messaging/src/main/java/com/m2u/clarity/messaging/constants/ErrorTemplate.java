package com.m2u.clarity.messaging.constants;

public final class ErrorTemplate {

    private ErrorTemplate() {}

    public static final String TEMPLATE_1 = "[{}] ErrorCode:: [{}], ErrorDesc:: [{}], Details:: [{}]";
    public static final String TEMPLATE_2 = "[{}] ErrorCode:: [{}], ErrorDesc:: [{}]";
    public static final String TEMPLATE_3 = "ErrorCode:: [{}], ErrorDesc:: [{}], Details:: [{}]";
    public static final String TEMPLATE_4 = "ErrorCode:: [{}], ErrorDesc:: [{}]";
}
