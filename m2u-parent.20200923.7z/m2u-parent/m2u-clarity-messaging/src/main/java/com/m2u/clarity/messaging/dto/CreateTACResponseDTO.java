package com.m2u.clarity.messaging.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;

@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CreateTACResponseDTO extends AbstractResponseDTO {

    private String tacLength;
    private String tac;
    private String mobileNo;
    private String validUntilDate;
    private String validUntilTime;
    private String validityUponUsage;
    private String status;
}
