package com.m2u.clarity.messaging.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ConfigurationProperties(prefix="m2u.clarity.messaging.create-tac")
@Data
public class CreateTACProperties {

    private final Request request = new Request();
    private final Response response = new Response();

    @Data
    public static class Request {
        private String messageType;
        private String messageTypeId;
        private RequestDataElement dataElement;
    }

    @Data
    public static class RequestDataElement {
        private Map<String, String> processingCodes = new HashMap<>();
        private Map<String, String> pointOfServices = new HashMap<>();
        private List<String> serviceRestrictCodes = new ArrayList<>();
        private Map<String, String> terminalIds = new HashMap<>();
        private RequestAdditionalData additionalData;
    }

    @Data
    public static class RequestAdditionalData {
        private String serviceCode;
        private List<String> serviceNames = new ArrayList<>();
        private Field serviceMessage;
        private Field tacServiceCode;
        private Field tacInfo1;
        private Field tacInfo2;
    }

    @Data
    public static class Response {
        private String primaryBitmap;
        private List<Field> additionalData = new ArrayList<>();
    }
}
