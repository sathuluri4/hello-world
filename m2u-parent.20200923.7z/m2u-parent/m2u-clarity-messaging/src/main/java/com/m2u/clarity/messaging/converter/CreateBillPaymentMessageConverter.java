package com.m2u.clarity.messaging.converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.CreateBillPaymentRequestDTO;
import com.m2u.clarity.messaging.dto.CreateBillPaymentResponseDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.ClarityCommonProperties;
import com.m2u.clarity.messaging.properties.CreateBillPaymentProperties;
import com.m2u.clarity.messaging.utils.ClarityMessagingUtils;
import com.m2u.clarity.messaging.utils.DestUtils;
import com.m2u.clarity.messaging.utils.Iso8583Utils;
import com.m2u.clarity.messaging.utils.JposUtils;
import lombok.extern.slf4j.Slf4j;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component("CreateBillPaymentMessageConverter")
public class CreateBillPaymentMessageConverter extends AbstractMessageConverter implements MessageConverter<CreateBillPaymentRequestDTO, CreateBillPaymentResponseDTO> {

    private static final String TODAY_EFFECTIVE_DATE = "00000000";
    
    @Autowired
    private ClarityCommonProperties clarityCommonProp;

    @Autowired
    private CreateBillPaymentProperties createBillPaymentProp;

    private GenericPackager packager;

    @Autowired
    public CreateBillPaymentMessageConverter(
        @Value("${m2u.clarity.messaging.jpos.packager.create-bill-payment.default}") String packagerConfig) throws ClarityMessagingException {

        this.packager = JposUtils.setupPackager(packagerConfig);
    }

    @Override
    public String convertRequestMessage(CreateBillPaymentRequestDTO request) throws ClarityMessagingException {
        try {
            StringBuilder convertedMessage = new StringBuilder();
            CreateBillPaymentProperties.Request reqConfig = createBillPaymentProp.getRequest();
            CreateBillPaymentProperties.RequestDataElement reqDataElement = reqConfig.getDataElement();

            // Validating request data before proceed further
            validateRequestData(request);
            // Update request data, e.g. replace with default values, padding, etc
            updateRequestData(request);

            // Generate request message wrapper
            String messageType = reqConfig.getMessageType();
            String reqMessageWrapper = ClarityMessagingUtils.generateReqMessageWrapper(request, messageType);
            convertedMessage.append(reqMessageWrapper);

            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.set(0, reqConfig.getMessageTypeId());
            // PrimaryBitmap is calculate and set by JPOS during packing
            isoMsg.set(2, request.getPan());
            isoMsg.set(3, reqDataElement.getProcessingCodes().get(request.getCountryCode()));
            isoMsg.set(4, request.getTxnAmount());
            isoMsg.set(22, reqDataElement.getPointOfServices().get(request.getCountryCode()));
            isoMsg.set(27, String.valueOf(request.getTacLength()));
            isoMsg.set(38, request.getTac());
            isoMsg.set(40, request.getServiceRestrictCode());
            isoMsg.set(41, reqDataElement.getTerminalIds().get(request.getCountryCode()));
            isoMsg.set(49, request.getTxnCurrencyCode());

            String billPaymentSize = String.format("%02d", request.getBillPayment().size());

            StringBuilder additionalData = new StringBuilder();
            additionalData
                .append(request.getServiceCodeHead())
                .append(billPaymentSize);

             for(CreateBillPaymentRequestDTO.BillPayment billPayment : request.getBillPayment()) {
                 additionalData
                     .append(billPayment.getServiceCode())
                     .append(billPayment.getFromAcctCode())
                     .append(billPayment.getToAcctCode())
                     .append(billPayment.getPayeeCode())
                     .append(billPayment.getRefNo())
                     .append(billPayment.getIndividualEffectPaymentDate())
                     .append(billPayment.getCurrencyCode())
                     .append(billPayment.getTxnAmount())
                     .append(billPayment.getBillAcctNo())
                     .append(billPayment.getCustName())
                     .append(billPayment.getIcNoBusRegNo())
                     .append(billPayment.getCNo())
                     .append(billPayment.getExpiryDate())
                     .append(billPayment.getCvv());
             }
            isoMsg.set(61, additionalData.toString());

            StringBuilder smsData = new StringBuilder();
            smsData
                .append(request.getSmsAlertBit())
                .append(request.getSmsUserId())
                .append(request.getSelfNotifMobileNo());
            isoMsg.set(63, smsData.toString());

            isoMsg.set(73, request.getEffectiveDate());
            isoMsg.set(102, request.getFromAcctNo());
            isoMsg.set(103, request.getToAcctNo());
            // TODO: Set dummy data to get the correct primary & secondary bitmaps
            isoMsg.set(128, "                ");

            // MAC setup
            String temp = new String(isoMsg.pack());
            // Skip the dummy MAC generated just now
            temp = temp.substring(0, temp.length() - 16);
            String mac = DestUtils.createMAC(temp);
            isoMsg.set(128, mac);
            temp = new String(isoMsg.pack());

            // Call jPOS to generate ISO8583 message
            convertedMessage.append(temp);

            return convertedMessage.toString();

        } catch (ISOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getCode(),
                ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_REQ_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }
    
    @Override
    public CreateBillPaymentResponseDTO convertResponseMessage(CreateBillPaymentRequestDTO request, String response) throws ClarityMessagingException {
        try {
            StringBuilder strB = new StringBuilder(response);

            // Parse response message wrapper
            CreateBillPaymentResponseDTO createBillPaymentResponseDTO = parseRespMessageWrapper(request, CreateBillPaymentResponseDTO.class, response, strB);

            // Replace dummy primary bitmap responded from CLARITY, jPOS need actual primary bitmap for parsing message
            replaceRespBitmaps(request, response, createBillPaymentProp.getResponse().getPrimaryBitmap(), strB);

            // Parse ISO8583 message
            ISOMsg isoMsg = new ISOMsg();
            isoMsg.setPackager(packager);
            isoMsg.unpack(strB.toString().getBytes());

            createBillPaymentResponseDTO.setSystemAuditTrailNo(isoMsg.getString(11));
            createBillPaymentResponseDTO.setDateTime(isoMsg.getString(12));
            createBillPaymentResponseDTO.setActionCode(isoMsg.getString(39));
            createBillPaymentResponseDTO.setTerminalId(isoMsg.getString(41));

            String bit62Data = isoMsg.getString(62);
            Map<String, Object> dataMap = null;
            if(null != bit62Data && bit62Data.length() > 0) {
                StringBuilder strB62 = new StringBuilder(bit62Data);
                List<Map<String, Object>> dataList = parseRespFields(request, createBillPaymentProp.getResponse().getAdditionalData(), bit62Data, strB62);

                // Always take the first index for root object
                dataMap = dataList.get(0);
            } else {
                dataMap = new HashMap<>(0);
            }

            ObjectMapper mapper = new ObjectMapper();
            // Updating values to existing object
            mapper.readerForUpdating(createBillPaymentResponseDTO).readValue(mapper.writeValueAsBytes(dataMap));

            createBillPaymentResponseDTO.setMac(isoMsg.getString(64));

            return createBillPaymentResponseDTO;

        } catch (ISOException | IOException e) {
            log.error(ErrorTemplate.TEMPLATE_2,
                request.getTxnRefId(),
                ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getCode(),
                ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED.getDesc(), e);
            throw new ClarityMessagingException(ClarityMessagingStatus.ISO8583_RESP_MESSAGE_CONVERSION_FAILED, e.getMessage(), e);
        }
    }

    private void validateRequestData(CreateBillPaymentRequestDTO request) throws ClarityMessagingException {
        CreateBillPaymentProperties.RequestDataElement reqDataElement = createBillPaymentProp.getRequest().getDataElement();
        CreateBillPaymentProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();
        CreateBillPaymentProperties.RequestSmsData reqSmsData = reqDataElement.getSmsData();

        validateDataAgainstMap(request, reqDataElement.getProcessingCodes(), request.getCountryCode(), "ProcessingCode");
        validateDataAgainstMap(request, reqDataElement.getPointOfServices(), request.getCountryCode(), "PointOfService");
        validateDataAgainstMap(request, reqDataElement.getTerminalIds(), request.getCountryCode(), "TerminalId");
        validateDataAgainstList(request, reqDataElement.getServiceRestrictCodes(), request.getServiceRestrictCode(), "ServiceRestrictCode");

        if (request.getTacLength() != request.getTac().length()) {
            String errorDetails = String.format("TAC [%s] value length doesn't sync with request TAC length [%s]. txnRefId [%s]", request.getTac(), request.getTacLength(), request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        if(!TODAY_EFFECTIVE_DATE.equals(request.getEffectiveDate())) {
            validateDataAgainstDateFormat(request, "yyyyMMdd",  request.getEffectiveDate(), "EffectiveDate");
        }

        if ((!TODAY_EFFECTIVE_DATE.equals(request.getEffectiveDate())
                && ("1".equals(request.getSmsAlertBit()) || "2".equals(request.getSmsAlertBit())))
                && (null == request.getSmsUserId() || null == request.getSelfNotifMobileNo())) {
            String errorDetails = String.format("SmsUserId and SelfNotifMobileNomust not be NULL. txnRefId [%s]", request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        // Validate Additional Data
        validateAdditionalData(request, reqAdditionalData);

        // Validate SMS Data
        validateSmsData(request, reqSmsData);
        validateDataAgainstList(request, reqSmsData.getSmsAlertBits(), request.getSmsAlertBit(), "SmsAlertBit");
    }

    private void validateAdditionalData(CreateBillPaymentRequestDTO request, CreateBillPaymentProperties.RequestAdditionalData reqAdditionalData) throws ClarityMessagingException {
        
        validateDataAgainstList(request, reqAdditionalData.getServiceCodeHeads(), request.getServiceCodeHead(), "ServiceCodeHead (Head)");

        if(null == request.getBillPayment()) {
            String errorDetails = String.format("Request must contain minimum 1 bill payment. txnRefId [%s]", request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        } else if (request.getBillPayment().size() > 99) {
            String errorDetails = String.format("MAX bill payment supported is up to 99. Current bill payment size [%d]. txnRefId [%s]", request.getBillPayment().size(), request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        for(int i=0; i<request.getBillPayment().size(); i++) {
            CreateBillPaymentRequestDTO.BillPayment billPayment = request.getBillPayment().get(i);

            validateDataAgainstList(request, reqAdditionalData.getServiceCodes(), billPayment.getServiceCode(), "ServiceCode");

            Iso8583Utils.validateField(billPayment.getFromAcctCode(), reqAdditionalData.getFromAcctCode());
            Iso8583Utils.validateField(billPayment.getToAcctCode(), reqAdditionalData.getToAcctCode());
            Iso8583Utils.validateField(billPayment.getPayeeCode(), reqAdditionalData.getPayeeCode());
            Iso8583Utils.validateField(billPayment.getRefNo(), reqAdditionalData.getRefNo());
            Iso8583Utils.validateField(billPayment.getIndividualEffectPaymentDate(), reqAdditionalData.getIndividualEffectPaymentDate());

            if(!TODAY_EFFECTIVE_DATE.equals(billPayment.getIndividualEffectPaymentDate())) {
                validateDataAgainstDateFormat(request, "yyyyMMdd",  billPayment.getIndividualEffectPaymentDate(), "IndividualEffectPaymentDate");
            }

            Iso8583Utils.validateField(billPayment.getCurrencyCode(), reqAdditionalData.getCurrencyCode());
            Iso8583Utils.validateField(billPayment.getTxnAmount(), reqAdditionalData.getTxnAmount());
            Iso8583Utils.validateField(billPayment.getBillAcctNo(), reqAdditionalData.getBillAcctNo());
            Iso8583Utils.validateField(billPayment.getCustName(), reqAdditionalData.getCustName());
            Iso8583Utils.validateField(billPayment.getIcNoBusRegNo(), reqAdditionalData.getIcNoBusRegNo());
            Iso8583Utils.validateField(billPayment.getCNo(), reqAdditionalData.getCNo());
            Iso8583Utils.validateField(billPayment.getExpiryDate(), reqAdditionalData.getExpiryDate());

            if(null != billPayment.getExpiryDate() && !"0000".equals(billPayment.getExpiryDate())) {
                validateDataAgainstDateFormat(request, "MMyy",  billPayment.getExpiryDate(), "ExpiryDate");
            }

            Iso8583Utils.validateField(billPayment.getCvv(), reqAdditionalData.getCvv());
        }
    }

    private void validateSmsData(CreateBillPaymentRequestDTO request, CreateBillPaymentProperties.RequestSmsData reqSmsData) throws ClarityMessagingException {
        Iso8583Utils.validateField(request.getSmsUserId(), reqSmsData.getSmsUserId());
        Iso8583Utils.validateField(request.getSelfNotifMobileNo(), reqSmsData.getSelfNotifMobileNo());
    }

    private void updateRequestData(CreateBillPaymentRequestDTO request) {
        CreateBillPaymentProperties.RequestDataElement reqDataElement = createBillPaymentProp.getRequest().getDataElement();

        request.setFromAcctNo(Iso8583Utils.padFieldData(request.getFromAcctNo(), reqDataElement.getFromAcctNo()));

        if(null == request.getToAcctNo()) {
            request.setToAcctNo(reqDataElement.getToAcctNo().getDefaultVal());
        } else {
            // TODO: should we right pad zeros with max size 19? similar to from acct no.?
            request.setToAcctNo(Iso8583Utils.padFieldData(request.getToAcctNo(), reqDataElement.getToAcctNo()));
        }

        updateAdditionalData(request);
        updateSmsData(request);
    }

    private void updateAdditionalData(CreateBillPaymentRequestDTO request) {
        CreateBillPaymentProperties.RequestDataElement reqDataElement = createBillPaymentProp.getRequest().getDataElement();
        CreateBillPaymentProperties.RequestAdditionalData reqAdditionalData = reqDataElement.getAdditionalData();

        for(CreateBillPaymentRequestDTO.BillPayment billPayment : request.getBillPayment()) {
            if (null == billPayment.getRefNo()) {
                billPayment.setRefNo(reqAdditionalData.getRefNo().getDefaultVal());
            } else {
                // TODO: if client set with value, should we perform padding? zeros or spaces? left or right?
                billPayment.setRefNo(Iso8583Utils.padFieldData(billPayment.getRefNo(), reqAdditionalData.getRefNo()));
            }

            billPayment.setTxnAmount(Iso8583Utils.padFieldData(billPayment.getTxnAmount(), reqAdditionalData.getTxnAmount()));

            if (null == billPayment.getBillAcctNo()) {
                billPayment.setBillAcctNo(reqAdditionalData.getBillAcctNo().getDefaultVal());
            } else {
                // TODO: if client set with value, should we perform padding? zeros or spaces? left or right?
                billPayment.setBillAcctNo(Iso8583Utils.padFieldData(billPayment.getBillAcctNo(), reqAdditionalData.getBillAcctNo()));
            }

            billPayment.setCustName(Iso8583Utils.padFieldData(billPayment.getCustName(), reqAdditionalData.getCustName()));
            billPayment.setIcNoBusRegNo(Iso8583Utils.padFieldData(billPayment.getIcNoBusRegNo(), reqAdditionalData.getIcNoBusRegNo()));

            if (null == billPayment.getCNo()) {
                billPayment.setCNo(reqAdditionalData.getCNo().getDefaultVal());
            } else {
                // TODO: if client set with value, should we perform padding? zeros or spaces? left or right?
                billPayment.setCNo(Iso8583Utils.padFieldData(billPayment.getCNo(), reqAdditionalData.getCNo()));
            }

            if (null == billPayment.getExpiryDate()) {
                billPayment.setExpiryDate(reqAdditionalData.getExpiryDate().getDefaultVal());
            }

            if (null == billPayment.getCvv()) {
                billPayment.setCvv(reqAdditionalData.getCvv().getDefaultVal());
            }
        }
    }

    private void updateSmsData(CreateBillPaymentRequestDTO request) {
        CreateBillPaymentProperties.RequestDataElement reqDataElement = createBillPaymentProp.getRequest().getDataElement();
        CreateBillPaymentProperties.RequestSmsData reqSmsData = reqDataElement.getSmsData();

        if (TODAY_EFFECTIVE_DATE.equals(request.getEffectiveDate()) && ("0".equals(request.getSmsAlertBit()))) {
            log.debug("[{}] EffectiveDate [{}] and SmsAlertBit [{}] condition detected, overwrite SmsUserId [{}] and SelfNotifMobileNo [{}] to default values",
                request.getTxnRefId(), request.getEffectiveDate(), request.getSmsAlertBit(),
                    request.getSmsUserId(), request.getSelfNotifMobileNo());
            request.setSmsUserId(reqSmsData.getSmsUserId().getDefaultVal());
            request.setSelfNotifMobileNo(reqSmsData.getSelfNotifMobileNo().getDefaultVal());
        } else {
            // TODO: should we do padding? zeros or spaces? left or right?
            request.setSmsUserId(Iso8583Utils.padFieldData(request.getSmsUserId(), reqSmsData.getSmsUserId()));
            request.setSelfNotifMobileNo(Iso8583Utils.padFieldData(request.getSelfNotifMobileNo(), reqSmsData.getSelfNotifMobileNo()));
        }
    }
}
