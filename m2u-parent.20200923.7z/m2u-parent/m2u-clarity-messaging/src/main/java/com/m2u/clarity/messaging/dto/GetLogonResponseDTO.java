package com.m2u.clarity.messaging.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.Map;

@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class GetLogonResponseDTO extends AbstractResponseDTO {

    private String retrievalRefNo;
    private String pan2;
    private String infoBlockId;
    private String custName;
    private String custTypeFlag;
    private String custIcBizReg;
    private String custDob;
    private String gender;
    private String raceCode;
    private String custIcNoBizRegNo;
    private String housePhoneNo;
    private String officePhoneNo;
    private String addLine1;
    private String addLine2;
    private String addLine3;
    private String addLine4;
    private String addLine5;
    private String email;
    private String institutionId;
    private String overseaFlag;
    private String gcif;
    private String smallBizChargeIndicator;
    private String coBadgeDbCardType;
    private String pdpaS2uIndicator;
    private Map<String, List<Map<String, String>>> accountGroups;
}
