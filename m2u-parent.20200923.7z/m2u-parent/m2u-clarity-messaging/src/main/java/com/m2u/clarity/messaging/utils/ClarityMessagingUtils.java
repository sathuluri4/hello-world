package com.m2u.clarity.messaging.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.m2u.clarity.messaging.constants.ClarityMessaging;
import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.dto.AbstractRequestDTO;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.ClarityCommonProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public final class ClarityMessagingUtils {

    private static ClarityCommonProperties clarityCommonProperties;

    private ClarityMessagingUtils() {}

    @Autowired
    public synchronized void setClarityCommonProperties(ClarityCommonProperties clarityCommonProp) {
        clarityCommonProperties = clarityCommonProp;
    }

    public static String generateReqMessageWrapper(AbstractRequestDTO request, String messageType) throws ClarityMessagingException {
        StringBuilder strB = new StringBuilder();
        Map<String, String> reqMsgWrapper = clarityCommonProperties.getReqMsgWrapper();

        try {
            // Check to ensure date time in the right format
            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
            formatter.setLenient(false);
            formatter.parse(request.getCreationDateTime());
        } catch (ParseException e) {
            String errorDetails = String.format("Invalid creation datetime detected '%s'. txnRefId [%s]", request.getCreationDateTime(), request.getTxnRefId());
            log.error(ErrorTemplate.TEMPLATE_1,
                request.getTxnRefId(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getCode(),
                ClarityMessagingStatus.INVALID_REQUEST_DATA.getDesc(), errorDetails, e);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails, e);
        }

        return strB
            .append(reqMsgWrapper.get(ClarityMessaging.REQ_MSG_WRAPPER_PREFIX))
            .append(reqMsgWrapper.get(ClarityMessaging.REQ_MSG_WRAPPER_APP_ID))
            .append(StringUtils.rightPad(request.getUserId(), 30, " "))
            .append(request.getCreationDateTime())
            .append(reqMsgWrapper.get(ClarityMessaging.REQ_MSG_WRAPPER_SRC_ID))
            .append(reqMsgWrapper.get(ClarityMessaging.REQ_MSG_WRAPPER_DEST_ID))
            .append(messageType)
            .append(reqMsgWrapper.get(ClarityMessaging.REQ_MSG_WRAPPER_MSG_STAT))
            .append(StringUtils.rightPad(request.getTxnRefId(), 20, " "))
            .append(reqMsgWrapper.get(ClarityMessaging.REQ_MSG_WRAPPER_SESSION_ID))
            .append(reqMsgWrapper.get(ClarityMessaging.REQ_MSG_WRAPPER_RESERVE))
            .toString();
    }

    public static <T> T parseRespMessageWrapper(Class<T> type, StringBuilder data) throws ClarityMessagingException {
        // Parse response message wrapper
        List<Map<String, Object>> fieldList = Iso8583Utils.parseFields(data, clarityCommonProperties.getRespMsgWrapper(), 1);
        ObjectMapper mapper = new ObjectMapper();
        // Create new object that hold the details
        return mapper.convertValue(fieldList.get(0), type);
    }
}
