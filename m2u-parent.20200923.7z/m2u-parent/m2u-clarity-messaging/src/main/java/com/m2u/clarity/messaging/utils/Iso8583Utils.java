package com.m2u.clarity.messaging.utils;

import com.m2u.clarity.messaging.constants.ClarityMessaging;
import com.m2u.clarity.messaging.constants.ErrorTemplate;
import com.m2u.clarity.messaging.constants.Iso8583;
import com.m2u.clarity.messaging.enums.ClarityMessagingStatus;
import com.m2u.clarity.messaging.exception.ClarityMessagingException;
import com.m2u.clarity.messaging.properties.Field;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.*;

@Slf4j
@Component
public final class Iso8583Utils {

    private Iso8583Utils() {}

    public static List<Map<String, Object>> parseFields(StringBuilder data, List<Field> fields, int size) throws ClarityMessagingException {
        List<Map<String, Object>> fieldList = new ArrayList<>(size);

        // Loop through the parsing process depends on cycle size
        for(int i=0; i<size; i++) {
            // TODO: Decide whether is sequence important, if not should change to HashMap instead
            Map<String, Object> fieldMap = new LinkedHashMap<>(fields.size());
            for(Field field : fields) {
                Map.Entry<String, Object> fieldPair = parseField(data, field);
                if(null != fieldPair) {
                    fieldMap.put(fieldPair.getKey(), fieldPair.getValue());
                }
            }
            fieldList.add(fieldMap);
        }

        return fieldList;
    }

    public static void validateField(String data, Field field) throws ClarityMessagingException {
        // NULL is not allowed for compulsory data
        if (null == data && field.isOptional()) {
            return;
        } else if (null == data) {
            String errorDetails = String.format("Field [%s] value is NULL", field.getName());
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        // Check number format of data
        if(field.getType().equals(Iso8583.DATA_TYPE_NUMBER) && !data.matches("\\d+")) {
            String errorDetails = String.format("Field [%s] should only contain number values [%s]", field.getName(), data);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }

        // Check size of data
        if(data.length() > field.getSize() ||
                !(field.isLeftPadSpaces() || field.isRightPadSpaces() || field.isLeftPadZeros() || field.isRightPadZeros()) && data.length() != field.getSize()) {

            String errorDetails = String.format("Field [%s] size is [%d] instead of required size [%d]",
                    field.getName(), data.length(), field.getSize());
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_REQUEST_DATA, errorDetails);
        }
    }

    public static void replaceBitmaps(StringBuilder strB, String primaryBitmap) throws ClarityMessagingException {
        if(null == strB || strB.length() == 0) {
            String errorDetails = String.format("Failed to replace bitmaps in data [%s]", strB);
            log.error(ErrorTemplate.TEMPLATE_3,
                ClarityMessagingStatus.INVALID_DATA.getCode(),
                ClarityMessagingStatus.INVALID_DATA.getDesc(),
                errorDetails);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_DATA, errorDetails);
        }
        strB.replace(4, 20, primaryBitmap);
    }

    public static String padFieldData(String data, Field field) {
        // If it is NULL, just replace with empty string
        if(data == null) {
            data = "";
        }
        // Perform padding (LEFT/RIGHT) using zeros or spaces
        if (field.isLeftPadSpaces()) {
            return StringUtils.leftPad(data, field.getSize(), " ");
        } else if(field.isRightPadSpaces()) {
            return StringUtils.rightPad(data, field.getSize(), " ");
        } else if(field.isLeftPadZeros()) {
            return StringUtils.leftPad(data, field.getSize(), "0");
        } else if(field.isRightPadZeros()) {
            return StringUtils.rightPad(data, field.getSize(), "0");
        } else {
            return data;
        }
    }

    private static Map.Entry<String, Object> parseField(StringBuilder data, Field field) throws ClarityMessagingException {
        Map.Entry<String, Object> fieldPair = null;
        int endIndex = 0;

        if (!field.isIgnore()) {
            boolean repeat = field.isRepeat();
            Map<String, List<Map<String, Object>>> fieldMap = null;

            do {
                String fieldData = null;
                // TODO: IMPORTANT!!! The logic doesn't handle repeating structure well, refactor it for both LIST and MAP scenarios
                if(field.isList()) {
                    fieldData = field.getName();
                } else {
                    // Extract the field data
                    // TODO: Should we trim the data or keep as original, e.g. zeros, spaces, etc?
                    fieldData = data.substring(0, field.getSize()).trim();
                    // Remove extracted field data
                    data.delete(0, field.getSize());

                    fieldData = convertFieldData(fieldData, field);
                }
                // Additional process for field which has subfields
                if (!field.getSubFields().isEmpty()) {
                    if(null == fieldMap) {
                        // TODO: Decide whether is sequence important, if not should change to HashMap instead
                        fieldMap = new LinkedHashMap<>();
                    }
                    fieldPair = parseChildFields(data, field, endIndex, fieldData, fieldMap);
                    // TODO: IMPORTANT!!! This is a temporary hack, refactor it as necessary
                    if(field.isList()) {
                        if(fieldMap.values().size() > 0) {
                            fieldPair = new AbstractMap.SimpleEntry<>(field.getName(), fieldMap.get(field.getName()));
                        }
                    }
                } else {
                    fieldPair = new AbstractMap.SimpleEntry<>(field.getName(), fieldData);
                }

                // Control whether to proceed to stop the cycle
                if (!repeatParseFields(data, repeat)) {
                    repeat = false;
                }

            } while(repeat);
        } else {
            // For skip field, we still need to remove them so that it wont get process again
            // Remove extracted field data
            data.delete(0, field.getSize());
        }
        return fieldPair;
    }

    private static boolean repeatParseFields(StringBuilder data, boolean currentRepeatFlag) {
        return currentRepeatFlag &&
                !(data.length() == 0 || (data.length() == 2 && ClarityMessaging.END_OF_MESSAGE.equals(data.toString())));
    }

    private static Map.Entry<String, Object> parseChildFields(StringBuilder data, Field parentField, int startIndex, String parentKey, Map<String, List<Map<String, Object>>> fieldMap) throws ClarityMessagingException {
        int noOfOccursSize = parentField.getNoOfOccursSize();
        String fieldData = data.substring(startIndex, (startIndex + noOfOccursSize)).trim();
        // Remove extracted field data
        data.delete(startIndex, (startIndex + noOfOccursSize));
        int noOfOccurs = Integer.parseInt(fieldData);

        List<Map<String, Object>> fieldList = parseFields(data, parentField.getSubFields(), noOfOccurs);
        fieldMap.put(parentKey, fieldList);

        return new AbstractMap.SimpleEntry<>(parentField.getName(), fieldMap);
    }

    private static String convertFieldData(String data, Field field) throws ClarityMessagingException {
        try {
            if (Iso8583.DATA_TYPE_ALPHA.equals(field.getType())) {
                return data;
            } else if (Iso8583.DATA_TYPE_NUMBER.equals(field.getType())) {
                return String.valueOf(Long.parseLong(data));
            } else {
                String errorDetails = String.format("Field [%s] type unsupported [%s]", field.getName(), field.getType());
                throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_CONFIGURATION, errorDetails);
            }
        } catch (NumberFormatException e) {
            String errorDetails = String.format("Field [%s] should only contain number values [%s]", field.getName(), data);
            throw new ClarityMessagingException(ClarityMessagingStatus.INVALID_DATA, errorDetails, e);
        }
    }
}
