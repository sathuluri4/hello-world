package com.m2u.common.exception;

public class JSONException extends Exception {

    public JSONException(String errorDetails) {
        super(errorDetails);
    }

    public JSONException(String errorDetails, Throwable cause) {
        super(errorDetails, cause);
    }
}
