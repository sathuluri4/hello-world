package com.m2u.common.exception;

public class EncryptionKeyPairException extends Exception {

    public EncryptionKeyPairException(String errorDetails) {
        super(errorDetails);
    }

    public EncryptionKeyPairException(String errorDetails, Throwable cause) {
        super(errorDetails, cause);
    }
}
