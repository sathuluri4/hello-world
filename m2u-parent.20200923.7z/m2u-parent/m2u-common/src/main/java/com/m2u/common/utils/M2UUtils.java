package com.m2u.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

@Slf4j
@Component
public class M2UUtils {

    private static String downtimeFilepath;

    private M2UUtils() {}

    @Value("${m2u.downtime-file}")
    public synchronized void setDowntimeFilepath(String downtimeFilePth) {
        downtimeFilepath = downtimeFilePth;
    }

    // TODO: Use DB to control instead of file, so that control is centralize in one place instead of multiple VM file replacement
    public static boolean isSystemDowntime() {
        boolean isSystemDowntime = false;
        try {
            Path file = Paths.get(downtimeFilepath);
            if (Files.exists(file)) {
                List<String> lines = Files.readAllLines(Paths.get(downtimeFilepath));
                if(!lines.isEmpty()) {
                    String line = lines.get(0).trim();
                    if("1".equals(line) || "2".equals(line)) {
                        isSystemDowntime = true;
                    }
                }
            }
        } catch (IOException e) {
            // TODO: If exception happened then treat system as UP
        }
        return isSystemDowntime;
    }

    public static String createSessionId() {
        // TODO: Remove the "-" to make the value fit into DB column
        return UUID.randomUUID().toString().replace("-","");
    }

    public static String createToken() {
        // TODO: Remove the "-" to make the value fit into DB column
        return UUID.randomUUID().toString().replace("-","");
    }

    public static boolean isTokenValid(String expectedToken, String actualToken) {
        return expectedToken.equals(actualToken);
    }
}
