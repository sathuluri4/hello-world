package com.m2u.common.exception;

public class CryptographicException extends Exception {

    public CryptographicException(String errorDetails) {
        super(errorDetails);
    }

    public CryptographicException(String errorDetails, Throwable cause) {
        super(errorDetails, cause);
    }
}
