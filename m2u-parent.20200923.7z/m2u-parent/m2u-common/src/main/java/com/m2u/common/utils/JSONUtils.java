package com.m2u.common.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.m2u.common.exception.JSONException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class JSONUtils {

    private static final ObjectMapper mapper = new ObjectMapper();

    static {
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }

    private JSONUtils() {}

    public static String convertObjectToJSON(Object obj) throws JSONException {
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            String errorDetails = String.format("Failed to convert to object to JSON string [%s]", obj);
            log.error(errorDetails, e);
            throw new JSONException(errorDetails, e);
        }
    }

    public static <T> T convertJSONToObject(Class<T> t, String json) throws JSONException {
        try {
            return mapper.readValue(json, t);
        } catch (Exception e) {
            String errorDetails = String.format("Failed to parse json [%s] to class [%s]", json, t.getSimpleName());
            log.error(errorDetails, e);
            throw new JSONException(errorDetails, e);
        }
    }
}
